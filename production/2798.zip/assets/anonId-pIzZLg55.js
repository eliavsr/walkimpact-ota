function a(e){let t=0;for(let h=0;h<(e||"").length;h++)t=Math.imul(31,t)+e.charCodeAt(h)|0;return Math.abs(t).toString(36).slice(0,10)}export{a as h};
