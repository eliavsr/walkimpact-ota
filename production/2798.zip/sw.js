/* WalkImpact Service Worker — Web Push (VAPID) handler.
 *
 * The backend (sendTemplatedNotification / adminSendNotification) delivers a
 * JSON payload: { title, body, url }. This SW MUST listen for the 'push' event
 * and call showNotification — otherwise the push is received by the browser but
 * NOTHING is displayed to the user. */

const APP_NAME = 'WalkImpact';
// Local, so a push notification never waits on a third-party CDN — and shows
// the same mark as the app icon.
const ICON = '/icon-192.png';

// Activate immediately so a freshly-registered SW starts handling push right away.
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// ── ALWAYS-FRESH APP SHELL ──────────────────────────────────────────────────
// The stale-code problem: index.html was being served from the browser's HTTP
// cache, and it points at the content-hashed JS bundles — so a cached index.html
// kept loading OLD bundles even after a new deploy. Result: fixes that shipped
// looked like they "did nothing" until the user manually cleared their cache.
//
// Fix: for NAVIGATIONS (the HTML document) go network-first and bypass the HTTP
// cache, so every load pulls the latest index.html → the latest bundles. Assets
// are content-hashed (safe to keep), so only the document needs this.
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req, { cache: 'no-store' }).catch(() => fetch(req).catch(() => new Response('', { status: 504 })))
    );
  }
});

// Show the notification when a push arrives.
self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    // Fallback: treat the raw payload as the body text.
    data = { title: APP_NAME, body: event.data ? event.data.text() : '' };
  }

  const title = data.title || APP_NAME;
  const options = {
    body: data.body || '',
    icon: data.icon || ICON,
    badge: ICON,
    dir: 'rtl',
    lang: 'he',
    vibrate: [120, 60, 120],
    requireInteraction: false,
    data: { url: data.url || '/lavie' },
    tag: data.tag || 'walkimpact-notification',
    renotify: true,
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Focus an existing tab or open a new one when the user taps the notification.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification.data && event.notification.data.url) || '/lavie';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          if ('navigate' in client) {
            try { client.navigate(targetUrl); } catch (e) { /* ignore */ }
          }
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
