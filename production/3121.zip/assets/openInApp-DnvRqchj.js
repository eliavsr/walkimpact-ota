import{a7 as t}from"./index-CPhBLC52.js";async function a(n){await t(n)}function i(n){return o=>{o.preventDefault(),a(n)}}export{i as o};
