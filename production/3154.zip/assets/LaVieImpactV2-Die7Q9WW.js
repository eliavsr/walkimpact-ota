import{r as s,j as e,R as Z}from"./ui-vendor-DDB9bS0w.js";import{b as J,bA as ee}from"./index-CeRA1y7S.js";import{P as ae}from"./ParticleField-DiMFSfDU.js";import{T as ie}from"./landingContent-9PbDh-XT.js";import{m as te,r as re,D as ne,a as se,b as oe,C as T,S as F,c as le,P as V,h as ce,e as de,d as pe}from"./impactV2Content-e5ukgIyP.js";import"./data-vendor-D4GOa4bq.js";const me=[[4,9,7,14,12,19,24],[3,6,10,9,16,22,30],[8,11,9,15,18,17,24]],H={he:[{who:"פלוגה ב׳ · 34 משתתפים",big:"78%",bigLbl:"תרגלו השבוע",trend:"עלייה חמישי שבוע ברציפות",kpis:[["34","משתתפים, נוכחות מלאה"],["12%+","מול החודש שעבר"],["0","שמות שנחשפו"]],bands:[["עומס נמוך",38],["עומס בינוני",44],["עומס גבוה",18]],line:"המפקד רואה את מה שאף מסדר לא מראה: איך הפלוגה באמת מחזיקה. בלי לחשוף אף חייל."},{who:"עמותה · 212 משתתפים",big:"3,180",bigLbl:"תרגולים החודש",trend:"פי 2.4 מהרבעון הקודם",kpis:[["212","משפחות לוחמות פעילות"],["פי 2.4","מהרבעון הקודם"],["4","יישובים בתכנית"]],bands:[["משפחות פעילות",71],["בתנופה",46],["זקוקות לחיזוק",12]],line:"הארגון רואה איפה התמיכה עובדת, ומכוון לשם את המשאבים. בלי לגעת בפרטיות של איש."},{who:"מטפל · 19 מלווים",big:"84%",bigLbl:"תרגלו בין המפגשים",trend:"הרצף שמחזיק את הטיפול",kpis:[["19","מלווים ברצף"],["d=2.55","האפקט שהרצף משמר"],["0","פרטים אישיים"]],bands:[["רצף מלא",67],["רצף חלקי",22],["בהפסקה",11]],line:"המטפל מקבל את מה שאין לו היום: עיניים על 167 השעות שבין המפגשים. ברמת הקבוצה בלבד."}],en:[{who:"Company B · 34 participants",big:"78%",bigLbl:"practised this week",trend:"Five weeks of climbing",kpis:[["34","participants, full presence"],["+12%","vs last month"],["0","names exposed"]],bands:[["Low load",38],["Mid load",44],["High load",18]],line:"The commander sees what no parade ever shows: how the company is really holding. Without exposing a single soldier."},{who:"NPO · 212 participants",big:"3,180",bigLbl:"practices this month",trend:"2.4x the previous quarter",kpis:[["212","active fighting families"],["2.4x","the previous quarter"],["4","towns in the programme"]],bands:[["Active families",71],["Gaining momentum",46],["Need reinforcement",12]],line:"The organisation sees where support is working and aims its resources there. Without touching anyone’s privacy."},{who:"Therapist · 19 supported",big:"84%",bigLbl:"practised between sessions",trend:"The continuity that holds treatment",kpis:[["19","in steady support"],["d=2.55","the effect continuity keeps"],["0","personal details"]],bands:[["Full continuity",67],["Partial",22],["Paused",11]],line:"The therapist gets what the clinic never had: eyes on the 167 hours between sessions. Group level only."}]},he=[0,1,3],ge=o=>{const d=Math.max(...o);return o.map((n,v)=>[v*(100/(o.length-1)),26-n/d*22])},xe=o=>o.map(([d,n],v)=>`${v?"L":"M"}${d.toFixed(1)},${n.toFixed(1)}`).join(" ");function G({cast:o,field:d,markRef:n,className:v}){const p=s.useRef(null);return s.useEffect(()=>{const N=p.current;if(!N)return;const c=window.matchMedia("(prefers-reduced-motion: reduce)").matches;let w=0,b=0,z=!1;const f=2800,k=h=>{b||(b=h);const g=Math.min(1,(h-b)/f);n.current[d]=g,g<1&&(w=requestAnimationFrame(k))},y=()=>{if(!z){if(z=!0,c){n.current[d]=1;return}w=requestAnimationFrame(k)}};if(!("IntersectionObserver"in window)){y();return}const m=new IntersectionObserver(h=>{h.forEach(g=>{g.isIntersecting&&(y(),m.disconnect())})},{threshold:.3});return m.observe(N),()=>{cancelAnimationFrame(w),m.disconnect()}},[d,n]),e.jsx("div",{className:v,ref:p,children:e.jsx(ae,{cast:o,markRef:n,field:d})})}function q({text:o,label:d}){return o?e.jsxs("details",{className:"v2src",children:[e.jsx("summary",{children:d}),e.jsx("p",{children:o})]}):null}function je(){const[o,d]=s.useState("he"),[n,v]=s.useState(null),[p,N]=s.useState(11),[c,w]=s.useState(0),[b,z]=s.useState(!1),[f,k]=s.useState(!1),y=s.useRef(!1),m=s.useRef(null),h=s.useRef(!1),g=s.useRef(null),D=s.useRef({sold:0,fam:0}),i=s.useMemo(()=>te(n,o),[n,o]),E=s.useMemo(()=>re(n),[n]),B=s.useMemo(()=>({...ne,...(n==null?void 0:n.images)||{}}),[n]),u=H[o]||H.he,Y=o==="he"?ce:de,U=p*pe,W=((n==null?void 0:n.donate_url_il)||"").trim()||se,K=((n==null?void 0:n.donate_url_intl)||"").trim()||oe,R=(n==null?void 0:n.sticky_cta_enabled)!==!1;s.useEffect(()=>{let t=!0;return(async()=>{try{const a=await J.entities.ImpactPageV2.filter({singleton_key:"main"},"-updated_date",1);t&&(a!=null&&a[0])&&v(a[0])}catch{}})(),()=>{t=!1}},[]),s.useEffect(()=>{const t=document.title;return document.title=i.title||t,h.current=window.matchMedia("(prefers-reduced-motion: reduce)").matches,()=>{document.title=t}},[i.title]);const M=s.useCallback(()=>{if(m.current)return m.current;const t=window.AudioContext||window.webkitAudioContext;if(!t)return null;const a=new t,r=Math.floor(a.sampleRate*4),l=a.createBuffer(1,r,a.sampleRate),x=l.getChannelData(0);let j=0;for(let O=0;O<r;O++){const X=Math.random()*2-1;j=(j+.02*X)/1.02,x[O]=j*3.4}const L=a.createGain();L.gain.value=0,L.connect(a.destination);const C=a.createBufferSource();C.buffer=l,C.loop=!0;const A=a.createBiquadFilter();A.type="lowpass",A.frequency.value=320;const I=a.createGain();return I.gain.value=.05,C.connect(A),A.connect(I),I.connect(L),C.start(),m.current={ctx:a,master:L},m.current},[]),Q=s.useCallback(()=>{const t=M();if(!t)return;t.ctx.state==="suspended"&&t.ctx.resume();const a=!y.current;y.current=a,z(a);const r=t.ctx.currentTime;t.master.gain.cancelScheduledValues(r),t.master.gain.setValueAtTime(t.master.gain.value,r),t.master.gain.linearRampToValueAtTime(a?1:0,r+(a?1:.4))},[M]);s.useEffect(()=>{if(!R){k(!1);return}let t=!1;const a=()=>{t=!1;const l=window.scrollY>window.innerHeight*.85,x=g.current,j=x?x.getBoundingClientRect().top<window.innerHeight*.9:!1;k(l&&!j)},r=()=>{t||(t=!0,requestAnimationFrame(a))};return window.addEventListener("scroll",r,{passive:!0}),window.addEventListener("resize",r),a(),()=>{window.removeEventListener("scroll",r),window.removeEventListener("resize",r)}},[R,E]),s.useEffect(()=>{const t=document.querySelectorAll(".wi-v2 [data-reveal]");if(!("IntersectionObserver"in window)||h.current){t.forEach(r=>r.classList.add("on"));return}const a=new IntersectionObserver(r=>{r.forEach(l=>{l.isIntersecting&&(l.target.classList.add("on"),a.unobserve(l.target))})},{rootMargin:"4000px 0px -8% 0px",threshold:0});return t.forEach(r=>a.observe(r)),()=>a.disconnect()},[o,E,c]);const $=t=>ee("form","impact-v2",`${t}_seats_${p}`),_=t=>{var a;t.preventDefault(),(a=g.current)==null||a.scrollIntoView({behavior:h.current?"auto":"smooth",block:"start"})},S=o==="he",P={hero:t=>e.jsxs("section",{className:"v2 dark hero",style:{backgroundImage:`url('${B.img_hero}')`},children:[e.jsxs("div",{className:"v2in",children:[e.jsx("p",{className:"word",children:i.hero}),e.jsx("p",{className:"lead",children:(i.heroLine||[]).map((a,r)=>e.jsxs(Z.Fragment,{children:[r?e.jsx("br",{}):null,a]},a))}),e.jsx("p",{className:"attrib",children:i.heroSrc})]}),e.jsxs("a",{className:"cue",href:"#donate",onClick:_,children:[i.scroll,e.jsx("i",{"aria-hidden":"true",children:"↓"})]})]},t.key),problem:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:i.problemTitle}),e.jsx("p",{className:"h2sub",children:i.problemSub}),e.jsx(G,{cast:"soldiers",field:"sold",markRef:D,className:"field"}),e.jsx("p",{className:"bignum",children:e.jsx("span",{children:i.problemNum})}),e.jsx(G,{cast:"family",field:"fam",markRef:D,className:"field fam"}),e.jsx("p",{className:"body",children:i.problemLine}),e.jsx(q,{text:i.problemSrc,label:i.sourcesLabel})]})},t.key),scope:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:i.scopeTitle}),e.jsx("div",{className:"tiles","data-reveal":!0,children:(i.scopeTiles||[]).map(([a,r,l])=>e.jsxs("div",{className:"tile",children:[e.jsx("span",{className:"tn",children:a}),e.jsx("span",{className:"tl",children:r}),l?e.jsx("span",{className:"tnote",children:l}):null]},`${a}-${r}`))}),e.jsx("p",{className:"money",children:i.scopeMoney}),e.jsx("p",{className:"body",children:i.scopeMoneyLine}),e.jsxs("a",{className:"inlinecta",href:"#donate",onClick:_,children:[i.scopeMoneyCta," ",e.jsx("span",{"aria-hidden":"true",children:S?"←":"→"})]}),e.jsx(q,{text:i.scopeSrc,label:i.sourcesLabel})]})},t.key),gap:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:i.gapTitle}),e.jsx("p",{className:"h2sub accent",children:i.gapSub}),e.jsx("div",{className:"hours","data-reveal":!0,"aria-hidden":"true",children:e.jsx("div",{className:"hourgrid",children:Array.from({length:168},(a,r)=>e.jsx("span",{className:`hr${r===0?" on":""}`},r))})}),e.jsx("p",{className:"micro",children:i.gapLegend})]})},t.key),proof:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:i.proofTitle}),e.jsx("div",{className:"bars","data-reveal":!0,children:(i.proofBars||[]).map(([a,r,l],x)=>e.jsxs("div",{className:"bar",children:[e.jsx("span",{className:"barlbl",children:a}),e.jsx("span",{className:"bartrack",children:e.jsx("span",{className:`barfill${x?" good":""}`,style:{width:`${r/2.55*100}%`}})}),e.jsx("span",{className:"bartag",children:l})]},a))}),e.jsx("p",{className:"body strong",children:i.proofNote}),e.jsx("p",{className:"bignum","data-reveal":!0,children:e.jsx("span",{children:i.reboundNum})}),e.jsx("p",{className:"body",children:i.reboundLine}),e.jsx(q,{text:i.proofSrc,label:i.sourcesLabel})]})},t.key),solution:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:i.solutionTitle}),e.jsx("p",{className:"h2sub",children:i.solutionSub}),e.jsx("div",{className:"phones","data-reveal":!0,children:(V[o]||V.he).map((a,r)=>e.jsxs("figure",{children:[e.jsx("span",{className:"phone",children:e.jsx("img",{src:a,alt:(i.solutionCaps||[])[r]||"",loading:"lazy",decoding:"async"})}),e.jsx("figcaption",{children:(i.solutionCaps||[])[r]})]},a))})]})},t.key),credibility:t=>e.jsx("section",{className:"v2 dark tight",children:e.jsxs("div",{className:"v2in",children:[e.jsx("p",{className:"credline",children:i.credLine}),e.jsx("p",{className:"micro",children:i.credSrc})]})},t.key),orgs:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:i.orgsTitle}),e.jsx("p",{className:"body strong",children:i.orgsSub}),e.jsx("p",{className:"body",children:i.orgsLine}),e.jsx("p",{className:"body",children:i.orgsPrivacy}),e.jsx("div",{className:"tabs",role:"tablist",children:(i.orgsTabs||[]).map((a,r)=>e.jsx("button",{role:"tab","aria-selected":c===r,className:`tab${c===r?" on":""}`,onClick:()=>w(r),children:a},a))}),e.jsxs("div",{className:"agg",role:"tabpanel",children:[e.jsxs("div",{className:"agghead",children:[e.jsx("p",{className:"aggwho",children:u[c].who}),e.jsx("span",{className:"aggtrend",children:u[c].trend})]}),e.jsxs("div",{className:"agghero",children:[e.jsxs("div",{children:[e.jsx("p",{className:"aggbig",children:u[c].big}),e.jsx("p",{className:"aggbiglbl",children:u[c].bigLbl})]}),(()=>{const a=ge(me[c]),r=xe(a),[l,x]=a[a.length-1];return e.jsxs("svg",{className:"spark",viewBox:"0 0 100 30","aria-hidden":"true",preserveAspectRatio:"none",children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"wiV2Spark",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"0",stopColor:"#C7155A",stopOpacity:".34"}),e.jsx("stop",{offset:"1",stopColor:"#C7155A",stopOpacity:"0"})]})}),e.jsx("path",{d:`${r} L100,30 L0,30 Z`,fill:"url(#wiV2Spark)",stroke:"none"}),e.jsx("path",{d:r,fill:"none",stroke:"#C7155A",strokeWidth:"2.4",strokeLinecap:"round",strokeLinejoin:"round"}),e.jsx("circle",{cx:l,cy:x,r:"2.4",fill:"#C7155A"})]})})()]}),e.jsx("div",{className:"aggkpis",children:u[c].kpis.map(([a,r])=>e.jsxs("div",{className:"kpi",children:[e.jsx("span",{className:"kpin",children:a}),e.jsx("span",{className:"kpil",children:r})]},r))}),e.jsx("div",{className:"aggbands",children:u[c].bands.map(([a,r])=>e.jsxs("div",{className:"band",children:[e.jsx("span",{className:"bandlbl",children:a}),e.jsx("span",{className:"bandtrack",children:e.jsx("span",{className:"bandfill",style:{width:`${r}%`}})}),e.jsxs("span",{className:"bandpct",children:[r,"%"]})]},a))}),e.jsx("p",{className:"aggline",children:u[c].line})]},c),e.jsx("p",{className:"micro",children:i.orgsNote})]})},t.key),voices:t=>e.jsx("section",{className:"v2 dark photo",style:{backgroundImage:`url('${B.img_voices}')`},children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:i.voicesTitle}),e.jsx("p",{className:"body",children:i.voicesSub}),e.jsx("div",{className:"voices","data-reveal":!0,children:he.map(a=>ie[a]).filter(Boolean).map(([a,r])=>e.jsxs("blockquote",{children:[e.jsx("p",{children:a}),e.jsx("cite",{children:r})]},r))})]})},t.key),traction:t=>e.jsx("section",{className:"v2 light tight",children:e.jsx("div",{className:"v2in",children:e.jsxs("div",{className:"tract","data-reveal":!0,children:[e.jsx("div",{className:"tractrow",children:(i.tractionStats||[]).map(([a,r])=>e.jsxs("div",{className:"tractstat",children:[e.jsx("span",{className:"tn",children:a}),e.jsx("span",{className:"tl",children:r})]},r))}),e.jsxs("blockquote",{className:"tractquote",children:[e.jsx("p",{children:i.tractionQuote}),e.jsx("cite",{children:i.tractionQuoteSrc})]}),e.jsxs("a",{className:"tractlink",href:le,target:"_blank",rel:"noopener noreferrer",children:[i.tractionLink," ",e.jsx("span",{"aria-hidden":"true",children:S?"←":"→"})]})]})})},t.key),donate:t=>e.jsx("section",{id:"donate",ref:g,className:"v2 dark photo ask",style:{backgroundImage:`url('${B.img_donate}')`},children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"asktitle",children:i.donateTitle}),e.jsx("p",{className:"anchor",children:i.donateSub}),e.jsx("p",{className:"anchorsub",children:i.donateSubSub}),e.jsx("p",{className:"h3",children:i.seatLabel}),e.jsx("div",{className:"grid","aria-hidden":"true",children:Array.from({length:T},(a,r)=>e.jsx("span",{className:`seat${r<Math.min(p,T)?" on":""}`},r))}),p>T&&e.jsxs("p",{className:"plus",children:["+",Y(p-T)]}),e.jsx("input",{className:"slider",type:"range",min:"0",max:F.length-1,step:"1",value:F.indexOf(p),onChange:a=>N(F[Number(a.target.value)]),"aria-label":i.seatLabel,"aria-valuetext":String(p)}),e.jsx("div",{className:"stops","aria-hidden":"true",children:F.map(a=>e.jsx("span",{children:a},a))}),e.jsx("a",{className:"cta",href:W,target:"_blank",rel:"noopener noreferrer",onClick:()=>$("primary"),children:i.cta(p,U)}),e.jsx("a",{className:"cta ghost",href:K,target:"_blank",rel:"noopener noreferrer",onClick:()=>$("intl"),children:i.ctaIntl}),e.jsx("p",{className:"legal",children:i.legal})]})},t.key)};return e.jsxs("div",{dir:i.dir,lang:o,className:`wi-v2${o==="en"?" en":""}`,children:[e.jsx("style",{children:ve}),e.jsxs("div",{className:"topbar",children:[e.jsx("button",{className:"chip",onClick:()=>d(S?"en":"he"),"aria-label":i.otherLabel,children:i.other}),e.jsx("button",{className:"chip",onClick:Q,role:"switch","aria-checked":b,children:`♪ ${b?i.sound[1]:i.sound[0]}`})]}),e.jsx("main",{children:E.map(t=>P[t.key]?P[t.key](t):null)}),R&&e.jsxs("a",{className:`sticky${f?" on":""}`,href:"#donate",onClick:_,"aria-hidden":!f,tabIndex:f?0:-1,children:[i.stickyCta," ",e.jsx("span",{"aria-hidden":"true",children:S?"←":"→"})]})]})}const ve=`
.wi-v2{--ink:#14111C;--ink2:#1D1926;--lav:#F3EDFA;--paper:#FFF;
  --magenta:#C7155A;--magenta2:#D81E5B;--violet:#8B60EA;
  --text-lt:#F7F4F9;--muted-lt:#CBC5D3;--text-dk:#14111C;--muted-dk:#6B6478;
  background:var(--ink);font-family:'Google Sans','Open Sans Hebrew','Heebo','Assistant',system-ui,sans-serif}
.wi-v2.en{font-family:'Google Sans','Assistant',system-ui,sans-serif}
.wi-v2 *{box-sizing:border-box}
.wi-v2 main{position:relative;z-index:1}

.wi-v2 .v2{position:relative;padding:clamp(5rem,12vh,9rem) clamp(1.25rem,6vw,5rem);
  display:flex;align-items:center;justify-content:center}
.wi-v2 .v2.tight{padding-top:clamp(2rem,5vh,3.5rem);padding-bottom:clamp(3.5rem,8vh,6rem)}
.wi-v2 .v2.dark{background:var(--ink);color:var(--text-lt)}
.wi-v2 .v2.light{background:var(--lav);color:var(--text-dk)}
.wi-v2 .v2.photo{background-size:cover;background-position:center}
.wi-v2 .v2.dark.photo::before{content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,rgba(20,17,28,.95) 0%,rgba(20,17,28,.88) 40%,rgba(20,17,28,.95) 100%)}
.wi-v2 .v2in{position:relative;z-index:1;max-width:740px;width:100%;text-align:center}
.wi-v2 .v2in.wide{max-width:1080px}

/* The copy sits in the TOP third, not the middle. Centred, it landed straight on
   the soldiers' faces and torsos - the busiest part of the frame - and the
   Hebrew became genuinely hard to read. Held high, the type has the plain wall
   and sky behind it and the photograph still reads underneath. */
.wi-v2 .hero{min-height:100svh;background-size:cover;background-position:center;
  align-items:flex-start;padding-top:clamp(9vh,14vh,16vh)}
.wi-v2 .hero::before{content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,rgba(20,17,28,.88) 0%,rgba(20,17,28,.74) 30%,
    rgba(20,17,28,.46) 56%,rgba(20,17,28,.62) 78%,rgba(20,17,28,.93) 100%)}
.wi-v2 .word{font-size:clamp(2.6rem,7vw,5.2rem);font-weight:800;line-height:.95;letter-spacing:-.03em;
  margin:0;text-shadow:0 4px 44px rgba(7,6,11,.85)}
.wi-v2 .lead{font-size:clamp(1.3rem,2.8vw,2rem);line-height:1.4;margin:26px auto 0;max-width:24ch;
  text-wrap:balance;text-shadow:0 2px 28px rgba(7,6,11,.9)}
.wi-v2 .attrib{font-size:.92rem;color:var(--muted-lt);margin:26px auto 0;max-width:46ch;line-height:1.55;
  text-shadow:0 2px 18px rgba(7,6,11,.95)}
.wi-v2 .cue{position:absolute;z-index:2;bottom:calc(26px + env(safe-area-inset-bottom,0px));
  left:50%;transform:translateX(-50%);font-size:1rem;
  color:#B4ADBF;letter-spacing:.14em;font-weight:600;text-decoration:none;
  text-shadow:0 2px 18px rgba(7,6,11,.95)}
.wi-v2 .cue i{display:block;font-style:normal;font-size:1.45rem;margin-top:8px;
  animation:wiV2Bob 2.6s cubic-bezier(.4,0,.6,1) infinite}
@keyframes wiV2Bob{0%,100%{transform:translateY(0);opacity:.4}50%{transform:translateY(9px);opacity:1}}

.wi-v2 .h1{font-size:clamp(1.9rem,4.5vw,3.4rem);font-weight:700;line-height:1.05;letter-spacing:-.02em;
  margin:0;text-wrap:balance}
.wi-v2 .h2sub{font-size:clamp(1.3rem,2.6vw,1.9rem);font-weight:500;line-height:1.3;margin:14px auto 0;
  max-width:26ch;text-wrap:balance}
.wi-v2 .h2sub.accent{color:var(--magenta)}
.wi-v2 .v2.dark .h2sub.accent{color:#F094B0}
.wi-v2 .h3{font-size:clamp(1.25rem,2.2vw,1.6rem);font-weight:700;margin:38px 0 4px}
.wi-v2 .body{font-size:clamp(1.05rem,1.6vw,1.3rem);line-height:1.6;margin:18px auto 0;max-width:44ch}
.wi-v2 .body.strong{font-weight:600}
.wi-v2 .v2.dark .body{color:var(--muted-lt)}
.wi-v2 .v2.light .body{color:var(--muted-dk)}
.wi-v2 .micro{font-size:.78rem;line-height:1.6;margin:16px auto 0;max-width:60ch}
.wi-v2 .v2.dark .micro{color:#8F8899}
.wi-v2 .v2.light .micro{color:var(--muted-dk)}
/* Weighted so the number groups with the cloud BELOW it, which is the one it
   counts, rather than floating equidistant between the two. */
.wi-v2 .bignum{margin:26px 0 0}
.wi-v2 .field+.bignum{margin-top:48px}
.wi-v2 .bignum span{display:inline-block;font-size:clamp(3.2rem,9vw,7rem);font-weight:800;line-height:1;
  letter-spacing:-.03em;color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .v2.dark .bignum span{color:#F094B0}
.wi-v2 .money{font-size:clamp(2rem,5.5vw,3.4rem);font-weight:800;letter-spacing:-.02em;margin:38px 0 0;
  color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .credline{font-size:clamp(.95rem,1.3vw,1.06rem);line-height:1.65;color:var(--muted-lt);
  margin:0 auto;max-width:60ch}

.wi-v2 .inlinecta{display:inline-flex;align-items:center;gap:8px;margin-top:22px;padding:13px 26px;
  border-radius:999px;background:var(--magenta);color:#fff;text-decoration:none;font-weight:700;font-size:1.02rem;
  transition:filter .25s,transform .25s}
.wi-v2 .inlinecta:hover{filter:brightness(1.08);transform:translateY(-2px)}

.wi-v2 .tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:32px auto 0}
.wi-v2 .tile{border-radius:20px;padding:22px 12px 18px;display:flex;flex-direction:column;gap:8px;align-items:center}
.wi-v2 .v2.light .tile{background:rgba(255,255,255,.72);border:1px solid rgba(139,96,234,.18)}
.wi-v2 .v2.dark .tile{background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.15)}
.wi-v2 .tile .tn{font-size:clamp(1.7rem,3.6vw,2.6rem);font-weight:800;line-height:1;letter-spacing:-.02em;
  color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .tile .tl{font-size:clamp(.95rem,1.35vw,1.06rem);line-height:1.4;text-align:center}
.wi-v2 .v2.light .tile .tl{color:var(--text-dk)}
.wi-v2 .v2.dark .tile .tl{color:var(--muted-lt)}
.wi-v2 .tile .tnote{font-size:.8rem;line-height:1.45;text-align:center}
.wi-v2 .v2.light .tile .tnote{color:var(--muted-dk)}
.wi-v2 .v2.dark .tile .tnote{color:#A49DB0}

/* The point clouds. Sized so ten figures still read as ten on a phone, with
   headroom above them for the in-canvas callouts. */
.wi-v2 .field{width:min(1040px,94vw);height:clamp(280px,36vh,420px);margin:30px auto 6px}
.wi-v2 .field.fam{width:min(520px,72vw);height:clamp(210px,26vh,300px);margin:18px auto 6px}
.wi-v2 .pfield{width:100%;height:100%;display:block}

.wi-v2 .hours{margin:34px auto 0;max-width:520px}
.wi-v2 .hourgrid{display:grid;grid-template-columns:repeat(24,1fr);gap:4px}
.wi-v2 .hr{aspect-ratio:1;border-radius:2px;background:rgba(255,255,255,.13)}
.wi-v2 .hr.on{background:var(--magenta);box-shadow:0 0 12px rgba(199,21,90,.75)}
.wi-v2 .hours[data-reveal] .hr{opacity:0;transition:opacity .5s}
.wi-v2 .hours[data-reveal].on .hr{opacity:1}

.wi-v2 .bars{display:flex;flex-direction:column;gap:20px;margin:34px auto 0;max-width:600px;text-align:start}
.wi-v2 .bar{display:grid;grid-template-columns:1fr;gap:8px}
.wi-v2 .barlbl{font-size:1.05rem}
.wi-v2 .v2.light .barlbl{color:var(--muted-dk)}
.wi-v2 .v2.dark .barlbl{color:var(--muted-lt)}
.wi-v2 .bartrack{display:block;height:16px;border-radius:99px;overflow:hidden}
.wi-v2 .v2.light .bartrack{background:rgba(20,17,28,.10)}
.wi-v2 .v2.dark .bartrack{background:rgba(255,255,255,.09)}
.wi-v2 .barfill{display:block;height:100%;border-radius:99px;background:#9C93AD;
  transition:width 1s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .barfill.good{background:linear-gradient(90deg,var(--violet),var(--magenta))}
.wi-v2 .bartag{font-size:.98rem;font-weight:700;font-variant-numeric:tabular-nums}
.wi-v2 .bars[data-reveal]:not(.on) .barfill{width:0 !important}

.wi-v2 .phones{display:grid;grid-template-columns:repeat(auto-fit,minmax(184px,1fr));gap:26px;margin:44px auto 0}
.wi-v2 .phones figure{margin:0}
.wi-v2 .phone{display:block;padding:9px;border-radius:34px;background:linear-gradient(160deg,#2A2436,#15121D);
  border:1px solid rgba(255,255,255,.16);box-shadow:0 24px 60px rgba(0,0,0,.6);position:relative}
.wi-v2 .phone::after{content:"";position:absolute;top:15px;left:50%;transform:translateX(-50%);
  width:34%;height:7px;border-radius:99px;background:#0B0910}
.wi-v2 .phone img{width:100%;display:block;border-radius:26px}
.wi-v2 .phones figcaption{font-size:1.02rem;color:var(--muted-lt);margin-top:14px;line-height:1.45}

.wi-v2 .tabs{display:flex;gap:8px;justify-content:center;margin:28px auto 0;flex-wrap:wrap}
.wi-v2 .tab{padding:11px 22px;border-radius:999px;font-size:1rem;font-weight:600;font-family:inherit;
  cursor:pointer;transition:background .25s,color .25s,border-color .25s}
.wi-v2 .v2.light .tab{background:rgba(255,255,255,.7);border:1px solid rgba(139,96,234,.24);color:var(--muted-dk)}
.wi-v2 .v2.light .tab.on{background:var(--magenta);border-color:var(--magenta);color:#fff}
.wi-v2 .agg{margin:26px auto 0;max-width:640px;text-align:start;border-radius:20px;padding:28px;
  animation:wiV2Rise .5s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .v2.light .agg{background:rgba(255,255,255,.82);border:1px solid rgba(139,96,234,.2)}
@keyframes wiV2Rise{from{opacity:0;transform:translateY(12px)}}
.wi-v2 .agghead{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap;margin-bottom:18px}
.wi-v2 .aggwho{font-size:1.15rem;font-weight:700;margin:0}
.wi-v2 .aggtrend{font-size:1rem;font-weight:600;color:var(--violet)}
.wi-v2 .agghero{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin:0 0 22px}
.wi-v2 .aggbig{font-size:clamp(2.6rem,6vw,4rem);font-weight:800;margin:0;line-height:1;letter-spacing:-.02em;
  font-variant-numeric:tabular-nums}
.wi-v2 .aggbiglbl{font-size:1.05rem;color:var(--muted-dk);margin:8px 0 0}
.wi-v2 .spark{width:min(150px,34%);height:44px;overflow:visible;opacity:.9}
.wi-v2 .aggkpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0 0 22px}
.wi-v2 .kpi{border-radius:12px;padding:14px 8px;display:flex;flex-direction:column;gap:4px;align-items:center;text-align:center;
  background:rgba(139,96,234,.08);border:1px solid rgba(139,96,234,.16)}
.wi-v2 .kpin{font-size:clamp(1.2rem,2vw,1.5rem);font-weight:800;color:var(--magenta);line-height:1;font-variant-numeric:tabular-nums}
.wi-v2 .kpil{font-size:.95rem;color:var(--muted-dk);line-height:1.35}
.wi-v2 .aggbands{display:flex;flex-direction:column;gap:15px}
.wi-v2 .band{display:grid;grid-template-columns:8ch 1fr 4ch;align-items:center;gap:12px}
.wi-v2 .bandlbl{font-size:1rem;color:var(--muted-dk)}
.wi-v2 .bandtrack{height:14px;border-radius:99px;background:rgba(20,17,28,.10);overflow:hidden}
.wi-v2 .bandfill{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--violet),var(--magenta));
  animation:wiV2Band .9s cubic-bezier(.2,.7,.3,1)}
@keyframes wiV2Band{from{width:0}}
.wi-v2 .bandpct{font-size:1rem;font-variant-numeric:tabular-nums;text-align:end}
.wi-v2 .aggline{font-size:1.08rem;line-height:1.55;margin:22px 0 0}

.wi-v2 .voices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin:34px auto 0;text-align:start}
.wi-v2 .voices blockquote:last-child:nth-child(odd){grid-column:1/-1}
.wi-v2 .voices blockquote{margin:0;background:rgba(13,11,19,.78);border:1px solid rgba(255,255,255,.14);
  border-radius:18px;padding:26px 28px;position:relative;overflow:hidden}
/* The Hebrew gershayim, not a low-9 quote. U+201E sits ON the baseline, so at
   5.4rem it dropped into the middle of the card and collided with the quote it
   was decorating. This glyph hangs from the cap line, which is why the long page
   uses it. */
.wi-v2 .voices blockquote::before{content:"״";position:absolute;top:-14px;inset-inline-start:14px;
  font-size:5.4rem;font-weight:700;color:#F094B0;opacity:.22;line-height:1;pointer-events:none}
.wi-v2 .voices blockquote::after{content:"";position:absolute;inset-inline-start:0;top:0;bottom:0;width:3px;
  background:linear-gradient(180deg,#F094B0,transparent)}
.wi-v2 .voices p{font-size:1.08rem;line-height:1.6;margin:0;position:relative}
.wi-v2 .voices cite{display:block;font-style:normal;font-size:.95rem;color:#F094B0;margin-top:14px;font-weight:600}

.wi-v2 .tract{margin:0 auto;max-width:620px;border-radius:20px;padding:26px 28px;
  background:rgba(255,255,255,.78);border:1px solid rgba(139,96,234,.22);text-align:start}
.wi-v2 .tractrow{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.wi-v2 .tractstat{display:flex;flex-direction:column;gap:5px;align-items:center;text-align:center}
.wi-v2 .tractstat .tn{font-size:clamp(1.4rem,3vw,2rem);font-weight:800;color:var(--magenta);
  line-height:1;font-variant-numeric:tabular-nums}
.wi-v2 .tractstat .tl{font-size:.9rem;color:var(--muted-dk);line-height:1.35}
.wi-v2 .tractquote{margin:22px 0 0;border-inline-start:3px solid var(--magenta);padding-inline-start:16px}
.wi-v2 .tractquote p{font-size:1.08rem;font-weight:600;line-height:1.5;margin:0}
.wi-v2 .tractquote cite{display:block;font-style:normal;font-size:.86rem;color:var(--muted-dk);margin-top:9px}
.wi-v2 .tractlink{display:inline-flex;align-items:center;gap:8px;margin-top:16px;color:var(--magenta);
  font-weight:700;font-size:.98rem;text-decoration:none}
.wi-v2 .tractlink:hover{text-decoration:underline}

.wi-v2 .asktitle{font-size:clamp(1.9rem,4.5vw,3.2rem);font-weight:800;line-height:1.15;margin:0 auto;
  max-width:20ch;text-wrap:balance}
.wi-v2 .anchor{font-size:clamp(1.35rem,2.6vw,1.9rem);font-weight:700;color:#F094B0;margin:24px auto 0;max-width:26ch;line-height:1.35}
.wi-v2 .anchorsub{font-size:1.1rem;color:var(--muted-lt);margin:8px auto 0}
.wi-v2 .grid{display:grid;grid-template-columns:repeat(10,1fr);gap:6px;margin:22px auto 0;max-width:440px}
.wi-v2 .seat{aspect-ratio:1;border-radius:3px;background:rgba(255,255,255,.11);border:1px solid rgba(255,255,255,.13);
  transition:background .28s cubic-bezier(.2,.7,.3,1),box-shadow .28s}
.wi-v2 .seat.on{background:var(--magenta);border-color:var(--magenta);box-shadow:0 0 12px rgba(199,21,90,.55)}
.wi-v2 .plus{font-size:1.1rem;font-weight:700;color:#F094B0;margin:12px 0 0}
.wi-v2 .slider{width:100%;max-width:440px;margin:22px 0 0;accent-color:var(--magenta);cursor:pointer}
.wi-v2 .stops{display:flex;justify-content:space-between;max-width:440px;margin:6px auto 0;
  font-size:.95rem;color:#B4ADBF;font-variant-numeric:tabular-nums}
.wi-v2 .cta{display:block;width:fit-content;margin:30px auto 0;padding:19px 46px;border-radius:999px;
  font-size:1.16rem;font-weight:800;color:#fff;text-decoration:none;
  background:linear-gradient(135deg,var(--magenta),var(--magenta2));transition:filter .25s,transform .25s}
.wi-v2 .cta:hover{filter:brightness(1.08);transform:translateY(-2px)}
.wi-v2 .cta.ghost{margin-top:14px;background:transparent;border:1.5px solid rgba(255,255,255,.4);
  font-size:1.02rem;font-weight:700;padding:15px 34px}
.wi-v2 .cta.ghost:hover{background:rgba(255,255,255,.1)}
.wi-v2 .legal{font-size:.86rem;color:#9F98AB;line-height:1.7;max-width:60ch;margin:28px auto 0}

.wi-v2 .v2src{margin:26px auto 0;max-width:100%;text-align:start}
.wi-v2 .v2src summary{cursor:pointer;font-size:.78rem;letter-spacing:.04em;font-weight:600;
  list-style:none;display:inline-flex;align-items:center;gap:6px;padding:6px 0;opacity:.72}
.wi-v2 .v2src summary::-webkit-details-marker{display:none}
.wi-v2 .v2src summary::after{content:"↓";font-size:.7rem;transition:transform .25s}
.wi-v2 .v2src[open] summary::after{transform:rotate(180deg)}
.wi-v2 .v2src p{font-size:.78rem;line-height:1.65;margin:8px 0 0}
.wi-v2 .v2.dark .v2src summary,.wi-v2 .v2.dark .v2src p{color:#8F8899}
.wi-v2 .v2.light .v2src summary,.wi-v2 .v2.light .v2src p{color:var(--muted-dk)}

.wi-v2 .topbar{position:fixed;top:14px;inset-inline-end:14px;z-index:9;display:flex;gap:8px}
/* Opaque enough to sit over a heading. At .82 the section titles read straight
   through the chips on a phone, where a centred heading passes under them. */
.wi-v2 .chip{padding:11px 17px;border-radius:999px;background:rgba(20,17,28,.94);
  -webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.22);color:var(--text-lt);font-size:.95rem;font-weight:600;
  font-family:inherit;cursor:pointer}
.wi-v2 .chip:hover{background:rgba(40,34,55,.94)}

/* The sticky CTA never covers the ask it points at, and on a phone it sits
   above the safe-area inset so it cannot land under the home indicator. */
.wi-v2 .sticky{position:fixed;z-index:8;inset-inline-end:18px;
  bottom:calc(18px + env(safe-area-inset-bottom,0px));
  display:inline-flex;align-items:center;gap:8px;padding:15px 28px;border-radius:999px;
  background:linear-gradient(135deg,var(--magenta),var(--magenta2));color:#fff;text-decoration:none;
  font-weight:800;font-size:1rem;box-shadow:0 14px 40px rgba(199,21,90,.45);
  opacity:0;transform:translateY(16px);pointer-events:none;
  transition:opacity .35s cubic-bezier(.2,.7,.3,1),transform .35s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .sticky.on{opacity:1;transform:none;pointer-events:auto}

.wi-v2 [data-reveal]>*{opacity:0;transform:translateY(16px);
  transition:opacity .6s cubic-bezier(.2,.7,.3,1),transform .6s cubic-bezier(.2,.7,.3,1)}
.wi-v2 [data-reveal].on>*{opacity:1;transform:none}
.wi-v2 [data-reveal]>*:nth-child(2){transition-delay:.1s}
.wi-v2 [data-reveal]>*:nth-child(3){transition-delay:.2s}
.wi-v2 [data-reveal]>*:nth-child(4){transition-delay:.3s}
.wi-v2 :focus-visible{outline:2px solid var(--magenta);outline-offset:4px;border-radius:6px}

@media (prefers-reduced-motion:reduce){
  .wi-v2 .cue i{animation:none}
  .wi-v2 .sticky,.wi-v2 .seat{transition:none}
  .wi-v2 [data-reveal]>*{transition:none;opacity:1;transform:none}
  .wi-v2 .agg,.wi-v2 .bandfill{animation:none}
}
@media (max-width:760px){
  .wi-v2 .tiles{grid-template-columns:repeat(2,1fr)}
}
@media (max-width:640px){
  .wi-v2 .topbar{top:10px;inset-inline-end:10px}
  .wi-v2 .chip{padding:9px 13px;font-size:.86rem}
  .wi-v2 .voices{grid-template-columns:1fr}
  .wi-v2 .voices blockquote:last-child:nth-child(odd){grid-column:auto}
  .wi-v2 .grid{gap:5px;max-width:330px}
  .wi-v2 .agg{padding:20px 16px}
  .wi-v2 .band{grid-template-columns:7ch 1fr 4ch;gap:8px}
  .wi-v2 .tractrow{grid-template-columns:1fr;gap:16px}
  .wi-v2 .hourgrid{grid-template-columns:repeat(14,1fr);gap:3px}
  .wi-v2 .field{height:clamp(230px,30vh,300px);margin-top:22px}
  .wi-v2 .field.fam{width:min(340px,84vw);height:200px}
  .wi-v2 .sticky{inset-inline:14px;justify-content:center;font-size:.96rem;padding:14px 20px}
  .wi-v2 .cta{width:100%;padding:17px 22px;font-size:1.05rem}
}
`;export{je as default};
