import{ae as o}from"./index-CeRA1y7S.js";async function e(n){await o(n)}function i(n){return a=>{a.preventDefault(),e(n)}}export{e as a,i as o};
