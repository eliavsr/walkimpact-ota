import{r as i,j as X}from"./ui-vendor-BeC9_MVI.js";import{m as T}from"./maplibre-vendor-p_PJaFjI.js";import{y as $}from"./index-BFqTIuCy.js";import"./data-vendor-BtMj5tE1.js";const Ee="https://tiles.openfreemap.org/styles/liberty",ee=["coalesce",["get","render_height"],8],ke=["interpolate",["linear"],ee,0,"#DCCCEA",12,"#CDB8E0",30,"#B99FD4",60,"#A386C7",120,"#8E6DB8"],ve=l=>/^poi/i.test(l),he=[[0,4,3],[.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,.5],[3,4,0],[0,.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,.5]];let O=null;function Te(){if(O!==null)return O;try{const l=document.createElement("canvas");O=!!(window.WebGLRenderingContext&&(l.getContext("webgl")||l.getContext("experimental-webgl")))}catch{O=!1}return O}function Le([l,y],[x,L]){const g=R=>R*Math.PI/180,I=R=>R*180/Math.PI,D=g(L-y),z=Math.sin(D)*Math.cos(g(x)),E=Math.cos(g(l))*Math.sin(g(x))-Math.sin(g(l))*Math.cos(g(x))*Math.cos(D);return(I(Math.atan2(z,E))+360)%360}function Re(l,y){return((y-l)%360+540)%360-180}function De({center:l,routePoints:y=[],routeCoords:x=[],destination:L=null,stops:g=[],routeNodes:I=[],onStopTap:D,onStopSlots:z,introFlyIn:E=!1,follow:R=!0,zoom:M=17.5,pitch:A=55,cameraOffset:te=null,trailColor:fe=$.teal,routeColor:ye=$.indigo,frameRoute:ne=!0,reduced:k=!1,onUserPan:re,onMoveEnd:oe,onCamera:ie,onFallback:ae}){const[J,me]=i.useState(!1),j=i.useRef(null),d=i.useRef(null),v=i.useRef(!1),Q=i.useRef(0),H=i.useRef(null),G=i.useRef(null),S=i.useRef(null),F=i.useRef([]),C=i.useRef([]),p=i.useRef(ae),u=i.useRef(re),_=i.useRef(D),P=i.useRef(z),Y=i.useRef(oe),U=i.useRef(ie);U.current=ie,p.current=ae,u.current=re,_.current=D,P.current=z,Y.current=oe,i.useEffect(()=>{var B,q,b,se,ce,le;if(!j.current||d.current)return;if(!Te()){(B=p.current)==null||B.call(p);return}try{((b=(q=T).getRTLTextPluginStatus)==null?void 0:b.call(q))==="unavailable"&&T.setRTLTextPlugin("https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.2.3/mapbox-gl-rtl-text.min.js",!0)}catch{}let e;try{e=new T.Map({container:j.current,style:Ee,center:l?[l[1],l[0]]:[34.78,32.08],zoom:M,pitch:A,bearing:0,attributionControl:!1,antialias:!1,fadeDuration:0})}catch{(se=p.current)==null||se.call(p);return}d.current=e,e.on("error",o=>{var a,f;(a=o==null?void 0:o.error)!=null&&a.message&&/webgl|context/i.test(o.error.message)&&((f=p.current)==null||f.call(p))});const n=o=>{var a;o!=null&&o.originalEvent&&((a=u.current)==null||a.call(u))};e.on("dragstart",n),e.on("rotatestart",n),e.on("zoomstart",n),e.on("moveend",()=>{var o;try{const a=e.getCenter();(o=Y.current)==null||o.call(Y,[a.lat,a.lng])}catch{}}),e.on("click",o=>{var a,f;try{const N=o.point,K=V.current||[];let r=null,c=1/0;if(K.forEach(w=>{if(typeof(w==null?void 0:w.lat)!="number"||typeof(w==null?void 0:w.lon)!="number"||w.kind==="ghost")return;const pe=e.project([w.lon,w.lat]),ue=Math.hypot(pe.x-N.x,pe.y-N.y);ue<c&&(c=ue,r=w)}),!r)return;const we=r.state==="today"?34:r.kind==="back"||r.kind==="coin"?28:24;if(c>we)return;const de=e.project([r.lon,r.lat]),Z=(a=j.current)==null?void 0:a.getBoundingClientRect(),W=r.state==="today"?52:30,xe=Z?{left:Z.left+de.x-W/2,top:Z.top+de.y-W/2,width:W,height:W}:null;(f=_.current)==null||f.call(_,r,xe)}catch{}}),e.on("load",()=>{var f,N,K;v.current=!0;try{(f=U.current)==null||f.call(U,{zoomBy:r=>{var c;try{(c=u.current)==null||c.call(u),e.easeTo({zoom:Math.min(19.5,Math.max(13,e.getZoom()+r)),duration:320})}catch{}},tiltBy:r=>{var c;try{(c=u.current)==null||c.call(u),e.easeTo({pitch:Math.min(70,Math.max(0,e.getPitch()+r)),duration:320})}catch{}},turnBy:r=>{var c;try{(c=u.current)==null||c.call(u),e.easeTo({bearing:e.getBearing()+r,duration:320})}catch{}},reset:()=>{try{e.easeTo({pitch:A,bearing:0,zoom:M,duration:420})}catch{}}})}catch{}if(me(!0),E)try{e.jumpTo({zoom:Math.max(13,M-2.2),pitch:Math.max(0,A-22)}),setTimeout(()=>{try{e.easeTo({zoom:M,pitch:A,duration:4500})}catch{}},2800)}catch{}try{(N=e.setSky)==null||N.call(e,{"sky-color":"#BFDBF5","horizon-color":"#F6E9F0","fog-color":"#EFE7F5","sky-horizon-blend":.5,"horizon-fog-blend":.35,"fog-ground-blend":.08})}catch{}try{const r=(K=e.getStyle().layers.find(c=>c.type==="symbol"))==null?void 0:K.id;e.addLayer({id:"wi-buildings-3d",source:"openmaptiles","source-layer":"building",type:"fill-extrusion",minzoom:14,filter:["!=",["get","hide_3d"],!0],paint:{"fill-extrusion-color":ke,"fill-extrusion-base":["coalesce",["get","render_min_height"],0],"fill-extrusion-opacity":.82,"fill-extrusion-vertical-gradient":!0,"fill-extrusion-height":k?ee:0,"fill-extrusion-height-transition":{duration:1400,delay:0}}},r),k||setTimeout(()=>{var c;try{(c=d.current)==null||c.setPaintProperty("wi-buildings-3d","fill-extrusion-height",ee)}catch{}},220)}catch{}try{e.getStyle().layers.filter(r=>r.type==="symbol"&&ve(r.id)).forEach(r=>{try{e.setLayoutProperty(r.id,"visibility","none")}catch{}})}catch{}const o=E?6.5:1,a=E?.8:1;try{e.addSource("wi-trail",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-trail-casing",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*o,"line-opacity":.45*a}}),e.addLayer({id:"wi-trail-line",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":fe,"line-width":10*o,"line-opacity":.92*a}}),e.addSource("wi-route",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-route-casing",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":12*o,"line-opacity":.5*a}}),e.addLayer({id:"wi-route-line",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":ye,"line-width":8*o,"line-opacity":.95*a}}),e.addLayer({id:"wi-route-flow",type:"line",source:"wi-route",layout:{"line-cap":"butt","line-join":"round"},paint:{"line-color":"#FFFFFF","line-width":E?3:3.4,"line-opacity":E?.28:.9,"line-dasharray":[0,4,3]}})}catch{}if(!k)if(H.current=setInterval(()=>{if(!d.current||!v.current)return;const r=Date.now()%7e3/7e3,c=.55+.4*(.5-Math.cos(r*2*Math.PI)/2);try{d.current.setPaintProperty("wi-trail-line","line-opacity",c)}catch{}},120),E)try{d.current.setPaintProperty("wi-route-flow","line-dasharray",[2,3])}catch{}else{let r=0;G.current=setInterval(()=>{if(!(!d.current||!v.current)){r=(r+1)%he.length;try{d.current.setPaintProperty("wi-route-flow","line-dasharray",he[r])}catch{}}},90)}});const s=typeof ResizeObserver<"u"?new ResizeObserver(()=>{try{e.resize()}catch{}}):null;try{s&&j.current&&s.observe(j.current)}catch{}const h=requestAnimationFrame(()=>{try{e.resize()}catch{}}),t=(ce=e.getCanvas)==null?void 0:ce.call(e),m=o=>{var a,f;(a=o.preventDefault)==null||a.call(o),(f=p.current)==null||f.call(p)};return(le=t==null?void 0:t.addEventListener)==null||le.call(t,"webglcontextlost",m),()=>{var o,a;cancelAnimationFrame(h);try{s==null||s.disconnect()}catch{}H.current&&clearInterval(H.current),G.current&&clearInterval(G.current),H.current=null,G.current=null,(o=t==null?void 0:t.removeEventListener)==null||o.call(t,"webglcontextlost",m);try{(a=S.current)==null||a.remove()}catch{}S.current=null,F.current.forEach(f=>{try{f.remove()}catch{}}),F.current=[],v.current=!1;try{e.remove()}catch{}d.current=null}},[]),i.useEffect(()=>{const e=d.current;if(!(!e||!l||!R)){if(y.length>=2){const n=Le(y[y.length-2],y[y.length-1]);Q.current+=Re(Q.current,n)*.18}try{e.easeTo({center:[l[1],l[0]],bearing:Q.current,pitch:A,zoom:M,offset:te||[0,0],duration:k?0:900,essential:!0})}catch{}}},[l,y,R,k,M,A,te]),i.useEffect(()=>{const e=d.current;if(!(!e||!v.current||!ne||x.length<2))try{const n=new T.LngLatBounds;x.forEach(([s,h])=>n.extend([h,s])),e.fitBounds(n,{padding:{top:150,bottom:230,left:60,right:60},pitch:40,bearing:0,duration:k?0:1500,essential:!0})}catch{}},[x,k,ne]),i.useEffect(()=>{var n;const e=d.current;if(e){try{(n=S.current)==null||n.remove()}catch{}if(S.current=null,!!L)try{const s=document.createElement("div");s.className="wi-dest-pin",s.innerHTML='<span class="wi-dest-ring"></span><span class="wi-dest-dot"></span>',S.current=new T.Marker({element:s,anchor:"center"}).setLngLat([L.lon,L.lat]).addTo(e)}catch{}}},[L]);const ge=I.map(e=>`${e.id}|${e.done?1:0}`).join("~");i.useEffect(()=>{const e=d.current;if(e)return C.current.forEach(n=>{try{n.remove()}catch{}}),C.current=[],I.forEach(n=>{try{const s=n.kind==="coin"?"#f59e0b":"#14b8a6",h=document.createElement("div");h.style.cssText=`width:${n.done?12:20}px;height:${n.done?12:20}px;border-radius:50%;background:${s};border:3px solid #fff;box-shadow:0 2px 8px rgba(26,20,38,.28);opacity:${n.done?.35:1};`;const t=new T.Marker({element:h,anchor:"center"}).setLngLat([n.lon,n.lat]).addTo(e);C.current.push(t)}catch{}}),()=>{C.current.forEach(n=>{try{n.remove()}catch{}}),C.current=[]}},[ge]);const be=g.map(e=>`${e.id}|${e.lat}|${e.lon}|${e.state}|${e.done?1:0}|${e.color}|${e.icon}|${e.caption}`).join("~"),V=i.useRef(g);return V.current=g,i.useEffect(()=>{var h;const e=d.current;if(!e)return;const n=V.current;F.current.forEach(t=>{try{t.remove()}catch{}}),F.current=[];const s=[];n.forEach(t=>{if(!(typeof(t==null?void 0:t.lat)!="number"||typeof(t==null?void 0:t.lon)!="number"))try{const m=document.createElement("button");m.type="button",m.className=`wi-stop wi-stop--${t.state||"ahead"}${t.done?" wi-stop--complete":""}`,m.style.setProperty("--wi-stop",t.color||$.teal),m.setAttribute("aria-label",t.label||"");const B=document.createElement("span");if(B.className="wi-stop-slot",m.appendChild(B),t.done){const b=document.createElement("span");b.className="wi-stop-check",b.textContent="✓",m.appendChild(b)}if(t.caption){const b=document.createElement("span");b.className=`wi-stop-cap${t.capAbove?" wi-stop-cap--above":""}`,b.textContent=t.caption,m.appendChild(b)}const q=new T.Marker({element:m,anchor:"center"}).setLngLat([t.lon,t.lat]).addTo(e);F.current.push(q),s.push({id:t.id,el:B})}catch{}}),(h=P.current)==null||h.call(P,s)},[be,J]),i.useEffect(()=>{var n;const e=d.current;if(!(!e||!v.current))try{(n=e.getSource("wi-trail"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:y.map(([s,h])=>[h,s])}})}catch{}},[y,J]),i.useEffect(()=>{var n;const e=d.current;if(!(!e||!v.current))try{(n=e.getSource("wi-route"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:x.map(([s,h])=>[h,s])}})}catch{}},[x,J]),X.jsxs(X.Fragment,{children:[X.jsx("style",{children:`
        /* ⚠️⚠️ THE RTL TRAP — READ BEFORE TOUCHING ANY MARKER RULE.
           MapLibre's own stylesheet pins every marker with
           .maplibregl-marker { position:absolute; top:0; left:0 } and then
           writes the ground position into an inline transform. Our rules below
           are a single class too, and they load LAST — so declaring
           position:relative here silently beat MapLibre's absolute, dropped the
           marker back into normal flow, and in an RTL document normal flow
           starts at the RIGHT EDGE. The inline transform then offset it from
           there, pushing every stop roughly a screen-width off to the side.
           Measured: container 0..1850, inline translate(925px) — and the marker
           landed at x=2697. That is the whole of "the journey is somewhere on
           the map I have to go looking for": her road was literally rendered
           off the edge of the screen.
           Keep position:absolute + top:0 + left:0 on anything MapLibre mounts as
           a marker. top is still animatable (the bob uses it) because an
           absolutely positioned box honours top just the same. */
        .wi-dest-pin { position: absolute; top: 0; left: 0; width: 26px; height: 26px; }
        .wi-dest-dot { position:absolute; inset:7px; border-radius:50%;
          background:${$.indigo}; border:2.5px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .wi-dest-ring { position:absolute; inset:0; border-radius:50%;
          background:${$.indigo}; opacity:.35; animation: wiDestPulse 1.9s ease-out infinite; }
        @keyframes wiDestPulse {
          0% { transform: scale(.55); opacity:.55; }
          70% { transform: scale(1.5); opacity:0; }
          100% { transform: scale(1.5); opacity:0; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-dest-ring { animation: none; } }

        /* Journey stops standing in the world. Sized by their moment: the day's
           step is the one that draws the eye, the past is quiet, ahead is faint. */
        /* ⚠️⚠️ NOTHING HERE MAY ANIMATE OR SET transform ON .wi-stop ITSELF.
           MapLibre positions a marker by writing an inline transform onto this
           exact element (translate(-50%,-50%) translate(Xpx,Ypx)), and any CSS
           animation or rule that also sets transform REPLACES that — the
           marker snaps to the container's top-left corner and stops following
           the ground.
           That is precisely what happened to TODAY'S stop: the bob animation
           below used to animate transform, so the single most important thing
           on the screen rendered at (0,-1) — off in the corner — while every
           other stop sat correctly on the road. Measured, not guessed:
           computedTransform matrix(1,0,0,1,0,-1) against an inline
           translate(187.5px,340px). It reads exactly like "the journey is
           somewhere on the map you have to go looking for".
           The bob now animates top (this element is position:relative, so that
           moves it visually and touches no transform), and the press uses the
           standalone scale property, which composes with transform instead of
           overwriting it. */
        .wi-stop { -webkit-appearance:none; appearance:none; padding:0; cursor:pointer;
          position:absolute; top:0; left:0;   /* ⚠️ see THE RTL TRAP above */
          border-radius:50%; background:#fff; border:2.5px solid var(--wi-stop);
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 3px 10px rgba(40,25,70,.35); transition:scale .18s ease; }

        /* The road remembers. Every stop she finished carries a soft bloom in
           its own domain colour, so the path behind her is visibly warmer than
           the path ahead — presence left on the ground rather than a number in
           a corner. Drawn behind the marker and never interactive. */
        /* A finished day stops asking for attention: the bob is dropped and a
           check rides the marker, so the work she did is visible ON the road. */
        .wi-stop--complete { animation:none !important; }
        .wi-stop-check { position:absolute; right:-3px; bottom:-3px; width:20px; height:20px;
          border-radius:50%; background:#2E9E6B; border:2.5px solid #fff; color:#fff;
          font-size:11px; font-weight:900; line-height:1;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 2px 6px rgba(40,25,70,.4); pointer-events:none; }

        .wi-stop--done::after, .wi-stop--complete::after {
          content:''; position:absolute; inset:-11px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, var(--wi-stop) 0%, transparent 70%);
          opacity:.34; pointer-events:none;
          animation: wiBloom 6s ease-in-out infinite;
        }
        @keyframes wiBloom {
          0%,100% { transform: scale(1);    opacity:.30; }
          50%     { transform: scale(1.14); opacity:.42; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--done::after { animation:none; } }
        .wi-stop:active { scale:.9; }
        /* ⚠️ HIT SLOP, NOT A BIGGER BUTTON. A finished stop is 30px and a
           locked one 28px — well under the 44px a thumb needs — so taps that
           looked like they landed on a stop landed on the map instead, and the
           card "did not open". The circle keeps its size; only the target
           grows, behind it, invisible. */
        .wi-stop::before { content:''; position:absolute; inset:-9px; border-radius:50%; }
        .wi-stop-slot { display:flex; align-items:center; justify-content:center; line-height:0; }
        /* Sits under the circle, reads over any ground the map puts behind it. */
        /* Dark ink inside a white halo, NOT white text: the ground under these
           labels is a pale lavender city, and white-on-pale left "אתמול · היום ·
           מחר" barely there — the one thing that tells her which way her own
           road runs. */
        .wi-stop-cap { position:absolute; top:100%; margin-top:7px; left:50%;
          transform:translateX(-50%); white-space:nowrap; pointer-events:none;
          font-size:11.5px; font-weight:900; color:#241C3A; letter-spacing:.01em;
          /* A solid light pill so the label reads on ANY surface — the pale map OR
             the dark purple road. Dark text over a white glow alone vanished on the
             road (looked white/unreadable). */
          background:rgba(255,255,255,0.94); padding:2px 9px; border-radius:999px;
          box-shadow:0 1px 5px rgba(26,20,38,0.18); text-shadow:none; }
        /* Future captions (מחר) sit ABOVE their circle so a small node's label
           never lands on the big today node just below it. */
        .wi-stop-cap--above { top:auto; bottom:100%; margin-top:0; margin-bottom:7px; }

        /* ── The road back, and the ghost of what is still folded away ──
           The journey card's own two nodes, planted on the map: a neutral 42px
           circle carrying the arrow, and one faint dashed node behind it so the
           road never looks like it ends. Same sizes, same weights, same colours
           as JourneyHeroCard — they are the same control, on a different
           surface. */
        /* Her coin, waiting on the road. No border and no white plate — it is
           an object lying there, not another station. */
        .wi-stop--coin  { width:44px; height:44px; background:transparent; border:none;
                          box-shadow:none; }
        .wi-stop--coin::after {
          content:''; position:absolute; inset:-10px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, #8B60EA 0%, transparent 70%);
          opacity:.42; pointer-events:none; animation: wiBloom 3.4s ease-in-out infinite;
        }
        .wi-stop--back  { width:42px; height:42px; background:#F1EEF6; border:2px solid #E3DCEF;
                          box-shadow:0 3px 10px rgba(40,25,70,.22); }
        .wi-stop--ghost { width:36px; height:36px; background:#F1EEF6; border:2px dashed #E3DCEF;
                          opacity:.42; pointer-events:none; box-shadow:none; }
        .wi-stop--done   { width:30px; height:30px; opacity:.9; }
        .wi-stop--ahead  { width:28px; height:28px; opacity:.6; border-style:dashed; }
        .wi-stop--locked { width:28px; height:28px; opacity:.5; border-style:dashed; }
        .wi-stop--today  { width:70px; height:70px; border-width:5px;
          box-shadow:0 0 0 9px color-mix(in srgb, var(--wi-stop) 22%, transparent), 0 8px 22px rgba(40,25,70,.4);
          animation: wiStopBob 2.1s ease-in-out infinite; }
        .wi-stop--today .wi-stop-core { width:24px; height:24px; }
        @keyframes wiStopBob {
          0%,100% { top: 0; }
          50%     { top: -5px; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--today { animation:none; } }
      `}),X.jsx("div",{ref:j,style:{width:"100%",height:"100%"}})]})}export{De as default,Te as isWebGLAvailable};
