function r(n){return n==null?"":`⁨${n}⁩`}function t(n){return n==null?"":`⁦${n}⁩`}export{r as i,t as l};
