function r(t){let n=0;for(let a=0;a<(t||"").length;a++)n=Math.imul(31,n)+t.charCodeAt(a)|0;return Math.abs(n).toString(36).slice(0,10)}function h(t){return t?r(t):null}export{h as a,r as h};
