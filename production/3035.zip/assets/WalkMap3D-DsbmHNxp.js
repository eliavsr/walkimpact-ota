import{r as s,j as re}from"./ui-vendor-C2vz56HF.js";import{m as F}from"./maplibre-vendor-Dv0jWwdn.js";import{y as Y}from"./index-C6i4OyGT.js";import"./data-vendor-B0a1ptKG.js";const Le="https://tiles.openfreemap.org/styles/liberty",ce=["coalesce",["get","render_height"],8],Te=["interpolate",["linear"],ce,0,"#DCCCEA",12,"#CDB8E0",30,"#B99FD4",60,"#A386C7",120,"#8E6DB8"],Me=t=>/^poi/i.test(t),be=[[0,4,3],[.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,.5],[3,4,0],[0,.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,.5]];let K=null;function Ae(){if(K!==null)return K;try{const t=document.createElement("canvas");K=!!(window.WebGLRenderingContext&&(t.getContext("webgl")||t.getContext("experimental-webgl")))}catch{K=!1}return K}function le([t,a],[d,f]){const u=g=>g*Math.PI/180,b=g=>g*180/Math.PI,p=u(f-a),k=Math.sin(p)*Math.cos(u(d)),v=Math.cos(u(t))*Math.sin(u(d))-Math.sin(u(t))*Math.cos(u(d))*Math.cos(p);return(b(Math.atan2(k,v))+360)%360}function Re(t,a){return((a-t)%360+540)%360-180}function se([t,a],[d,f]){const u=(d-t)*111320,b=(f-a)*111320*Math.cos(t*Math.PI/180);return Math.hypot(b,u)}const Se=30;function De(t,a){if(!Array.isArray(t)||t.length<2||!a)return a;const d=111320,f=111320*Math.cos(a[0]*Math.PI/180),u=a[1]*f,b=a[0]*d;let p=null,k=1/0;for(let v=0;v<t.length-1;v++){const g=t[v][1]*f,I=t[v][0]*d,R=t[v+1][1]*f,S=t[v+1][0]*d,j=R-g,N=S-I,q=j*j+N*N;if(!q)continue;let B=((u-g)*j+(b-I)*N)/q;B=Math.max(0,Math.min(1,B));const T=g+B*j,z=I+B*N,H=Math.hypot(u-T,b-z);H<k&&(k=H,p=[z/d,T/f])}return p&&k<=Se?p:a}const je=35;function Be(t,a){if(!Array.isArray(t)||t.length<2||!a)return null;let d=0,f=1/0;for(let p=0;p<t.length;p++){const k=se(a,t[p]);k<f&&(f=k,d=p)}if(f>120)return null;let u=0;for(let p=d;p<t.length-1;p++)if(u+=se(t[p],t[p+1]),u>=je)return le(a,t[p+1]);const b=t[t.length-1];return se(a,b)>5?le(a,b):null}function $e({center:t,routePoints:a=[],routeCoords:d=[],roadBehind:f=[],destination:u=null,stops:b=[],routeNodes:p=[],onStopTap:k,onStopSlots:v,introFlyIn:g=!1,follow:I=!0,zoom:R=17.5,pitch:S=55,cameraOffset:j=null,trailColor:N=Y.teal,routeColor:q=Y.indigo,frameRoute:B=!0,reduced:T=!1,onUserPan:z,onMoveEnd:H,onCamera:de,onFallback:pe}){const[C,we]=s.useState(!1),O=s.useRef(null),y=s.useRef(null),D=s.useRef(!1),oe=s.useRef(0),W=s.useRef(null),X=s.useRef(null),_=s.useRef(null),P=s.useRef([]),G=s.useRef([]),w=s.useRef(pe),x=s.useRef(z),J=s.useRef(k),Q=s.useRef(v),V=s.useRef(H),Z=s.useRef(de);Z.current=de,w.current=pe,x.current=z,J.current=k,Q.current=v,V.current=H,s.useEffect(()=>{var $,ee,M,ue,he,ye;if(!O.current||y.current)return;if(!Ae()){($=w.current)==null||$.call(w);return}try{((M=(ee=F).getRTLTextPluginStatus)==null?void 0:M.call(ee))==="unavailable"&&F.setRTLTextPlugin("https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.2.3/mapbox-gl-rtl-text.min.js",!0)}catch{}let e;try{e=new F.Map({container:O.current,style:Le,center:t?[t[1],t[0]]:[34.78,32.08],zoom:R,pitch:S,bearing:0,attributionControl:!1,antialias:!1,fadeDuration:0})}catch{(ue=w.current)==null||ue.call(w);return}y.current=e,e.on("error",i=>{var l,E;(l=i==null?void 0:i.error)!=null&&l.message&&/webgl|context/i.test(i.error.message)&&((E=w.current)==null||E.call(w))});const n=i=>{var l;i!=null&&i.originalEvent&&((l=x.current)==null||l.call(x))};e.on("dragstart",n),e.on("rotatestart",n),e.on("zoomstart",n),e.on("moveend",()=>{var i;try{const l=e.getCenter();(i=V.current)==null||i.call(V,[l.lat,l.lng])}catch{}}),e.on("click",i=>{var l,E;try{const U=i.point,te=ae.current||[];let o=null,h=1/0;if(te.forEach(A=>{if(typeof(A==null?void 0:A.lat)!="number"||typeof(A==null?void 0:A.lon)!="number"||A.kind==="ghost")return;const me=e.project([A.lon,A.lat]),ge=Math.hypot(me.x-U.x,me.y-U.y);ge<h&&(h=ge,o=A)}),!o)return;const ke=o.state==="today"?34:o.kind==="back"||o.kind==="coin"?28:24;if(h>ke)return;const fe=e.project([o.lon,o.lat]),ie=(l=O.current)==null?void 0:l.getBoundingClientRect(),ne=o.state==="today"?52:30,ve=ie?{left:ie.left+fe.x-ne/2,top:ie.top+fe.y-ne/2,width:ne,height:ne}:null;(E=J.current)==null||E.call(J,o,ve)}catch{}}),e.on("load",()=>{var E,U,te;D.current=!0;try{(E=Z.current)==null||E.call(Z,{zoomBy:o=>{var h;try{(h=x.current)==null||h.call(x),e.easeTo({zoom:Math.min(19.5,Math.max(13,e.getZoom()+o)),duration:320})}catch{}},tiltBy:o=>{var h;try{(h=x.current)==null||h.call(x),e.easeTo({pitch:Math.min(70,Math.max(0,e.getPitch()+o)),duration:320})}catch{}},turnBy:o=>{var h;try{(h=x.current)==null||h.call(x),e.easeTo({bearing:e.getBearing()+o,duration:320})}catch{}},reset:()=>{try{e.easeTo({pitch:S,bearing:0,zoom:R,duration:420})}catch{}}})}catch{}if(we(!0),g)try{e.jumpTo({zoom:Math.max(13,R-2.2),pitch:Math.max(0,S-22)}),setTimeout(()=>{try{e.easeTo({zoom:R,pitch:S,duration:4500})}catch{}},2800)}catch{}try{(U=e.setSky)==null||U.call(e,{"sky-color":"#BFDBF5","horizon-color":"#F6E9F0","fog-color":"#EFE7F5","sky-horizon-blend":.5,"horizon-fog-blend":.35,"fog-ground-blend":.08})}catch{}try{const o=(te=e.getStyle().layers.find(h=>h.type==="symbol"))==null?void 0:te.id;e.addLayer({id:"wi-buildings-3d",source:"openmaptiles","source-layer":"building",type:"fill-extrusion",minzoom:14,filter:["!=",["get","hide_3d"],!0],paint:{"fill-extrusion-color":Te,"fill-extrusion-base":["coalesce",["get","render_min_height"],0],"fill-extrusion-opacity":.82,"fill-extrusion-vertical-gradient":!0,"fill-extrusion-height":T?ce:0,"fill-extrusion-height-transition":{duration:1400,delay:0}}},o),T||setTimeout(()=>{var h;try{(h=y.current)==null||h.setPaintProperty("wi-buildings-3d","fill-extrusion-height",ce)}catch{}},220)}catch{}try{e.getStyle().layers.filter(o=>o.type==="symbol"&&Me(o.id)).forEach(o=>{try{e.setLayoutProperty(o.id,"visibility","none")}catch{}})}catch{}const i=g?6.5:1,l=g?.8:1;try{e.addSource("wi-road-back",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-road-back-casing",type:"line",source:"wi-road-back",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*i,"line-opacity":.34*l}}),e.addLayer({id:"wi-road-back-line",type:"line",source:"wi-road-back",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#6E5C93","line-width":10*i,"line-opacity":.55*l}}),e.addSource("wi-trail",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-trail-casing",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*i,"line-opacity":.45*l}}),e.addLayer({id:"wi-trail-line",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":N,"line-width":10*i,"line-opacity":.92*l}}),e.addSource("wi-route",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-route-casing",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":12*i,"line-opacity":.5*l}}),e.addLayer({id:"wi-route-line",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":q,"line-width":8*i,"line-opacity":.95*l}}),e.addLayer({id:"wi-route-flow",type:"line",source:"wi-route",layout:{"line-cap":"butt","line-join":"round"},paint:{"line-color":"#FFFFFF","line-width":g?3:3.4,"line-opacity":g?.28:.9,"line-dasharray":[0,4,3]}})}catch{}if(!T)if(W.current=setInterval(()=>{if(!y.current||!D.current)return;const o=Date.now()%7e3/7e3,h=.55+.4*(.5-Math.cos(o*2*Math.PI)/2);try{y.current.setPaintProperty("wi-trail-line","line-opacity",h)}catch{}},120),g)try{y.current.setPaintProperty("wi-route-flow","line-dasharray",[2,3])}catch{}else{let o=0;X.current=setInterval(()=>{if(!(!y.current||!D.current)){o=(o+1)%be.length;try{y.current.setPaintProperty("wi-route-flow","line-dasharray",be[o])}catch{}}},90)}});const c=typeof ResizeObserver<"u"?new ResizeObserver(()=>{try{e.resize()}catch{}}):null;try{c&&O.current&&c.observe(O.current)}catch{}const m=requestAnimationFrame(()=>{try{e.resize()}catch{}}),r=(he=e.getCanvas)==null?void 0:he.call(e),L=i=>{var l,E;(l=i.preventDefault)==null||l.call(i),(E=w.current)==null||E.call(w)};return(ye=r==null?void 0:r.addEventListener)==null||ye.call(r,"webglcontextlost",L),()=>{var i,l;cancelAnimationFrame(m);try{c==null||c.disconnect()}catch{}W.current&&clearInterval(W.current),X.current&&clearInterval(X.current),W.current=null,X.current=null,(i=r==null?void 0:r.removeEventListener)==null||i.call(r,"webglcontextlost",L);try{(l=_.current)==null||l.remove()}catch{}_.current=null,P.current.forEach(E=>{try{E.remove()}catch{}}),P.current=[],D.current=!1;try{e.remove()}catch{}y.current=null}},[]),s.useEffect(()=>{const e=y.current;if(!e||!t||!I)return;const n=Be(d,t)??(a.length>=2?le(a[a.length-2],a[a.length-1]):null);n!=null&&(oe.current+=Re(oe.current,n)*.18);const c=De(d,t);try{e.easeTo({center:[c[1],c[0]],bearing:oe.current,pitch:S,zoom:R,offset:j||[0,0],duration:T?0:900,essential:!0})}catch{}},[t,a,d,I,T,R,S,j]),s.useEffect(()=>{const e=y.current;if(!(!e||!D.current||!B||d.length<2))try{const n=new F.LngLatBounds;d.forEach(([c,m])=>n.extend([m,c])),e.fitBounds(n,{padding:{top:150,bottom:230,left:60,right:60},pitch:40,bearing:0,duration:T?0:1500,essential:!0})}catch{}},[d,T,B]),s.useEffect(()=>{var n;const e=y.current;if(e){try{(n=_.current)==null||n.remove()}catch{}if(_.current=null,!!u)try{const c=document.createElement("div");c.className="wi-dest-pin",c.innerHTML='<span class="wi-dest-ring"></span><span class="wi-dest-dot"></span>',_.current=new F.Marker({element:c,anchor:"center"}).setLngLat([u.lon,u.lat]).addTo(e)}catch{}}},[u]);const xe=p.map(e=>`${e.id}|${e.done?1:0}`).join("~");s.useEffect(()=>{const e=y.current;if(e)return G.current.forEach(n=>{try{n.remove()}catch{}}),G.current=[],p.forEach(n=>{try{const c=n.kind==="coin"?"#f59e0b":"#14b8a6",m=document.createElement("div");m.style.cssText=`width:${n.done?12:20}px;height:${n.done?12:20}px;border-radius:50%;background:${c};border:3px solid #fff;box-shadow:0 2px 8px rgba(26,20,38,.28);opacity:${n.done?.35:1};`;const r=new F.Marker({element:m,anchor:"center"}).setLngLat([n.lon,n.lat]).addTo(e);G.current.push(r)}catch{}}),()=>{G.current.forEach(n=>{try{n.remove()}catch{}}),G.current=[]}},[xe]);const Ee=b.map(e=>`${e.id}|${e.lat}|${e.lon}|${e.state}|${e.done?1:0}|${e.color}|${e.icon}|${e.caption}`).join("~"),ae=s.useRef(b);return ae.current=b,s.useEffect(()=>{var m;const e=y.current;if(!e)return;const n=ae.current;P.current.forEach(r=>{try{r.remove()}catch{}}),P.current=[];const c=[];n.forEach(r=>{if(!(typeof(r==null?void 0:r.lat)!="number"||typeof(r==null?void 0:r.lon)!="number"))try{const L=document.createElement("button");L.type="button",L.className=`wi-stop wi-stop--${r.state||"ahead"}${r.done?" wi-stop--complete":""}`,L.style.setProperty("--wi-stop",r.color||Y.teal),L.setAttribute("aria-label",r.label||"");const $=document.createElement("span");if($.className="wi-stop-slot",L.appendChild($),r.done){const M=document.createElement("span");M.className="wi-stop-check",M.textContent="✓",L.appendChild(M)}if(r.caption){const M=document.createElement("span");M.className=`wi-stop-cap${r.capAbove?" wi-stop-cap--above":""}`,M.textContent=r.caption,L.appendChild(M)}const ee=new F.Marker({element:L,anchor:"center"}).setLngLat([r.lon,r.lat]).addTo(e);P.current.push(ee),c.push({id:r.id,el:$})}catch{}}),(m=Q.current)==null||m.call(Q,c)},[Ee,C]),s.useEffect(()=>{var n;const e=y.current;if(!(!e||!D.current))try{(n=e.getSource("wi-trail"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:a.map(([c,m])=>[m,c])}})}catch{}},[a,C]),s.useEffect(()=>{var n;const e=y.current;if(!(!e||!D.current))try{(n=e.getSource("wi-route"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:d.map(([c,m])=>[m,c])}})}catch{}},[d,C]),s.useEffect(()=>{var n;const e=y.current;if(!(!e||!D.current))try{(n=e.getSource("wi-road-back"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:f.map(([c,m])=>[m,c])}})}catch{}},[f,C]),re.jsxs(re.Fragment,{children:[re.jsx("style",{children:`
        /* ⚠️⚠️ THE RTL TRAP — READ BEFORE TOUCHING ANY MARKER RULE.
           MapLibre's own stylesheet pins every marker with
           .maplibregl-marker { position:absolute; top:0; left:0 } and then
           writes the ground position into an inline transform. Our rules below
           are a single class too, and they load LAST — so declaring
           position:relative here silently beat MapLibre's absolute, dropped the
           marker back into normal flow, and in an RTL document normal flow
           starts at the RIGHT EDGE. The inline transform then offset it from
           there, pushing every stop roughly a screen-width off to the side.
           Measured: container 0..1850, inline translate(925px) — and the marker
           landed at x=2697. That is the whole of "the journey is somewhere on
           the map I have to go looking for": her road was literally rendered
           off the edge of the screen.
           Keep position:absolute + top:0 + left:0 on anything MapLibre mounts as
           a marker. top is still animatable (the bob uses it) because an
           absolutely positioned box honours top just the same. */
        .wi-dest-pin { position: absolute; top: 0; left: 0; width: 26px; height: 26px; }
        .wi-dest-dot { position:absolute; inset:7px; border-radius:50%;
          background:${Y.indigo}; border:2.5px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .wi-dest-ring { position:absolute; inset:0; border-radius:50%;
          background:${Y.indigo}; opacity:.35; animation: wiDestPulse 1.9s ease-out infinite; }
        @keyframes wiDestPulse {
          0% { transform: scale(.55); opacity:.55; }
          70% { transform: scale(1.5); opacity:0; }
          100% { transform: scale(1.5); opacity:0; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-dest-ring { animation: none; } }

        /* Journey stops standing in the world. Sized by their moment: the day's
           step is the one that draws the eye, the past is quiet, ahead is faint. */
        /* ⚠️⚠️ NOTHING HERE MAY ANIMATE OR SET transform ON .wi-stop ITSELF.
           MapLibre positions a marker by writing an inline transform onto this
           exact element (translate(-50%,-50%) translate(Xpx,Ypx)), and any CSS
           animation or rule that also sets transform REPLACES that — the
           marker snaps to the container's top-left corner and stops following
           the ground.
           That is precisely what happened to TODAY'S stop: the bob animation
           below used to animate transform, so the single most important thing
           on the screen rendered at (0,-1) — off in the corner — while every
           other stop sat correctly on the road. Measured, not guessed:
           computedTransform matrix(1,0,0,1,0,-1) against an inline
           translate(187.5px,340px). It reads exactly like "the journey is
           somewhere on the map you have to go looking for".
           The bob now animates top (this element is position:relative, so that
           moves it visually and touches no transform), and the press uses the
           standalone scale property, which composes with transform instead of
           overwriting it. */
        .wi-stop { -webkit-appearance:none; appearance:none; padding:0; cursor:pointer;
          position:absolute; top:0; left:0;   /* ⚠️ see THE RTL TRAP above */
          border-radius:50%; background:#fff; border:2.5px solid var(--wi-stop);
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 3px 10px rgba(40,25,70,.35); transition:scale .18s ease; }

        /* The road remembers. Every stop she finished carries a soft bloom in
           its own domain colour, so the path behind her is visibly warmer than
           the path ahead — presence left on the ground rather than a number in
           a corner. Drawn behind the marker and never interactive. */
        /* A finished day stops asking for attention: the bob is dropped and a
           check rides the marker, so the work she did is visible ON the road. */
        .wi-stop--complete { animation:none !important; }
        .wi-stop-check { position:absolute; right:-3px; bottom:-3px; width:20px; height:20px;
          border-radius:50%; background:#2E9E6B; border:2.5px solid #fff; color:#fff;
          font-size:11px; font-weight:900; line-height:1;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 2px 6px rgba(40,25,70,.4); pointer-events:none; }

        .wi-stop--done::after, .wi-stop--complete::after {
          content:''; position:absolute; inset:-11px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, var(--wi-stop) 0%, transparent 70%);
          opacity:.34; pointer-events:none;
          animation: wiBloom 6s ease-in-out infinite;
        }
        @keyframes wiBloom {
          0%,100% { transform: scale(1);    opacity:.30; }
          50%     { transform: scale(1.14); opacity:.42; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--done::after { animation:none; } }
        .wi-stop:active { scale:.9; }
        /* ⚠️ HIT SLOP, NOT A BIGGER BUTTON. A finished stop is 30px and a
           locked one 28px — well under the 44px a thumb needs — so taps that
           looked like they landed on a stop landed on the map instead, and the
           card "did not open". The circle keeps its size; only the target
           grows, behind it, invisible. */
        .wi-stop::before { content:''; position:absolute; inset:-9px; border-radius:50%; }
        .wi-stop-slot { display:flex; align-items:center; justify-content:center; line-height:0; }
        /* Sits under the circle, reads over any ground the map puts behind it. */
        /* Dark ink inside a white halo, NOT white text: the ground under these
           labels is a pale lavender city, and white-on-pale left "אתמול · היום ·
           מחר" barely there - the one thing that tells her which way her own
           road runs. */
        .wi-stop-cap { position:absolute; top:100%; margin-top:7px; left:50%;
          transform:translateX(-50%); white-space:nowrap; pointer-events:none;
          font-size:11.5px; font-weight:900; color:#241C3A; letter-spacing:.01em;
          /* A solid light pill so the label reads on ANY surface — the pale map OR
             the dark purple road. Dark text over a white glow alone vanished on the
             road (looked white/unreadable). */
          background:rgba(255,255,255,0.94); padding:2px 9px; border-radius:999px;
          box-shadow:0 1px 5px rgba(26,20,38,0.18); text-shadow:none; }
        /* Future captions (מחר) sit ABOVE their circle so a small node's label
           never lands on the big today node just below it. */
        .wi-stop-cap--above { top:auto; bottom:100%; margin-top:0; margin-bottom:7px; }

        /* ── The road back, and the ghost of what is still folded away ──
           The journey card's own two nodes, planted on the map: a neutral 42px
           circle carrying the arrow, and one faint dashed node behind it so the
           road never looks like it ends. Same sizes, same weights, same colours
           as JourneyHeroCard — they are the same control, on a different
           surface. */
        /* Her coin, waiting on the road. No border and no white plate — it is
           an object lying there, not another station. */
        .wi-stop--coin  { width:44px; height:44px; background:transparent; border:none;
                          box-shadow:none; }
        .wi-stop--coin::after {
          content:''; position:absolute; inset:-10px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, #8B60EA 0%, transparent 70%);
          opacity:.42; pointer-events:none; animation: wiBloom 3.4s ease-in-out infinite;
        }
        .wi-stop--back  { width:42px; height:42px; background:#F1EEF6; border:2px solid #E3DCEF;
                          box-shadow:0 3px 10px rgba(40,25,70,.22); }
        .wi-stop--ghost { width:36px; height:36px; background:#F1EEF6; border:2px dashed #E3DCEF;
                          opacity:.42; pointer-events:none; box-shadow:none; }
        .wi-stop--done   { width:30px; height:30px; opacity:.9; }
        .wi-stop--ahead  { width:28px; height:28px; opacity:.6; border-style:dashed; }
        .wi-stop--locked { width:28px; height:28px; opacity:.5; border-style:dashed; }
        .wi-stop--today  { width:70px; height:70px; border-width:5px;
          box-shadow:0 0 0 9px color-mix(in srgb, var(--wi-stop) 22%, transparent), 0 8px 22px rgba(40,25,70,.4);
          animation: wiStopBob 2.1s ease-in-out infinite; }
        .wi-stop--today .wi-stop-core { width:24px; height:24px; }
        @keyframes wiStopBob {
          0%,100% { top: 0; }
          50%     { top: -5px; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--today { animation:none; } }
      `}),re.jsx("div",{ref:O,style:{width:"100%",height:"100%"}})]})}export{$e as default,Ae as isWebGLAvailable};
