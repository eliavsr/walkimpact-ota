import"./index-ChlSwsu8.js";function o(e){return(e||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,20)}export{o as n};
