import{a4 as e,a8 as r,r as s}from"./ui-vendor-YyuPkM9D.js";function c(){const a=e(),t=r();return s.useEffect(()=>{a(`/start${t.search}`,{replace:!0})},[a,t.search]),null}export{c as default};
