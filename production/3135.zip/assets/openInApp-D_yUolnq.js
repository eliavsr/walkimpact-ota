import{ae as o}from"./index-CR73H_2G.js";async function e(n){await o(n)}function i(n){return a=>{a.preventDefault(),e(n)}}export{e as a,i as o};
