import"./index-0P1qGcu_.js";function o(e){return(e||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,20)}export{o as n};
