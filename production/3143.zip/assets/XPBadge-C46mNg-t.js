import{R as n,j as e}from"./ui-vendor-DDB9bS0w.js";import"./index-DKbdJa7m.js";const r={maya_message:{points:3,label:"נקודות XP"},maya_session_complete:{points:20,label:"נקודות XP"},simulator_complete:{points:30,label:"נקודות XP"},simulator_message:{points:2,label:"נקודות XP"},daily_checkin:{points:10,label:"נקודות XP"},mood_log:{points:5,label:"נקודות XP"},exercise_complete:{points:15,label:"נקודות XP"},weekly_checkin:{points:25,label:"נקודות XP"},community_post:{points:8,label:"נקודות XP"},community_react:{points:2,label:"נקודות XP"},weekly_insights:{points:20,label:"נקודות XP"},nightly_reflection:{points:15,label:"נקודות XP"},breathing_exercise:{points:10,label:"נקודות XP"}};function p({points:a,label:s,onDone:t}){return n.useEffect(()=>{const l=setTimeout(t,2e3);return()=>clearTimeout(l)},[t]),e.jsxs("div",{className:"fixed top-16 left-1/2 -translate-x-1/2 z-50 pointer-events-none",style:{animation:"xpFloat 2s ease-out forwards"},children:[e.jsxs("span",{className:"inline-flex items-center gap-1 px-4 py-2 rounded-full font-black text-white text-base shadow-xl",style:{background:"linear-gradient(135deg, #F6AD55, #F97316)"},children:["⭐ +",a," ",s||"נקודות XP"]}),e.jsx("style",{children:`
        @keyframes xpFloat {
          0% { opacity: 0; transform: translateX(-50%) translateY(0); }
          20% { opacity: 1; }
          80% { opacity: 1; transform: translateX(-50%) translateY(-30px); }
          100% { opacity: 0; transform: translateX(-50%) translateY(-50px); }
        }
      `})]})}export{p as X,r as a};
