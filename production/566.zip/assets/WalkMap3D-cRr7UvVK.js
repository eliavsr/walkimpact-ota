import{r as o,j as W}from"./ui-vendor-DferYTpc.js";import{m as B}from"./maplibre-vendor-CTnERwHt.js";import{g as C}from"./index-CsK0sr-L.js";import"./data-vendor-BKbt1yPA.js";const we="https://tiles.openfreemap.org/styles/liberty",V=["coalesce",["get","render_height"],8],be=["interpolate",["linear"],V,0,"#DCCCEA",12,"#CDB8E0",30,"#B99FD4",60,"#A386C7",120,"#8E6DB8"],xe=l=>/^poi/i.test(l),pe=[[0,4,3],[.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,.5],[3,4,0],[0,.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,.5]];let N=null;function Ee(){if(N!==null)return N;try{const l=document.createElement("canvas");N=!!(window.WebGLRenderingContext&&(l.getContext("webgl")||l.getContext("experimental-webgl")))}catch{N=!1}return N}function ve([l,f],[E,L]){const m=g=>g*Math.PI/180,O=g=>g*180/Math.PI,D=m(L-f),v=Math.sin(D)*Math.cos(m(E)),I=Math.cos(m(l))*Math.sin(m(E))-Math.sin(m(l))*Math.cos(m(E))*Math.cos(D);return(O(Math.atan2(v,I))+360)%360}function ke(l,f){return((f-l)%360+540)%360-180}function Ae({center:l,routePoints:f=[],routeCoords:E=[],destination:L=null,stops:m=[],onStopTap:O,onStopSlots:D,introFlyIn:v=!1,follow:I=!0,zoom:g=17.5,pitch:R=55,cameraOffset:Z=null,trailColor:ue=C.teal,routeColor:he=C.indigo,frameRoute:ee=!0,reduced:k=!1,onUserPan:te,onMoveEnd:ne,onCamera:re,onFallback:oe}){const[K,fe]=o.useState(!1),M=o.useRef(null),d=o.useRef(null),T=o.useRef(!1),X=o.useRef(0),z=o.useRef(null),H=o.useRef(null),j=o.useRef(null),S=o.useRef([]),p=o.useRef(oe),u=o.useRef(te),$=o.useRef(O),G=o.useRef(D),_=o.useRef(ne),P=o.useRef(re);P.current=re,p.current=oe,u.current=te,$.current=O,G.current=D,_.current=ne,o.useEffect(()=>{var A,Y,b,ie,ae,se;if(!M.current||d.current)return;if(!Ee()){(A=p.current)==null||A.call(p);return}try{((b=(Y=B).getRTLTextPluginStatus)==null?void 0:b.call(Y))==="unavailable"&&B.setRTLTextPlugin("https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.2.3/mapbox-gl-rtl-text.min.js",!0)}catch{}let e;try{e=new B.Map({container:M.current,style:we,center:l?[l[1],l[0]]:[34.78,32.08],zoom:g,pitch:R,bearing:0,attributionControl:!1,antialias:!1,fadeDuration:0})}catch{(ie=p.current)==null||ie.call(p);return}d.current=e,e.on("error",r=>{var i,h;(i=r==null?void 0:r.error)!=null&&i.message&&/webgl|context/i.test(r.error.message)&&((h=p.current)==null||h.call(p))});const a=r=>{var i;r!=null&&r.originalEvent&&((i=u.current)==null||i.call(u))};e.on("dragstart",a),e.on("rotatestart",a),e.on("zoomstart",a),e.on("moveend",()=>{var r;try{const i=e.getCenter();(r=_.current)==null||r.call(_,[i.lat,i.lng])}catch{}}),e.on("click",r=>{var i,h;try{const F=r.point,U=J.current||[];let n=null,s=1/0;if(U.forEach(x=>{if(typeof(x==null?void 0:x.lat)!="number"||typeof(x==null?void 0:x.lon)!="number"||x.kind==="ghost")return;const le=e.project([x.lon,x.lat]),de=Math.hypot(le.x-F.x,le.y-F.y);de<s&&(s=de,n=x)}),!n)return;const me=n.state==="today"?34:n.kind==="back"||n.kind==="coin"?28:24;if(s>me)return;const ce=e.project([n.lon,n.lat]),Q=(i=M.current)==null?void 0:i.getBoundingClientRect(),q=n.state==="today"?52:30,ge=Q?{left:Q.left+ce.x-q/2,top:Q.top+ce.y-q/2,width:q,height:q}:null;(h=$.current)==null||h.call($,n,ge)}catch{}}),e.on("load",()=>{var h,F,U;T.current=!0;try{(h=P.current)==null||h.call(P,{zoomBy:n=>{var s;try{(s=u.current)==null||s.call(u),e.easeTo({zoom:Math.min(19.5,Math.max(13,e.getZoom()+n)),duration:320})}catch{}},tiltBy:n=>{var s;try{(s=u.current)==null||s.call(u),e.easeTo({pitch:Math.min(70,Math.max(0,e.getPitch()+n)),duration:320})}catch{}},turnBy:n=>{var s;try{(s=u.current)==null||s.call(u),e.easeTo({bearing:e.getBearing()+n,duration:320})}catch{}},reset:()=>{try{e.easeTo({pitch:R,bearing:0,zoom:g,duration:420})}catch{}}})}catch{}if(fe(!0),v)try{e.jumpTo({zoom:Math.max(13,g-2.2),pitch:Math.max(0,R-22)}),setTimeout(()=>{try{e.easeTo({zoom:g,pitch:R,duration:4500})}catch{}},2800)}catch{}try{(F=e.setSky)==null||F.call(e,{"sky-color":"#BFDBF5","horizon-color":"#F6E9F0","fog-color":"#EFE7F5","sky-horizon-blend":.5,"horizon-fog-blend":.35,"fog-ground-blend":.08})}catch{}try{const n=(U=e.getStyle().layers.find(s=>s.type==="symbol"))==null?void 0:U.id;e.addLayer({id:"wi-buildings-3d",source:"openmaptiles","source-layer":"building",type:"fill-extrusion",minzoom:14,filter:["!=",["get","hide_3d"],!0],paint:{"fill-extrusion-color":be,"fill-extrusion-base":["coalesce",["get","render_min_height"],0],"fill-extrusion-opacity":.82,"fill-extrusion-vertical-gradient":!0,"fill-extrusion-height":k?V:0,"fill-extrusion-height-transition":{duration:1400,delay:0}}},n),k||setTimeout(()=>{var s;try{(s=d.current)==null||s.setPaintProperty("wi-buildings-3d","fill-extrusion-height",V)}catch{}},220)}catch{}try{e.getStyle().layers.filter(n=>n.type==="symbol"&&xe(n.id)).forEach(n=>{try{e.setLayoutProperty(n.id,"visibility","none")}catch{}})}catch{}const r=v?6.5:1,i=v?.8:1;try{e.addSource("wi-trail",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-trail-casing",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*r,"line-opacity":.45*i}}),e.addLayer({id:"wi-trail-line",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":ue,"line-width":10*r,"line-opacity":.92*i}}),e.addSource("wi-route",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-route-casing",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":12*r,"line-opacity":.5*i}}),e.addLayer({id:"wi-route-line",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":he,"line-width":8*r,"line-opacity":.95*i}}),e.addLayer({id:"wi-route-flow",type:"line",source:"wi-route",layout:{"line-cap":"butt","line-join":"round"},paint:{"line-color":"#FFFFFF","line-width":v?3:3.4,"line-opacity":v?.28:.9,"line-dasharray":[0,4,3]}})}catch{}if(!k)if(z.current=setInterval(()=>{if(!d.current||!T.current)return;const n=Date.now()%7e3/7e3,s=.55+.4*(.5-Math.cos(n*2*Math.PI)/2);try{d.current.setPaintProperty("wi-trail-line","line-opacity",s)}catch{}},120),v)try{d.current.setPaintProperty("wi-route-flow","line-dasharray",[2,3])}catch{}else{let n=0;H.current=setInterval(()=>{if(!(!d.current||!T.current)){n=(n+1)%pe.length;try{d.current.setPaintProperty("wi-route-flow","line-dasharray",pe[n])}catch{}}},90)}});const c=typeof ResizeObserver<"u"?new ResizeObserver(()=>{try{e.resize()}catch{}}):null;try{c&&M.current&&c.observe(M.current)}catch{}const w=requestAnimationFrame(()=>{try{e.resize()}catch{}}),t=(ae=e.getCanvas)==null?void 0:ae.call(e),y=r=>{var i,h;(i=r.preventDefault)==null||i.call(r),(h=p.current)==null||h.call(p)};return(se=t==null?void 0:t.addEventListener)==null||se.call(t,"webglcontextlost",y),()=>{var r,i;cancelAnimationFrame(w);try{c==null||c.disconnect()}catch{}z.current&&clearInterval(z.current),H.current&&clearInterval(H.current),z.current=null,H.current=null,(r=t==null?void 0:t.removeEventListener)==null||r.call(t,"webglcontextlost",y);try{(i=j.current)==null||i.remove()}catch{}j.current=null,S.current.forEach(h=>{try{h.remove()}catch{}}),S.current=[],T.current=!1;try{e.remove()}catch{}d.current=null}},[]),o.useEffect(()=>{const e=d.current;if(!(!e||!l||!I)){if(f.length>=2){const a=ve(f[f.length-2],f[f.length-1]);X.current+=ke(X.current,a)*.18}try{e.easeTo({center:[l[1],l[0]],bearing:X.current,pitch:R,zoom:g,offset:Z||[0,0],duration:k?0:900,essential:!0})}catch{}}},[l,f,I,k,g,R,Z]),o.useEffect(()=>{const e=d.current;if(!(!e||!T.current||!ee||E.length<2))try{const a=new B.LngLatBounds;E.forEach(([c,w])=>a.extend([w,c])),e.fitBounds(a,{padding:{top:150,bottom:230,left:60,right:60},pitch:40,bearing:0,duration:k?0:1500,essential:!0})}catch{}},[E,k,ee]),o.useEffect(()=>{var a;const e=d.current;if(e){try{(a=j.current)==null||a.remove()}catch{}if(j.current=null,!!L)try{const c=document.createElement("div");c.className="wi-dest-pin",c.innerHTML='<span class="wi-dest-ring"></span><span class="wi-dest-dot"></span>',j.current=new B.Marker({element:c,anchor:"center"}).setLngLat([L.lon,L.lat]).addTo(e)}catch{}}},[L]);const ye=m.map(e=>`${e.id}|${e.lat}|${e.lon}|${e.state}|${e.done?1:0}|${e.color}|${e.icon}|${e.caption}`).join("~"),J=o.useRef(m);return J.current=m,o.useEffect(()=>{var w;const e=d.current;if(!e)return;const a=J.current;S.current.forEach(t=>{try{t.remove()}catch{}}),S.current=[];const c=[];a.forEach(t=>{if(!(typeof(t==null?void 0:t.lat)!="number"||typeof(t==null?void 0:t.lon)!="number"))try{const y=document.createElement("button");y.type="button",y.className=`wi-stop wi-stop--${t.state||"ahead"}${t.done?" wi-stop--complete":""}`,y.style.setProperty("--wi-stop",t.color||C.teal),y.setAttribute("aria-label",t.label||"");const A=document.createElement("span");if(A.className="wi-stop-slot",y.appendChild(A),t.done){const b=document.createElement("span");b.className="wi-stop-check",b.textContent="✓",y.appendChild(b)}if(t.caption){const b=document.createElement("span");b.className=`wi-stop-cap${t.capAbove?" wi-stop-cap--above":""}`,b.textContent=t.caption,y.appendChild(b)}const Y=new B.Marker({element:y,anchor:"center"}).setLngLat([t.lon,t.lat]).addTo(e);S.current.push(Y),c.push({id:t.id,el:A})}catch{}}),(w=G.current)==null||w.call(G,c)},[ye,K]),o.useEffect(()=>{var a;const e=d.current;if(!(!e||!T.current))try{(a=e.getSource("wi-trail"))==null||a.setData({type:"Feature",geometry:{type:"LineString",coordinates:f.map(([c,w])=>[w,c])}})}catch{}},[f,K]),o.useEffect(()=>{var a;const e=d.current;if(!(!e||!T.current))try{(a=e.getSource("wi-route"))==null||a.setData({type:"Feature",geometry:{type:"LineString",coordinates:E.map(([c,w])=>[w,c])}})}catch{}},[E,K]),W.jsxs(W.Fragment,{children:[W.jsx("style",{children:`
        /* ⚠️⚠️ THE RTL TRAP — READ BEFORE TOUCHING ANY MARKER RULE.
           MapLibre's own stylesheet pins every marker with
           .maplibregl-marker { position:absolute; top:0; left:0 } and then
           writes the ground position into an inline transform. Our rules below
           are a single class too, and they load LAST — so declaring
           position:relative here silently beat MapLibre's absolute, dropped the
           marker back into normal flow, and in an RTL document normal flow
           starts at the RIGHT EDGE. The inline transform then offset it from
           there, pushing every stop roughly a screen-width off to the side.
           Measured: container 0..1850, inline translate(925px) — and the marker
           landed at x=2697. That is the whole of "the journey is somewhere on
           the map I have to go looking for": her road was literally rendered
           off the edge of the screen.
           Keep position:absolute + top:0 + left:0 on anything MapLibre mounts as
           a marker. top is still animatable (the bob uses it) because an
           absolutely positioned box honours top just the same. */
        .wi-dest-pin { position: absolute; top: 0; left: 0; width: 26px; height: 26px; }
        .wi-dest-dot { position:absolute; inset:7px; border-radius:50%;
          background:${C.indigo}; border:2.5px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .wi-dest-ring { position:absolute; inset:0; border-radius:50%;
          background:${C.indigo}; opacity:.35; animation: wiDestPulse 1.9s ease-out infinite; }
        @keyframes wiDestPulse {
          0% { transform: scale(.55); opacity:.55; }
          70% { transform: scale(1.5); opacity:0; }
          100% { transform: scale(1.5); opacity:0; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-dest-ring { animation: none; } }

        /* Journey stops standing in the world. Sized by their moment: the day's
           step is the one that draws the eye, the past is quiet, ahead is faint. */
        /* ⚠️⚠️ NOTHING HERE MAY ANIMATE OR SET transform ON .wi-stop ITSELF.
           MapLibre positions a marker by writing an inline transform onto this
           exact element (translate(-50%,-50%) translate(Xpx,Ypx)), and any CSS
           animation or rule that also sets transform REPLACES that — the
           marker snaps to the container's top-left corner and stops following
           the ground.
           That is precisely what happened to TODAY'S stop: the bob animation
           below used to animate transform, so the single most important thing
           on the screen rendered at (0,-1) — off in the corner — while every
           other stop sat correctly on the road. Measured, not guessed:
           computedTransform matrix(1,0,0,1,0,-1) against an inline
           translate(187.5px,340px). It reads exactly like "the journey is
           somewhere on the map you have to go looking for".
           The bob now animates top (this element is position:relative, so that
           moves it visually and touches no transform), and the press uses the
           standalone scale property, which composes with transform instead of
           overwriting it. */
        .wi-stop { -webkit-appearance:none; appearance:none; padding:0; cursor:pointer;
          position:absolute; top:0; left:0;   /* ⚠️ see THE RTL TRAP above */
          border-radius:50%; background:#fff; border:2.5px solid var(--wi-stop);
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 3px 10px rgba(40,25,70,.35); transition:scale .18s ease; }

        /* The road remembers. Every stop she finished carries a soft bloom in
           its own domain colour, so the path behind her is visibly warmer than
           the path ahead — presence left on the ground rather than a number in
           a corner. Drawn behind the marker and never interactive. */
        /* A finished day stops asking for attention: the bob is dropped and a
           check rides the marker, so the work she did is visible ON the road. */
        .wi-stop--complete { animation:none !important; }
        .wi-stop-check { position:absolute; right:-3px; bottom:-3px; width:20px; height:20px;
          border-radius:50%; background:#2E9E6B; border:2.5px solid #fff; color:#fff;
          font-size:11px; font-weight:900; line-height:1;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 2px 6px rgba(40,25,70,.4); pointer-events:none; }

        .wi-stop--done::after, .wi-stop--complete::after {
          content:''; position:absolute; inset:-11px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, var(--wi-stop) 0%, transparent 70%);
          opacity:.34; pointer-events:none;
          animation: wiBloom 6s ease-in-out infinite;
        }
        @keyframes wiBloom {
          0%,100% { transform: scale(1);    opacity:.30; }
          50%     { transform: scale(1.14); opacity:.42; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--done::after { animation:none; } }
        .wi-stop:active { scale:.9; }
        /* ⚠️ HIT SLOP, NOT A BIGGER BUTTON. A finished stop is 30px and a
           locked one 28px — well under the 44px a thumb needs — so taps that
           looked like they landed on a stop landed on the map instead, and the
           card "did not open". The circle keeps its size; only the target
           grows, behind it, invisible. */
        .wi-stop::before { content:''; position:absolute; inset:-9px; border-radius:50%; }
        .wi-stop-slot { display:flex; align-items:center; justify-content:center; line-height:0; }
        /* Sits under the circle, reads over any ground the map puts behind it. */
        /* Dark ink inside a white halo, NOT white text: the ground under these
           labels is a pale lavender city, and white-on-pale left "אתמול · היום ·
           מחר" barely there — the one thing that tells her which way her own
           road runs. */
        .wi-stop-cap { position:absolute; top:100%; margin-top:7px; left:50%;
          transform:translateX(-50%); white-space:nowrap; pointer-events:none;
          font-size:11.5px; font-weight:900; color:#241C3A; letter-spacing:.01em;
          /* A solid light pill so the label reads on ANY surface — the pale map OR
             the dark purple road. Dark text over a white glow alone vanished on the
             road (looked white/unreadable). */
          background:rgba(255,255,255,0.94); padding:2px 9px; border-radius:999px;
          box-shadow:0 1px 5px rgba(26,20,38,0.18); text-shadow:none; }
        /* Future captions (מחר) sit ABOVE their circle so a small node's label
           never lands on the big today node just below it. */
        .wi-stop-cap--above { top:auto; bottom:100%; margin-top:0; margin-bottom:7px; }

        /* ── The road back, and the ghost of what is still folded away ──
           The journey card's own two nodes, planted on the map: a neutral 42px
           circle carrying the arrow, and one faint dashed node behind it so the
           road never looks like it ends. Same sizes, same weights, same colours
           as JourneyHeroCard — they are the same control, on a different
           surface. */
        /* Her coin, waiting on the road. No border and no white plate — it is
           an object lying there, not another station. */
        .wi-stop--coin  { width:44px; height:44px; background:transparent; border:none;
                          box-shadow:none; }
        .wi-stop--coin::after {
          content:''; position:absolute; inset:-10px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, #8B60EA 0%, transparent 70%);
          opacity:.42; pointer-events:none; animation: wiBloom 3.4s ease-in-out infinite;
        }
        .wi-stop--back  { width:42px; height:42px; background:#F1EEF6; border:2px solid #E3DCEF;
                          box-shadow:0 3px 10px rgba(40,25,70,.22); }
        .wi-stop--ghost { width:36px; height:36px; background:#F1EEF6; border:2px dashed #E3DCEF;
                          opacity:.42; pointer-events:none; box-shadow:none; }
        .wi-stop--done   { width:30px; height:30px; opacity:.9; }
        .wi-stop--ahead  { width:28px; height:28px; opacity:.6; border-style:dashed; }
        .wi-stop--locked { width:28px; height:28px; opacity:.5; border-style:dashed; }
        .wi-stop--today  { width:70px; height:70px; border-width:5px;
          box-shadow:0 0 0 9px color-mix(in srgb, var(--wi-stop) 22%, transparent), 0 8px 22px rgba(40,25,70,.4);
          animation: wiStopBob 2.1s ease-in-out infinite; }
        .wi-stop--today .wi-stop-core { width:24px; height:24px; }
        @keyframes wiStopBob {
          0%,100% { top: 0; }
          50%     { top: -5px; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--today { animation:none; } }
      `}),W.jsx("div",{ref:M,style:{width:"100%",height:"100%"}})]})}export{Ae as default,Ee as isWebGLAvailable};
