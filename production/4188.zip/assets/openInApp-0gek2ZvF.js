import{a8 as o}from"./index-RVvkNLnY.js";async function t(n){await o(n)}function i(n){return a=>{a.preventDefault(),t(n)}}export{t as a,i as o};
