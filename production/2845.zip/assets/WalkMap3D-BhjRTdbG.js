import{r as s,j as ne}from"./ui-vendor-c7kLwFo0.js";import{m as B}from"./maplibre-vendor-k5seUCIN.js";import{y as Y}from"./index-tDAvwcHX.js";import"./data-vendor-Dh0ZEWWH.js";const ke="https://tiles.openfreemap.org/styles/liberty",ce=["coalesce",["get","render_height"],8],Te=["interpolate",["linear"],ce,0,"#DCCCEA",12,"#CDB8E0",30,"#B99FD4",60,"#A386C7",120,"#8E6DB8"],Le=t=>/^poi/i.test(t),ge=[[0,4,3],[.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,.5],[3,4,0],[0,.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,.5]];let K=null;function Me(){if(K!==null)return K;try{const t=document.createElement("canvas");K=!!(window.WebGLRenderingContext&&(t.getContext("webgl")||t.getContext("experimental-webgl")))}catch{K=!1}return K}function le([t,a],[l,f]){const u=L=>L*Math.PI/180,E=L=>L*180/Math.PI,d=u(f-a),k=Math.sin(d)*Math.cos(u(l)),m=Math.cos(u(t))*Math.sin(u(l))-Math.sin(u(t))*Math.cos(u(l))*Math.cos(d);return(E(Math.atan2(k,m))+360)%360}function Ae(t,a){return((a-t)%360+540)%360-180}function se([t,a],[l,f]){const u=(l-t)*111320,E=(f-a)*111320*Math.cos(t*Math.PI/180);return Math.hypot(E,u)}const Re=30;function De(t,a){if(!Array.isArray(t)||t.length<2||!a)return a;const l=111320,f=111320*Math.cos(a[0]*Math.PI/180),u=a[1]*f,E=a[0]*l;let d=null,k=1/0;for(let m=0;m<t.length-1;m++){const L=t[m][1]*f,M=t[m][0]*l,D=t[m+1][1]*f,q=t[m+1][0]*l,j=D-L,F=q-M,O=j*j+F*F;if(!O)continue;let v=((u-L)*j+(E-M)*F)/O;v=Math.max(0,Math.min(1,v));const $=L+v*j,z=M+v*F,H=Math.hypot(u-$,E-z);H<k&&(k=H,d=[z/l,$/f])}return d&&k<=Re?d:a}const Se=35;function Be(t,a){if(!Array.isArray(t)||t.length<2||!a)return null;let l=0,f=1/0;for(let d=0;d<t.length;d++){const k=se(a,t[d]);k<f&&(f=k,l=d)}if(f>120)return null;let u=0;for(let d=l;d<t.length-1;d++)if(u+=se(t[d],t[d+1]),u>=Se)return le(a,t[d+1]);const E=t[t.length-1];return se(a,E)>5?le(a,E):null}function Oe({center:t,routePoints:a=[],routeCoords:l=[],destination:f=null,stops:u=[],routeNodes:E=[],onStopTap:d,onStopSlots:k,introFlyIn:m=!1,follow:L=!0,zoom:M=17.5,pitch:D=55,cameraOffset:q=null,trailColor:j=Y.teal,routeColor:F=Y.indigo,frameRoute:O=!0,reduced:v=!1,onUserPan:$,onMoveEnd:z,onCamera:H,onFallback:pe}){const[re,be]=s.useState(!1),I=s.useRef(null),y=s.useRef(null),S=s.useRef(!1),oe=s.useRef(0),W=s.useRef(null),C=s.useRef(null),_=s.useRef(null),P=s.useRef([]),G=s.useRef([]),g=s.useRef(pe),b=s.useRef($),X=s.useRef(d),J=s.useRef(k),Q=s.useRef(z),V=s.useRef(H);V.current=H,g.current=pe,b.current=$,X.current=d,J.current=k,Q.current=z,s.useEffect(()=>{var N,Z,A,de,he,ue;if(!I.current||y.current)return;if(!Me()){(N=g.current)==null||N.call(g);return}try{((A=(Z=B).getRTLTextPluginStatus)==null?void 0:A.call(Z))==="unavailable"&&B.setRTLTextPlugin("https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.2.3/mapbox-gl-rtl-text.min.js",!0)}catch{}let e;try{e=new B.Map({container:I.current,style:ke,center:t?[t[1],t[0]]:[34.78,32.08],zoom:M,pitch:D,bearing:0,attributionControl:!1,antialias:!1,fadeDuration:0})}catch{(de=g.current)==null||de.call(g);return}y.current=e,e.on("error",i=>{var p,x;(p=i==null?void 0:i.error)!=null&&p.message&&/webgl|context/i.test(i.error.message)&&((x=g.current)==null||x.call(g))});const r=i=>{var p;i!=null&&i.originalEvent&&((p=b.current)==null||p.call(b))};e.on("dragstart",r),e.on("rotatestart",r),e.on("zoomstart",r),e.on("moveend",()=>{var i;try{const p=e.getCenter();(i=Q.current)==null||i.call(Q,[p.lat,p.lng])}catch{}}),e.on("click",i=>{var p,x;try{const U=i.point,ee=ae.current||[];let o=null,h=1/0;if(ee.forEach(R=>{if(typeof(R==null?void 0:R.lat)!="number"||typeof(R==null?void 0:R.lon)!="number"||R.kind==="ghost")return;const ye=e.project([R.lon,R.lat]),me=Math.hypot(ye.x-U.x,ye.y-U.y);me<h&&(h=me,o=R)}),!o)return;const Ee=o.state==="today"?34:o.kind==="back"||o.kind==="coin"?28:24;if(h>Ee)return;const fe=e.project([o.lon,o.lat]),ie=(p=I.current)==null?void 0:p.getBoundingClientRect(),te=o.state==="today"?52:30,ve=ie?{left:ie.left+fe.x-te/2,top:ie.top+fe.y-te/2,width:te,height:te}:null;(x=X.current)==null||x.call(X,o,ve)}catch{}}),e.on("load",()=>{var x,U,ee;S.current=!0;try{(x=V.current)==null||x.call(V,{zoomBy:o=>{var h;try{(h=b.current)==null||h.call(b),e.easeTo({zoom:Math.min(19.5,Math.max(13,e.getZoom()+o)),duration:320})}catch{}},tiltBy:o=>{var h;try{(h=b.current)==null||h.call(b),e.easeTo({pitch:Math.min(70,Math.max(0,e.getPitch()+o)),duration:320})}catch{}},turnBy:o=>{var h;try{(h=b.current)==null||h.call(b),e.easeTo({bearing:e.getBearing()+o,duration:320})}catch{}},reset:()=>{try{e.easeTo({pitch:D,bearing:0,zoom:M,duration:420})}catch{}}})}catch{}if(be(!0),m)try{e.jumpTo({zoom:Math.max(13,M-2.2),pitch:Math.max(0,D-22)}),setTimeout(()=>{try{e.easeTo({zoom:M,pitch:D,duration:4500})}catch{}},2800)}catch{}try{(U=e.setSky)==null||U.call(e,{"sky-color":"#BFDBF5","horizon-color":"#F6E9F0","fog-color":"#EFE7F5","sky-horizon-blend":.5,"horizon-fog-blend":.35,"fog-ground-blend":.08})}catch{}try{const o=(ee=e.getStyle().layers.find(h=>h.type==="symbol"))==null?void 0:ee.id;e.addLayer({id:"wi-buildings-3d",source:"openmaptiles","source-layer":"building",type:"fill-extrusion",minzoom:14,filter:["!=",["get","hide_3d"],!0],paint:{"fill-extrusion-color":Te,"fill-extrusion-base":["coalesce",["get","render_min_height"],0],"fill-extrusion-opacity":.82,"fill-extrusion-vertical-gradient":!0,"fill-extrusion-height":v?ce:0,"fill-extrusion-height-transition":{duration:1400,delay:0}}},o),v||setTimeout(()=>{var h;try{(h=y.current)==null||h.setPaintProperty("wi-buildings-3d","fill-extrusion-height",ce)}catch{}},220)}catch{}try{e.getStyle().layers.filter(o=>o.type==="symbol"&&Le(o.id)).forEach(o=>{try{e.setLayoutProperty(o.id,"visibility","none")}catch{}})}catch{}const i=m?6.5:1,p=m?.8:1;try{e.addSource("wi-trail",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-trail-casing",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*i,"line-opacity":.45*p}}),e.addLayer({id:"wi-trail-line",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":j,"line-width":10*i,"line-opacity":.92*p}}),e.addSource("wi-route",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),e.addLayer({id:"wi-route-casing",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":12*i,"line-opacity":.5*p}}),e.addLayer({id:"wi-route-line",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":F,"line-width":8*i,"line-opacity":.95*p}}),e.addLayer({id:"wi-route-flow",type:"line",source:"wi-route",layout:{"line-cap":"butt","line-join":"round"},paint:{"line-color":"#FFFFFF","line-width":m?3:3.4,"line-opacity":m?.28:.9,"line-dasharray":[0,4,3]}})}catch{}if(!v)if(W.current=setInterval(()=>{if(!y.current||!S.current)return;const o=Date.now()%7e3/7e3,h=.55+.4*(.5-Math.cos(o*2*Math.PI)/2);try{y.current.setPaintProperty("wi-trail-line","line-opacity",h)}catch{}},120),m)try{y.current.setPaintProperty("wi-route-flow","line-dasharray",[2,3])}catch{}else{let o=0;C.current=setInterval(()=>{if(!(!y.current||!S.current)){o=(o+1)%ge.length;try{y.current.setPaintProperty("wi-route-flow","line-dasharray",ge[o])}catch{}}},90)}});const c=typeof ResizeObserver<"u"?new ResizeObserver(()=>{try{e.resize()}catch{}}):null;try{c&&I.current&&c.observe(I.current)}catch{}const w=requestAnimationFrame(()=>{try{e.resize()}catch{}}),n=(he=e.getCanvas)==null?void 0:he.call(e),T=i=>{var p,x;(p=i.preventDefault)==null||p.call(i),(x=g.current)==null||x.call(g)};return(ue=n==null?void 0:n.addEventListener)==null||ue.call(n,"webglcontextlost",T),()=>{var i,p;cancelAnimationFrame(w);try{c==null||c.disconnect()}catch{}W.current&&clearInterval(W.current),C.current&&clearInterval(C.current),W.current=null,C.current=null,(i=n==null?void 0:n.removeEventListener)==null||i.call(n,"webglcontextlost",T);try{(p=_.current)==null||p.remove()}catch{}_.current=null,P.current.forEach(x=>{try{x.remove()}catch{}}),P.current=[],S.current=!1;try{e.remove()}catch{}y.current=null}},[]),s.useEffect(()=>{const e=y.current;if(!e||!t||!L)return;const r=Be(l,t)??(a.length>=2?le(a[a.length-2],a[a.length-1]):null);r!=null&&(oe.current+=Ae(oe.current,r)*.18);const c=De(l,t);try{e.easeTo({center:[c[1],c[0]],bearing:oe.current,pitch:D,zoom:M,offset:q||[0,0],duration:v?0:900,essential:!0})}catch{}},[t,a,l,L,v,M,D,q]),s.useEffect(()=>{const e=y.current;if(!(!e||!S.current||!O||l.length<2))try{const r=new B.LngLatBounds;l.forEach(([c,w])=>r.extend([w,c])),e.fitBounds(r,{padding:{top:150,bottom:230,left:60,right:60},pitch:40,bearing:0,duration:v?0:1500,essential:!0})}catch{}},[l,v,O]),s.useEffect(()=>{var r;const e=y.current;if(e){try{(r=_.current)==null||r.remove()}catch{}if(_.current=null,!!f)try{const c=document.createElement("div");c.className="wi-dest-pin",c.innerHTML='<span class="wi-dest-ring"></span><span class="wi-dest-dot"></span>',_.current=new B.Marker({element:c,anchor:"center"}).setLngLat([f.lon,f.lat]).addTo(e)}catch{}}},[f]);const we=E.map(e=>`${e.id}|${e.done?1:0}`).join("~");s.useEffect(()=>{const e=y.current;if(e)return G.current.forEach(r=>{try{r.remove()}catch{}}),G.current=[],E.forEach(r=>{try{const c=r.kind==="coin"?"#f59e0b":"#14b8a6",w=document.createElement("div");w.style.cssText=`width:${r.done?12:20}px;height:${r.done?12:20}px;border-radius:50%;background:${c};border:3px solid #fff;box-shadow:0 2px 8px rgba(26,20,38,.28);opacity:${r.done?.35:1};`;const n=new B.Marker({element:w,anchor:"center"}).setLngLat([r.lon,r.lat]).addTo(e);G.current.push(n)}catch{}}),()=>{G.current.forEach(r=>{try{r.remove()}catch{}}),G.current=[]}},[we]);const xe=u.map(e=>`${e.id}|${e.lat}|${e.lon}|${e.state}|${e.done?1:0}|${e.color}|${e.icon}|${e.caption}`).join("~"),ae=s.useRef(u);return ae.current=u,s.useEffect(()=>{var w;const e=y.current;if(!e)return;const r=ae.current;P.current.forEach(n=>{try{n.remove()}catch{}}),P.current=[];const c=[];r.forEach(n=>{if(!(typeof(n==null?void 0:n.lat)!="number"||typeof(n==null?void 0:n.lon)!="number"))try{const T=document.createElement("button");T.type="button",T.className=`wi-stop wi-stop--${n.state||"ahead"}${n.done?" wi-stop--complete":""}`,T.style.setProperty("--wi-stop",n.color||Y.teal),T.setAttribute("aria-label",n.label||"");const N=document.createElement("span");if(N.className="wi-stop-slot",T.appendChild(N),n.done){const A=document.createElement("span");A.className="wi-stop-check",A.textContent="✓",T.appendChild(A)}if(n.caption){const A=document.createElement("span");A.className=`wi-stop-cap${n.capAbove?" wi-stop-cap--above":""}`,A.textContent=n.caption,T.appendChild(A)}const Z=new B.Marker({element:T,anchor:"center"}).setLngLat([n.lon,n.lat]).addTo(e);P.current.push(Z),c.push({id:n.id,el:N})}catch{}}),(w=J.current)==null||w.call(J,c)},[xe,re]),s.useEffect(()=>{var r;const e=y.current;if(!(!e||!S.current))try{(r=e.getSource("wi-trail"))==null||r.setData({type:"Feature",geometry:{type:"LineString",coordinates:a.map(([c,w])=>[w,c])}})}catch{}},[a,re]),s.useEffect(()=>{var r;const e=y.current;if(!(!e||!S.current))try{(r=e.getSource("wi-route"))==null||r.setData({type:"Feature",geometry:{type:"LineString",coordinates:l.map(([c,w])=>[w,c])}})}catch{}},[l,re]),ne.jsxs(ne.Fragment,{children:[ne.jsx("style",{children:`
        /* ⚠️⚠️ THE RTL TRAP — READ BEFORE TOUCHING ANY MARKER RULE.
           MapLibre's own stylesheet pins every marker with
           .maplibregl-marker { position:absolute; top:0; left:0 } and then
           writes the ground position into an inline transform. Our rules below
           are a single class too, and they load LAST — so declaring
           position:relative here silently beat MapLibre's absolute, dropped the
           marker back into normal flow, and in an RTL document normal flow
           starts at the RIGHT EDGE. The inline transform then offset it from
           there, pushing every stop roughly a screen-width off to the side.
           Measured: container 0..1850, inline translate(925px) — and the marker
           landed at x=2697. That is the whole of "the journey is somewhere on
           the map I have to go looking for": her road was literally rendered
           off the edge of the screen.
           Keep position:absolute + top:0 + left:0 on anything MapLibre mounts as
           a marker. top is still animatable (the bob uses it) because an
           absolutely positioned box honours top just the same. */
        .wi-dest-pin { position: absolute; top: 0; left: 0; width: 26px; height: 26px; }
        .wi-dest-dot { position:absolute; inset:7px; border-radius:50%;
          background:${Y.indigo}; border:2.5px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .wi-dest-ring { position:absolute; inset:0; border-radius:50%;
          background:${Y.indigo}; opacity:.35; animation: wiDestPulse 1.9s ease-out infinite; }
        @keyframes wiDestPulse {
          0% { transform: scale(.55); opacity:.55; }
          70% { transform: scale(1.5); opacity:0; }
          100% { transform: scale(1.5); opacity:0; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-dest-ring { animation: none; } }

        /* Journey stops standing in the world. Sized by their moment: the day's
           step is the one that draws the eye, the past is quiet, ahead is faint. */
        /* ⚠️⚠️ NOTHING HERE MAY ANIMATE OR SET transform ON .wi-stop ITSELF.
           MapLibre positions a marker by writing an inline transform onto this
           exact element (translate(-50%,-50%) translate(Xpx,Ypx)), and any CSS
           animation or rule that also sets transform REPLACES that — the
           marker snaps to the container's top-left corner and stops following
           the ground.
           That is precisely what happened to TODAY'S stop: the bob animation
           below used to animate transform, so the single most important thing
           on the screen rendered at (0,-1) — off in the corner — while every
           other stop sat correctly on the road. Measured, not guessed:
           computedTransform matrix(1,0,0,1,0,-1) against an inline
           translate(187.5px,340px). It reads exactly like "the journey is
           somewhere on the map you have to go looking for".
           The bob now animates top (this element is position:relative, so that
           moves it visually and touches no transform), and the press uses the
           standalone scale property, which composes with transform instead of
           overwriting it. */
        .wi-stop { -webkit-appearance:none; appearance:none; padding:0; cursor:pointer;
          position:absolute; top:0; left:0;   /* ⚠️ see THE RTL TRAP above */
          border-radius:50%; background:#fff; border:2.5px solid var(--wi-stop);
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 3px 10px rgba(40,25,70,.35); transition:scale .18s ease; }

        /* The road remembers. Every stop she finished carries a soft bloom in
           its own domain colour, so the path behind her is visibly warmer than
           the path ahead — presence left on the ground rather than a number in
           a corner. Drawn behind the marker and never interactive. */
        /* A finished day stops asking for attention: the bob is dropped and a
           check rides the marker, so the work she did is visible ON the road. */
        .wi-stop--complete { animation:none !important; }
        .wi-stop-check { position:absolute; right:-3px; bottom:-3px; width:20px; height:20px;
          border-radius:50%; background:#2E9E6B; border:2.5px solid #fff; color:#fff;
          font-size:11px; font-weight:900; line-height:1;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 2px 6px rgba(40,25,70,.4); pointer-events:none; }

        .wi-stop--done::after, .wi-stop--complete::after {
          content:''; position:absolute; inset:-11px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, var(--wi-stop) 0%, transparent 70%);
          opacity:.34; pointer-events:none;
          animation: wiBloom 6s ease-in-out infinite;
        }
        @keyframes wiBloom {
          0%,100% { transform: scale(1);    opacity:.30; }
          50%     { transform: scale(1.14); opacity:.42; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--done::after { animation:none; } }
        .wi-stop:active { scale:.9; }
        /* ⚠️ HIT SLOP, NOT A BIGGER BUTTON. A finished stop is 30px and a
           locked one 28px — well under the 44px a thumb needs — so taps that
           looked like they landed on a stop landed on the map instead, and the
           card "did not open". The circle keeps its size; only the target
           grows, behind it, invisible. */
        .wi-stop::before { content:''; position:absolute; inset:-9px; border-radius:50%; }
        .wi-stop-slot { display:flex; align-items:center; justify-content:center; line-height:0; }
        /* Sits under the circle, reads over any ground the map puts behind it. */
        /* Dark ink inside a white halo, NOT white text: the ground under these
           labels is a pale lavender city, and white-on-pale left "אתמול · היום ·
           מחר" barely there - the one thing that tells her which way her own
           road runs. */
        .wi-stop-cap { position:absolute; top:100%; margin-top:7px; left:50%;
          transform:translateX(-50%); white-space:nowrap; pointer-events:none;
          font-size:11.5px; font-weight:900; color:#241C3A; letter-spacing:.01em;
          /* A solid light pill so the label reads on ANY surface — the pale map OR
             the dark purple road. Dark text over a white glow alone vanished on the
             road (looked white/unreadable). */
          background:rgba(255,255,255,0.94); padding:2px 9px; border-radius:999px;
          box-shadow:0 1px 5px rgba(26,20,38,0.18); text-shadow:none; }
        /* Future captions (מחר) sit ABOVE their circle so a small node's label
           never lands on the big today node just below it. */
        .wi-stop-cap--above { top:auto; bottom:100%; margin-top:0; margin-bottom:7px; }

        /* ── The road back, and the ghost of what is still folded away ──
           The journey card's own two nodes, planted on the map: a neutral 42px
           circle carrying the arrow, and one faint dashed node behind it so the
           road never looks like it ends. Same sizes, same weights, same colours
           as JourneyHeroCard — they are the same control, on a different
           surface. */
        /* Her coin, waiting on the road. No border and no white plate — it is
           an object lying there, not another station. */
        .wi-stop--coin  { width:44px; height:44px; background:transparent; border:none;
                          box-shadow:none; }
        .wi-stop--coin::after {
          content:''; position:absolute; inset:-10px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, #8B60EA 0%, transparent 70%);
          opacity:.42; pointer-events:none; animation: wiBloom 3.4s ease-in-out infinite;
        }
        .wi-stop--back  { width:42px; height:42px; background:#F1EEF6; border:2px solid #E3DCEF;
                          box-shadow:0 3px 10px rgba(40,25,70,.22); }
        .wi-stop--ghost { width:36px; height:36px; background:#F1EEF6; border:2px dashed #E3DCEF;
                          opacity:.42; pointer-events:none; box-shadow:none; }
        .wi-stop--done   { width:30px; height:30px; opacity:.9; }
        .wi-stop--ahead  { width:28px; height:28px; opacity:.6; border-style:dashed; }
        .wi-stop--locked { width:28px; height:28px; opacity:.5; border-style:dashed; }
        .wi-stop--today  { width:70px; height:70px; border-width:5px;
          box-shadow:0 0 0 9px color-mix(in srgb, var(--wi-stop) 22%, transparent), 0 8px 22px rgba(40,25,70,.4);
          animation: wiStopBob 2.1s ease-in-out infinite; }
        .wi-stop--today .wi-stop-core { width:24px; height:24px; }
        @keyframes wiStopBob {
          0%,100% { top: 0; }
          50%     { top: -5px; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--today { animation:none; } }
      `}),ne.jsx("div",{ref:I,style:{width:"100%",height:"100%"}})]})}export{Oe as default,Me as isWebGLAvailable};
