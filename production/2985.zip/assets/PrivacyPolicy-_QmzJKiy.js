import{r as s,j as n}from"./ui-vendor-D8bhJbis.js";import{L as c,a as l,b as d}from"./LegalPageShell-DCF1dCH0.js";import"./index-DQVrM8f5.js";import"./data-vendor-C2RBbgTV.js";const e="support@app.walkimpact.com";function g(){const[a,i]=s.useState("he"),t={en:{title:"Privacy Policy",lastUpdated:"Last Updated: July 2026",intro:"This Privacy Policy describes how WalkImpact handles personal and health-related information. WalkImpact is a digital supportive well-being tool for caregivers and partners of individuals coping with trauma, based on research-proven therapeutic approaches. It is not a substitute for professional therapy, it is not a medical device, and it does not provide diagnosis or treatment. Please read this policy carefully together with our Terms of Service.",sections:[{title:"1. Who We Are (Data Controller)",content:`WalkImpact ('WalkImpact', 'we', 'our', or 'us') is the data controller responsible for your personal information processed through our website, mobile applications, and related services (collectively, the 'Services').

For any privacy request or question, contact our privacy team at `+e+". Where required by law, we will respond within the timeframes set by applicable regulation."},{title:"2. Scope & Legal Frameworks",content:`We design our privacy practices to comply with:

• Israel - the Protection of Privacy Law, 5741-1981, and its regulations (including the Data Security Regulations, 2017) and Amendment 13 (2024/2025).
• European Union / EEA / UK - the General Data Protection Regulation (GDPR) and UK GDPR.
• United States - the California Consumer Privacy Act as amended by the CPRA (CCPA/CPRA), and applicable health-privacy frameworks. Where we act as a business associate handling Protected Health Information (PHI) on behalf of a covered entity, we apply HIPAA-aligned safeguards.

If there is a conflict between this policy and a mandatory legal right available to you in your jurisdiction, that legal right prevails.`},{title:"3. Information We Collect",content:`Information you provide directly:

• Account & identity data: name, email address, phone number, login credentials, preferred language.
• Profile & relationship data: your role (e.g., partner, parent, caregiver), gender, and the gender/relationship of the person you support.
• Sensitive well-being data: daily check-ins, mood and energy logs, stress/caregiver-load indicators, questionnaire responses (e.g., baseline resilience scores), free-text reflections, and conversation content with our AI guide.
• Communications: support tickets, feedback, and correspondence with us.

Information collected automatically:

• Usage data: features used, exercises completed, session duration, streaks, in-app events.
• Technical data: device type, operating system, app version, IP address, and approximate (coarse) location derived from IP.
• Cookies and similar technologies on our website.

We do NOT collect data about the person you care for beyond what you voluntarily provide about your own experience as a caregiver.`},{title:"4. Sensitive / Special-Category Data",content:`Some information you share reflects your mental and emotional state and is treated as special-category (sensitive) data under the GDPR and as sensitive personal information under the CPRA. We process it only:

• With your explicit, freely-given consent, which you may withdraw at any time; and
• Solely to provide, personalize, and improve the supportive content and adaptive recommendations within the Services.

We do not use your sensitive well-being data for advertising, and we never sell it.`},{title:"5. How We Use Your Information (Purposes & Legal Bases)",content:`We process your information to:

• Provide the Services and your personalized journey - legal basis: performance of a contract / explicit consent for sensitive data.
• Adapt exercises and recommendations based on your check-ins and history - legal basis: explicit consent.
• Maintain safety features, including surfacing crisis resources - legal basis: legitimate interest and protection of vital interests.
• Communicate service updates, reminders, and respond to support requests - legal basis: contract / legitimate interest.
• Improve and secure the Services using aggregated or de-identified analytics - legal basis: legitimate interest.
• Comply with legal obligations - legal basis: legal obligation.

We do not make decisions producing legal or similarly significant effects about you based solely on automated processing.`},{title:"5a. Communications & Notifications (Email / WhatsApp)",content:`If you provide an email address or phone number, we may send you service-related and supportive communications, including: weekly follow-up check-in reminders, daily practice reminders, important account or safety notices, product updates, and - only with your consent - a newsletter.

• Reminders and transactional messages are part of providing the Services.
• Marketing/newsletter messages are sent only to users who opted in, and you can unsubscribe at any time using the link in the email, by adjusting your in-app notification preferences, or by contacting us.
• WhatsApp messages are delivered through a third-party messaging provider and only to numbers you provided for this purpose. Standard message rates from your carrier may apply.

Withdrawing consent to marketing does not affect essential service messages required to operate your account.`},{title:"6. AI-Powered Features",content:"Certain features use artificial intelligence to generate supportive, educational content and to tailor recommendations. AI outputs are for self-help and educational purposes only and are not medical, psychological, or professional therapeutic advice. Content you enter into AI features may be processed by contracted service providers solely to generate a response, subject to contractual confidentiality and data-protection obligations."},{title:"7. How We Share Information",content:`We do not sell or rent your personal information. We share it only as follows:

• Service providers / sub-processors: cloud hosting, infrastructure, email/SMS delivery, and AI inference providers - bound by contract (Data Processing Agreements) to protect your data and act only on our instructions.
• Organizational (B2B) partners: if you joined through an organization, we may share only aggregated cohort statistics that do not identify any individual - never your individual identifiable well-being data.
• Legal & safety: to comply with law, lawful requests, or to protect the rights, safety, and security of users and the public.
• Business transfers: in a merger, acquisition, or asset sale, subject to this policy and applicable law.`},{title:"8. International Data Transfers",content:"We may process and store information in countries other than your own, including Israel, the EEA, and the United States. Where we transfer personal data internationally, we rely on lawful transfer mechanisms such as the European Commission's Standard Contractual Clauses, the UK International Data Transfer Addendum, adequacy decisions (including the EU adequacy decision recognizing Israel), and equivalent safeguards."},{title:"9. Data Retention",content:`We keep personal information only for as long as necessary for the purposes described in this policy:

• Account and profile data: for the life of your account.
• Well-being and journey data: while your account is active, so you can track progress over time.
• After account deletion: we delete or irreversibly anonymize your personal data within a reasonable period (typically up to 90 days), except where we must retain limited records to meet legal, tax, or security obligations.`},{title:"10. Data Security",content:`We apply technical and organizational measures aligned with Israel's Data Security Regulations and accepted industry standards, including encryption of data in transit and at rest, access controls and authentication, and security monitoring.

No system is perfectly secure. We maintain an incident-response process and, where required by law, will notify you and the relevant authorities of a data breach without undue delay.`},{title:"11. Your Privacy Rights",content:`Subject to your jurisdiction, you may have the right to:

• Access and receive a copy of your personal data
• Correct inaccurate or incomplete data
• Delete your data ('right to be forgotten')
• Restrict or object to certain processing
• Data portability
• Withdraw consent at any time (without affecting prior lawful processing)
• Lodge a complaint with a supervisory authority (e.g., the Israeli Privacy Protection Authority, your EU Data Protection Authority, or the UK ICO)

California residents (CCPA/CPRA): you have the right to know, delete, correct, and limit the use of sensitive personal information, and the right not to be discriminated against for exercising your rights. We do not sell or 'share' your personal information for cross-context behavioral advertising.

To exercise any right, email `+e+". We will verify your identity before responding. You may use an authorized agent where the law permits."},{title:"12. Cookies & Tracking",content:"Our website uses essential cookies and limited analytics to operate and improve the site. You can control non-essential cookies through your browser settings or our consent banner where applicable. Our mobile apps use device identifiers and local storage to keep you signed in and remember your preferences."},{title:"13. Children's Privacy",content:"The Services are intended for adults aged 18 and over. We do not knowingly collect personal information from individuals under 18. If we learn that we have collected such information, we will delete it. If you believe a minor has provided us data, contact "+e+"."},{title:"14. Not an Emergency Service",content:"WalkImpact does not provide emergency, crisis, or medical services. If you or someone else is in danger or experiencing a medical or mental-health emergency, contact your local emergency number immediately (in Israel: 101 / ERAN 1201) or a qualified professional."},{title:"15. Changes to This Policy",content:"We may update this Privacy Policy from time to time. Material changes will be communicated through the Services or by email, and we will update the 'Last Updated' date above. Your continued use after an update constitutes acceptance of the revised policy where permitted by law."},{title:"16. Contact Us",content:`For any privacy question or to exercise your rights, contact our privacy team:

Email: `+e+`
Website: www.walkimpact.com`}]},he:{title:"מדיניות פרטיות",lastUpdated:"עודכן לאחרונה: יולי 2026",intro:"מדיניות פרטיות זו מתארת כיצד WalkImpact מטפלת במידע אישי ובמידע הקשור לבריאות. WalkImpact היא כלי תומך דיגיטלי לרווחה עבור מלווים ובני/בנות זוג של אנשים המתמודדים עם טראומה, המבוסס על גישות טיפוליות מוכחות מחקרית. היא אינה תחליף לטיפול מקצועי, אינה מכשיר רפואי ואינה מספקת אבחון או טיפול. אנא קראו מדיניות זו בעיון יחד עם תנאי השימוש שלנו.",sections:[{title:"1. מי אנחנו (בעל השליטה במידע)",content:`WalkImpact ('WalkImpact', 'אנחנו', 'שלנו') היא בעלת השליטה במידע האחראית על המידע האישי שלך המעובד דרך האתר, האפליקציות והשירותים הנלווים שלנו (יחד, 'השירותים').

לכל בקשה או שאלה בנושא פרטיות, ניתן לפנות לצוות הפרטיות שלנו בכתובת `+e+". ככל שנדרש על פי דין, נשיב בתוך פרקי הזמן הקבועים בחוק החל."},{title:"2. תחולה ומסגרות חוקיות",content:`אנו מעצבים את נוהלי הפרטיות שלנו כדי לעמוד ב:

• ישראל - חוק הגנת הפרטיות, התשמ"א-1981, ותקנותיו (כולל תקנות הגנת הפרטיות (אבטחת מידע), התשע"ז-2017) ותיקון 13.
• האיחוד האירופי / EEA / בריטניה - תקנת הגנת המידע הכללית (GDPR) וה-UK GDPR.
• ארצות הברית - חוק הפרטיות של קליפורניה כפי שתוקן ב-CPRA (CCPA/CPRA), ומסגרות פרטיות בריאותיות החלות. כאשר אנו פועלים כספק (Business Associate) המטפל במידע בריאותי מוגן (PHI) עבור גורם מטפל, אנו מיישמים אמצעי הגנה בהתאם לעקרונות HIPAA.

במקרה של סתירה בין מדיניות זו לבין זכות משפטית מחייבת העומדת לך בתחום השיפוט שלך, הזכות המשפטית גוברת.`},{title:"3. מידע שאנו אוספים",content:`מידע שאתה מספק ישירות:

• נתוני חשבון וזיהוי: שם, כתובת אימייל, מספר טלפון, פרטי התחברות, שפה מועדפת.
• נתוני פרופיל ויחסים: תפקידך (למשל בן/בת זוג, הורה, מלווה), מגדר, והמגדר/סוג הקשר של האדם שאתה תומך בו.
• מידע רגיש על רווחה נפשית: צ׳ק-אין יומי, יומני מצב רוח ואנרגיה, מדדי עומס מטפל, תשובות לשאלונים (למשל ציוני חוסן בסיסיים), טקסט חופשי של רפלקציות, ותוכן שיחות עם המלווה ה-AI שלנו.
• תקשורת: פניות תמיכה, משוב והתכתבויות איתנו.

מידע הנאסף אוטומטית:

• נתוני שימוש: תכונות שבהן נעשה שימוש, תרגילים שהושלמו, משך מפגשים, רצפים, אירועים באפליקציה.
• נתונים טכניים: סוג מכשיר, מערכת הפעלה, גרסת אפליקציה, כתובת IP ומיקום משוער (גס) הנגזר מה-IP.
• עוגיות וטכנולוגיות דומות באתר שלנו.

איננו אוספים מידע על האדם שאתה מלווה מעבר למה שאתה בוחר לשתף מרצונך על החוויה שלך כמלווה.`},{title:"4. מידע רגיש / סוג מיוחד",content:`חלק מהמידע שאתה משתף משקף את מצבך הנפשי והרגשי ומטופל כמידע מסוג מיוחד (רגיש) לפי ה-GDPR וכמידע אישי רגיש לפי ה-CPRA. אנו מעבדים אותו רק:

• בהסכמתך המפורשת והחופשית, אותה תוכל לבטל בכל עת; וכן
• אך ורק לצורך מתן, התאמה אישית ושיפור התכנים התומכים וההמלצות המסתגלות בשירותים.

איננו משתמשים במידע הרגיש שלך לפרסום, ולעולם איננו מוכרים אותו.`},{title:"5. כיצד אנו משתמשים במידע (מטרות ובסיסים חוקיים)",content:`אנו מעבדים את המידע שלך כדי:

• לספק את השירותים ואת המסע האישי שלך - בסיס חוקי: ביצוע חוזה / הסכמה מפורשת למידע רגיש.
• להתאים תרגילים והמלצות על בסיס הצ׳ק-אין וההיסטוריה שלך - בסיס חוקי: הסכמה מפורשת.
• לתחזק תכונות בטיחות, כולל הצגת משאבי משבר - בסיס חוקי: אינטרס לגיטימי והגנה על אינטרסים חיוניים.
• לתקשר עדכוני שירות, תזכורות ולהשיב לבקשות תמיכה - בסיס חוקי: חוזה / אינטרס לגיטימי.
• לשפר ולאבטח את השירותים באמצעות ניתוחים מצרפיים או ללא פרטים מזהים - בסיס חוקי: אינטרס לגיטימי.
• לעמוד בחובות חוקיות - בסיס חוקי: חובה חוקית.

איננו מקבלים החלטות בעלות השלכות משפטיות או משמעותיות דומות לגביך המבוססות אך ורק על עיבוד אוטומטי.`},{title:"5א. תקשורת והתראות (אימייל / וואטסאפ)",content:`אם תספק/י כתובת אימייל או מספר טלפון, אנו עשויים לשלוח לך תקשורת הקשורה לשירות ותקשורת תומכת, ובכלל זה: תזכורות לשאלון מעקב שבועי, תזכורות לתרגול יומי, הודעות חשובות על החשבון או הבטיחות, עדכוני מוצר, ו - רק בהסכמתך - ניוזלטר.

• תזכורות והודעות תפעוליות הן חלק ממתן השירות.
• הודעות שיווק/ניוזלטר נשלחות רק למשתמשים שנתנו הסכמה (Opt-in), וניתן להסיר את ההרשמה בכל עת באמצעות הקישור באימייל, דרך הגדרות ההתראות באפליקציה, או בפנייה אלינו.
• הודעות וואטסאפ נשלחות דרך ספק הודעות צד שלישי ורק למספרים שמסרת למטרה זו. ייתכנו עלויות הודעה רגילות מצד הספק הסלולרי שלך.

ביטול הסכמה לדיוור שיווקי אינו משפיע על הודעות שירות חיוניות הנדרשות לתפעול החשבון שלך.`},{title:"6. תכונות מבוססות בינה מלאכותית (AI)",content:"תכונות מסוימות משתמשות בבינה מלאכותית כדי לייצר תוכן תומך וחינוכי ולהתאים המלצות. תוצרי ה-AI מיועדים לעזרה עצמית ולמטרות חינוכיות בלבד ואינם מהווים ייעוץ רפואי, פסיכולוגי או טיפולי מקצועי. תוכן שאתה מזין בתכונות ה-AI עשוי להיות מעובד על ידי ספקי שירות בחוזה אך ורק לצורך יצירת תגובה, בכפוף להתחייבויות חוזיות של סודיות והגנת מידע."},{title:"7. כיצד אנו משתפים מידע",content:`איננו מוכרים או משכירים את המידע האישי שלך. אנו משתפים אותו רק כמפורט:

• ספקי שירות / מעבדי משנה: אחסון בענן, תשתיות, שליחת אימייל/SMS וספקי הסקת AI - מחויבים בחוזה (הסכמי עיבוד נתונים) להגן על המידע שלך ולפעול אך ורק לפי הוראותינו.
• שותפים ארגוניים (B2B): אם הצטרפת דרך ארגון, אנו עשויים לשתף רק נתונים סטטיסטיים מצרפיים שאינם מזהים אף אדם - לעולם לא מידע אישי מזהה על הרווחה שלך.
• חוק ובטיחות: כדי לעמוד בדין, בבקשות חוקיות, או כדי להגן על זכויות, בטיחות וביטחון של משתמשים והציבור.
• העברות עסקיות: במיזוג, רכישה או מכירת נכסים, בכפוף למדיניות זו ולדין החל.`},{title:"8. העברות מידע בינלאומיות",content:"אנו עשויים לעבד ולאחסן מידע במדינות שונות משלך, כולל ישראל, האזור הכלכלי האירופי (EEA) וארצות הברית. כאשר אנו מעבירים מידע אישי בינלאומית, אנו מסתמכים על מנגנוני העברה חוקיים כגון סעיפים חוזיים סטנדרטיים (SCC) של הנציבות האירופית, תוספת ההעברה הבינלאומית של בריטניה, החלטות נאותות (כולל החלטת הנאותות של האיחוד האירופי המכירה בישראל), ואמצעי הגנה שווי ערך."},{title:"9. שמירת מידע",content:`אנו שומרים מידע אישי רק למשך הזמן הנדרש למטרות המתוארות במדיניות זו:

• נתוני חשבון ופרופיל: למשך חיי החשבון שלך.
• נתוני רווחה ומסע: כל עוד החשבון שלך פעיל, כדי שתוכל לעקוב אחר התקדמותך לאורך זמן.
• לאחר מחיקת חשבון: אנו מוחקים או הופכים לאנונימיים באופן בלתי הפיך את הנתונים האישיים שלך בתוך פרק זמן סביר (בדרך כלל עד 90 ימים), למעט כאשר עלינו לשמור רשומות מוגבלות לצורך עמידה בחובות חוקיות, מס או אבטחה.`},{title:"10. אבטחת מידע",content:`אנו מיישמים אמצעים טכניים וארגוניים בהתאם לתקנות אבטחת המידע בישראל ולתקנים מקובלים בתעשייה, ובכלל זה הצפנת מידע בתעבורה ובמנוחה, בקרות גישה ואימות, וניטור אבטחה.

אף מערכת אינה מאובטחת לחלוטין. אנו מקיימים תהליך תגובה לאירועים, וככל שנדרש על פי דין נודיע לך ולרשויות הרלוונטיות על אירוע אבטחת מידע ללא דיחוי בלתי סביר.`},{title:"11. הזכויות שלך בנושא פרטיות",content:`בכפוף לתחום השיפוט שלך, ייתכן שעומדת לך הזכות:

• לגשת ולקבל עותק של המידע האישי שלך
• לתקן מידע שגוי או חלקי
• למחוק את המידע שלך ('הזכות להישכח')
• להגביל או להתנגד לעיבוד מסוים
• לניידות מידע
• לבטל הסכמה בכל עת (מבלי לפגוע בעיבוד חוקי קודם)
• להגיש תלונה לרשות פיקוח (למשל הרשות להגנת הפרטיות בישראל, רשות הגנת המידע באיחוד האירופי, או ה-ICO בבריטניה)

תושבי קליפורניה (CCPA/CPRA): עומדת לך הזכות לדעת, למחוק, לתקן ולהגביל את השימוש במידע אישי רגיש, והזכות שלא להיות מופלה בשל מימוש זכויותיך. איננו מוכרים או 'משתפים' את המידע האישי שלך לפרסום התנהגותי חוצה-הקשרים.

כדי לממש זכות כלשהי, שלח אימייל לכתובת `+e+". נאמת את זהותך לפני שנשיב. ניתן להשתמש בנציג מורשה במקום שהחוק מתיר."},{title:"12. עוגיות ומעקב",content:"האתר שלנו משתמש בעוגיות חיוניות ובניתוחים מוגבלים כדי להפעיל ולשפר את האתר. תוכל לשלוט בעוגיות שאינן חיוניות דרך הגדרות הדפדפן או באנר ההסכמה שלנו במקום הרלוונטי. האפליקציות שלנו משתמשות במזהי מכשיר ובאחסון מקומי כדי לשמור אותך מחובר ולזכור את העדפותיך."},{title:"13. פרטיות ילדים",content:"השירותים מיועדים למבוגרים בני 18 ומעלה. איננו אוספים ביודעין מידע אישי מאנשים מתחת לגיל 18. אם נגלה שאספנו מידע כזה, נמחק אותו. אם אתה סבור שקטין מסר לנו מידע, פנה אל "+e+"."},{title:"14. אינו שירות חירום",content:'WalkImpact אינה מספקת שירותי חירום, משבר או שירותים רפואיים. אם אתה או מישהו אחר נמצא בסכנה או חווה מצב חירום רפואי או נפשי, פנה מיד למספר החירום המקומי (בישראל: 101 / ער"ן 1201) או לאיש מקצוע מוסמך.'},{title:"15. שינויים במדיניות זו",content:"אנו עשויים לעדכן מדיניות פרטיות זו מעת לעת. שינויים מהותיים יימסרו דרך השירותים או באימייל, ונעדכן את תאריך 'עודכן לאחרונה' למעלה. המשך השימוש שלך לאחר עדכון מהווה הסכמה למדיניות המעודכנת ככל שהדין מתיר."},{title:"16. צור קשר",content:`לכל שאלה בנושא פרטיות או למימוש זכויותיך, פנה לצוות הפרטיות שלנו:

אימייל: `+e+`
אתר: www.walkimpact.com`}]}}[a];return n.jsx(c,{lang:a,onLangChange:i,iconName:"lock",title:t.title,tagline:"Empowering Those Who Support Our Heroes",updated:t.lastUpdated,intro:t.intro,children:t.sections.map((o,r)=>n.jsx(l,{title:o.title,children:n.jsx(d,{children:o.content})},r))})}export{g as default};
