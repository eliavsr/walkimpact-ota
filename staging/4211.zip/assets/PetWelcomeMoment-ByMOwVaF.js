import{cQ as $,cR as R,cS as A,cT as I,n as N,be as T,cP as j,b as _,cU as L,L as x,c as k,t as O}from"./index-B_AS1dsX.js";import{a as C,e as D}from"./clinicalEngine-DdX2f_Dy.js";import{c0 as P,r as v,j as l,a3 as u}from"./ui-vendor-mKHLcNOY.js";import{A as M}from"./AnimatedPet-CWQAlibI.js";const w={spouse_hetero:{he:"בן/בת זוג",en:"spouse/partner"},spouse_lgbtq:{he:"בן/בת זוג",en:"partner"},parent:{he:"הורה",en:"parent"},sibling:{he:"אח/אחות",en:"sibling"},commander:{he:"מפקד/ת",en:"commander"},therapist:{he:"מטפל/ת",en:"therapist"},friend:{he:"חבר/ה",en:"friend"},other:{he:"תומך/ת",en:"supporter"}};function B(i,r,d){return(r||[]).map(a=>{const e=i[a.id];if(e===void 0)return null;const t=a.reverse?3-e:e;return{text:d?a.text:a.text_en||a.text,difficulty:t,theme:a.theme}}).filter(Boolean).sort((a,e)=>e.difficulty-a.difficulty).filter(a=>a.difficulty>=2).slice(0,4)}function Y({answers:i={},questions:r=[],profile:d={},isHe:o=!0,limit:a=3}){return(r||[]).map(e=>{const t=i[e.id];if(t===void 0)return null;const n=o?e.scale==="frequency"?$:R:e.scale==="frequency"?A:I;return{id:e.id,theme:e.theme,difficulty:e.reverse?3-t:t,text:o?N(e.text,d):e.text_en||e.text,answerLabel:(n==null?void 0:n[t])??""}}).filter(e=>e&&e.difficulty>=2).sort((e,t)=>t.difficulty-e.difficulty).slice(0,a)}async function V({answers:i={},profile:r={},focus:d,isHe:o=!0,questions:a=[]}){const e=C(i,r,d,o);try{const t=D(i,r),n=T(r)===j.FEMALE,h=w[r.relationship_type]||w.other,m=B(i,a,o),s=(r.display_name||"").trim(),E=Object.values(i).reduce((p,S)=>p+(S??0),0),y=m.length?m.map(p=>`- ${p.text} (${o?"עוצמה":"intensity"} ${p.difficulty}/3)`).join(`
`):o?"- אין פריטים בעוצמה גבוהה":"- no high-intensity items",f=o?`את/ה הקול החם והמקצועי של WalkImpact - אפליקציה תומכת למלווים של אנשים עם טראומה (PTSD).
כתוב/י שיקוף אישי - 2 עד 3 משפטים בלבד, פסקה אחת, בעברית.
המשתמש/ת הוא/היא המלווה (לא הנפגע).

כלל דקדוקי מחייב - מגדר הפנייה:
פנה/י אל המלווה ${n?'בלשון נקבה בלבד: "את", "מרגישה", "סיפרת", "שלך", "את יכולה", "נתחיל יחד".':'בלשון זכר בלבד: "אתה", "מרגיש", "סיפרת", "שלך", "אתה יכול", "נתחיל יחד".'}
אסור לערבב מגדרים. אסור להשתמש בצורות לוכסן ("את/ה", "מרגיש/ה", "יכול/ה") - צורה דקדוקית אחת עקבית לאורך כל הפסקה.

הכלל החשוב ביותר - היה ספציפי:
השיקוף חייב להישען על מה ש${n?"היא סיפרה":"הוא סיפר"} בפועל, ולהזכיר בעדינות לפחות נושא אחד קונקרטי מהרשימה למטה.
אם הפסקה שכתבת הייתה יכולה להישלח לכל משתמש אחר - נכשלת. כתוב/י מחדש.
אסור לכתוב מחמאות כלליות על אופי (כמו "העומק האנושי שלך", "החוסן הפנימי שלך", "עדות ל...", "אני מאמין בך"). זו חנופה, לא הקשבה, והיא שוחקת אמון.

חוקי טון מחייבים:
- לשקף בלי לשפוט. לא לדרג תחומים ("הכי קשה", "הכי מעיק", "בעייתי"), ולא לרמוז שמשהו שבור.
- להזכיר מה ש${n?"סיפרה":"סיפר"} זה לא שיפוט - זו הוכחה שהקשבנו.
- לא להאשים, לא לפתור, לא להבטיח החלמה.
- עברית פשוטה ואנושית. בלי שפה טיפולית מנופחת.

מה ${n?"היא סיפרה":"הוא סיפר"} לנו:
- שם: ${s||"לא צוין"}
- הקשר לנפגע: ${h.he}
- הנושאים שעלו (המספר הוא להקשר שלך בלבד - אל תכתוב/י מספרים בטקסט):
${y}

מבנה: משפט ראשון - לשקף בשקט משהו קונקרטי ש${n?"היא סיפרה":"הוא סיפר"}, במילים שלך. משפט אחרון - מאיפה נתחיל יחד ולמה דווקא שם.
בלי כותרת, בלי אימוג'י, בלי מספרים בגוף הטקסט.

חוק קריטי - אסור להשתמש בשמות פרטיים:
אסור לפתוח את הפסקה בשם פרטי. אסור להמציא שם. אסור להזכיר שם פרטי כלשהו בתוך הטקסט.
אם את/ה רוצה לפנות אישית - כתוב/י "את" או "אתה" בלבד. אל תכתוב/י שם פרטי בשום מקום בפסקה.
הפרת החוק הזה תהרוס את האמון של המשתמש/ת - זה החוק החשוב ביותר בכל הפרומפט.`:`You are the warm, professional voice of WalkImpact — a support app for caregivers of people with trauma (PTSD), grounded in research-backed therapeutic approaches.
Write a personal reflection — 2 to 3 sentences ONLY, one paragraph, in English.
The user is the CAREGIVER (not the trauma survivor).

THE MOST IMPORTANT RULE — BE SPECIFIC:
Ground the reflection in what they ACTUALLY told us, and gently name at least one concrete thing from the list below.
If the paragraph you wrote could be sent to any other user — you failed. Write it again.
Never write generic character compliments ("your human depth", "your inner resilience", "a testament to...", "I believe in you"). That is flattery, not listening, and it destroys trust.

Mandatory tone rules:
- Reflect without judging. Do NOT rank areas ("hardest", "heaviest", "biggest problem"), and never imply something is broken.
- Naming what they told us is NOT judgment — it is proof we listened.
- Don't blame, don't fix, don't promise recovery.
- Plain, human English. No inflated therapy-speak.

What they told us:
- Name: ${s||"not provided"}
- Relationship to survivor: ${h.en}
- Themes that came up (the number is for YOUR context only — never write numbers):
${y}

Structure: first sentence — quietly reflect something concrete they told us, in your own words. Last sentence — where we'll start together and why there.
No title, no emoji, no numbers in the body.

CRITICAL RULE — NO FIRST NAMES:
Do NOT open the paragraph with a first name. Do NOT invent a name. Do NOT mention any first name anywhere in the text.
If you want to address them personally, use "you" only. Never write a first name anywhere in the paragraph.
Violating this rule will destroy the user's trust — this is the most important rule in the entire prompt.`,c=await _.integrations.Core.InvokeLLM({prompt:f}),g=(typeof c=="string"?c:(c==null?void 0:c.text)||"").trim();return g?o?N(g,r,{llmSafe:!0}):g:e}catch{return e}}const b=1450;function X({petType:i="dog",petName:r="",petGender:d="male",userName:o="",isHe:a=!0,onContinue:e}){const t=P(),[n,h]=v.useState(!!t),m=(r||"").trim(),s=(o||"").trim(),E=d==="female";v.useEffect(()=>{if(t){try{L(i)}catch{}return}const c=setTimeout(()=>{h(!0);try{L(i)}catch{}},b);return()=>clearTimeout(c)},[t,i]);const y=m?a?`${s?`היי ${s}, `:"היי, "}אני ${m}!`:`${s?`Hi ${s}, `:"Hi, "}I'm ${m}!`:a?`${s?`היי ${s}!`:"היי, אני כאן!"}`:`${s?`Hi ${s}!`:"Hi, I'm here!"}`,f=a?`מצאתי אותך. מכאן נלך יחד - ואני כבר ${E?"שמחה ומוכנה":"שמח ומוכן"} לצאת לדרך לצידך.`:"I found you. We go on together from here — and I'm so glad to walk beside you.";return l.jsxs(u.div,{initial:{opacity:0},animate:{opacity:1},onClick:n?e:void 0,className:"fixed inset-0 z-[80] flex flex-col items-center justify-center px-8 text-center",dir:a?"rtl":"ltr",style:{background:O("radial-gradient(circle at 50% 40%, rgba(255,247,251,0.98) 0%, rgba(245,241,251,0.98) 55%, rgba(255,245,248,0.99) 100%)"),backdropFilter:"blur(4px)"},children:[l.jsxs("div",{className:"mb-6 flex flex-col items-center",style:{minHeight:190,justifyContent:"flex-end"},children:[l.jsx(u.div,{initial:t?{scale:1,y:0,opacity:1}:{scale:.16,y:74,opacity:.4},animate:t?{scale:1,y:0,opacity:1}:{scale:[.16,.34,.3,.62,.56,1],y:[74,40,48,14,20,0],opacity:[.4,.7,.7,.92,.92,1]},transition:t?{duration:0}:{duration:b/1e3,times:[0,.22,.34,.6,.72,1],ease:"easeOut"},style:{transformOrigin:"50% 100%"},children:l.jsx(u.div,{animate:n&&!t?{y:[0,-7,0]}:{},transition:{duration:2.4,repeat:1/0,ease:"easeInOut"},children:l.jsx(M,{petType:i,mood:n?"greeting":"joyful",size:150})})}),l.jsx(u.span,{"aria-hidden":"true",initial:t?{scaleX:1,opacity:.16}:{scaleX:.18,opacity:.06},animate:t?{scaleX:1,opacity:.16}:{scaleX:[.18,.36,.64,1],opacity:[.06,.1,.13,.16]},transition:t?{duration:0}:{duration:b/1e3,ease:"easeOut"},style:{width:96,height:11,borderRadius:"50%",background:x.dark,marginTop:-6}})]}),l.jsx(u.h2,{initial:{y:14,opacity:0},animate:n?{y:0,opacity:1}:{y:14,opacity:0},transition:{delay:t?0:.28,duration:.34},className:"text-2xl font-black mb-2",style:{color:x.dark,letterSpacing:"-0.02em"},children:y}),l.jsx(u.p,{initial:{y:10,opacity:0},animate:n?{y:0,opacity:1}:{y:10,opacity:0},transition:{delay:t?0:.42,duration:.34},className:"text-sm font-medium mb-8 max-w-xs",style:{color:x.mid,lineHeight:1.6},children:f}),l.jsx(u.button,{initial:{opacity:0},animate:n?{opacity:1}:{opacity:0},transition:{delay:t?0:.62},disabled:!n,onClick:c=>{c.stopPropagation(),e==null||e()},className:"px-8 py-3 rounded-full text-sm font-bold text-white active:scale-95 transition-transform",style:{background:k,boxShadow:"0 4px 16px rgba(216,30,91,0.28)"},children:a?"יוצאים למסע ›":"Let's begin ›"})]})}export{X as P,V as a,Y as g};
