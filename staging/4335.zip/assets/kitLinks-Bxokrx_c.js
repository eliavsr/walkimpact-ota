import{bA as r}from"./index-CkXTPvvT.js";const u=[{key:"families",he:"Fighting families",icon:"family",color:"#14b8a6",line:"Partners, parents and siblings of someone who came home changed."},{key:"fighter",he:"Fighters",icon:"resilience",color:"#f59e0b",line:"The person who was there, still carrying it at home."},{key:"orgs",he:"Organizations",icon:"users",color:"#6366f1",line:"Municipalities, nonprofits, resilience centers, units and commanders."},{key:"employers",he:"Employers",icon:"handshake",color:"#8B60EA",line:"Workplaces with reservists and relatives of the wounded on staff."},{key:"donors",he:"Donors and funds",icon:"heart",color:"#D81E5B",line:"People who can hold fighting families, or introduce you to people who can."},{key:"press",he:"Press",icon:"announcement",color:"#2E7F8A",line:"Journalists, writers, and anyone with a platform."}],g={eyebrow:"Ambassador kit",title:"Pick who you are talking to.",titleTail:"Everything else is ready.",lede:"One table, six audiences. For each one: what to send, what to say, and what it opens for us.",cta:"Pick an audience"},f=[{key:"flyer_families",segment:"families",kind:"flyer",sort_order:10,title:"Flyer for fighting families",subtitle:"One printed page, ready to send or print.",url:"/print/walkimpact-flyer-families.pdf",download_url:"/print/walkimpact-flyer-families.pdf",audience_note:"For a partner, parent or sibling of someone who came home changed.",help_note:"One fighting family starting a journey. That is the number we count.",content_updated_date:"2026-07-21",update_note:"Hebrew only. Rewritten after the claims review."},{key:"page_families",segment:"families",kind:"page",sort_order:20,title:"Landing page for families",subtitle:"The family carries the hero. Who carries you?",url:"/families",audience_note:"The link to send in a message. Opens on any device.",help_note:"Direct signup. The shortest path from someone who cares to a family getting help."},{key:"page_fighter",segment:"fighter",kind:"page",sort_order:10,title:"Landing page for fighters",subtitle:"Someone is waiting for you. No diagnosis and no forms.",url:"/fighter",audience_note:'For the person who will say "I am not sick". This page was built for him.',help_note:"The softest entry we have. A companion to adopt, not a treatment to begin."},{key:"flyer_orgs",segment:"orgs",kind:"flyer",sort_order:10,title:"Flyer for organizations",subtitle:"What the organization gets, how it is measured, what it costs.",url:"/print/walkimpact-flyer-orgs.pdf",download_url:"/print/walkimpact-flyer-orgs.pdf",audience_note:"For a welfare director, a resilience center, a nonprofit CEO, a mayor.",help_note:"A pilot. This is what opens a whole community at once.",content_updated_date:"2026-07-21",update_note:"Hebrew only. Rewritten after the claims review."},{key:"page_orgs",segment:"orgs",kind:"page",sort_order:20,title:"Landing page for organizations",subtitle:"Includes the Mor-Yosef committee finding adopted by the government.",url:"/orgs",audience_note:"The link to send after a first conversation.",help_note:'Answers "we already have something" before you meet.'},{key:"flyer_employers",segment:"employers",kind:"flyer",sort_order:10,title:"Flyer for employers",subtitle:"A benefit that reaches the home, under the company brand.",url:"/print/walkimpact-flyer-employers.pdf",download_url:"/print/walkimpact-flyer-employers.pdf",audience_note:"For HR, employee wellbeing, or the CEO.",help_note:"Company sponsorship. Holds dozens of fighting families at once.",content_updated_date:"2026-07-21",update_note:"Hebrew only. Rewritten after the claims review."},{key:"page_employers",segment:"employers",kind:"page",sort_order:20,title:"Landing page for employers",subtitle:"Be the organization that stood beside them.",url:"/employers",audience_note:"To send after a hallway conversation at work.",help_note:"Turns a casual mention into a formal approach."},{key:"impact",segment:"donors",kind:"impact",sort_order:10,title:"The impact page",subtitle:"The full story with the research. One fighting family, 39 shekels a month.",url:"/impact",cta_label:"Open the page",audience_note:"For a donor, a fund, or anyone who asked what it costs to hold a family.",help_note:"A donation, and the page that convinces people who are undecided."},{key:"onepager_en",segment:"donors",kind:"deck",sort_order:5,title:"One-pager",subtitle:"One page with the story, the figures and their sources.",url:"/print/walkimpact-onepager-en.pdf",download_url:"/print/walkimpact-onepager-en.pdf",audience_note:"For a donor or a foundation who asked for something short.",help_note:"A donation, or a meeting. The easiest document to forward.",content_updated_date:"2026-08-08"},{key:"onepager_he",segment:"donors",kind:"deck",sort_order:6,title:"One-pager, Hebrew",subtitle:"The same page for a Hebrew reader.",url:"/print/walkimpact-onepager-he.pdf",download_url:"/print/walkimpact-onepager-he.pdf",audience_note:"For an Israeli donor or fund.",help_note:"Same document, no language barrier.",content_updated_date:"2026-08-08"},{key:"social_pack",segment:"all",kind:"creative",sort_order:40,title:"Social graphics",subtitle:"28 ads in three ratios and nine carousels, ready to upload.",url:"/lavie/kit#graphics",cta_label:"Open",audience_note:"For anyone posting on Facebook, Instagram, LinkedIn or TikTok.",help_note:"A post with real creative reads as a campaign, not a personal note.",content_updated_date:"2026-08-08"},{key:"card",segment:"donors",kind:"kit",sort_order:30,title:"Business card",subtitle:"With a QR code to the app.",url:"/print/walkimpact-card.pdf",download_url:"/print/walkimpact-card.pdf",audience_note:"For a conference, an event, a chance meeting.",help_note:"What someone carries home in a pocket."},{key:"download",segment:"all",kind:"page",sort_order:90,title:"App download page",subtitle:"Detects the device and sends people to the right store.",url:"/download",audience_note:'For when someone has already said "fine, send it to me".',help_note:"The last link before an install. Do not lead with it."}],y=[{key:"secondary",value:"1 in 3",line:"Relatives of a trauma survivor develop secondary traumatic stress themselves.",src:"Diehle 2017, a review of 36 studies: over 30% of partners. Frančišković 2007: 39%. In Israel, Solomon 1992, 205 wives of combat veterans."},{key:"proof",value:"d=0.82 to d=2.55",line:"The effect size of the same treatment when practice continues between sessions. Same therapists, and what changes is the practice at home.",src:"Brewin 2000, meta-analysis of 77 studies: lack of social support is the strongest risk predictor. Monson 2012, JAMA: including the partner in treatment improved the PTSD itself. Kazantzis 2016, n=2,312, g=0.51. Findings about practice and support in general, not about WalkImpact.",star:!0},{key:"gap",value:"1 hour against 167",line:"Treatment gets one hour a week. The fighting family holds the rest of it alone.",src:"The entitlement applies to those already recognized, at one hour a week. The 167 is our own arithmetic on the rest of the week, not a reported figure. People still inside the recognition process, and their households, usually do not get even the hour."},{key:"rebound",value:"48%",line:"Improved by the end of treatment, then slid back within four months.",src:"Grau, Sripada and others 2022, 10,832 military veterans. The authors conclude that the field needs ways to hold the gains after treatment ends."},{key:"social",value:"8 billion shekels",line:"A year, and only for the people the system already knows about.",src:"Israeli Ministry of Defense rehabilitation budget, 2025. The department projects 100,000 disabled veterans by 2030, about half of them psychological."},{key:"traction",value:"4,000",line:"Reservists and rescue personnel in Sderot receive the platform, fully subsidised.",src:"Sderot municipality programme. Covered by BR7, 29 July 2026."}],w={quote:`"The committee recognizes accompanying family members as a critical factor in the wounded person's rehabilitation, and recognizes the need for dedicated emotional and financial support for the family."`,src:"Mor-Yosef public committee, June 2026, recommendation 6. Adopted by the government in July 2026.",close:"The need is recognized. The open question is who answers it inside the homes."},k=[{key:"pitch_10",length_label:"10 seconds",title:"In an elevator or a message",body:"When a soldier comes home from war, the war for the home begins. WalkImpact gives the fighting family daily tools to hold it. Alongside the fighter, never instead of him."},{key:"pitch_30",length_label:"30 seconds",title:"In a real conversation",body:`WalkImpact is the first to look at everyone who loves a fighter: partners, parents, siblings, commanders, and the fighter himself.

Three minutes a day of practical tools. How to steady yourself, how to understand what he is going through, and how to talk when it is hard. Private, separated from your identity, with no diagnosis and no label.

It supports treatment rather than replacing it, and it costs the fighting family nothing.`},{key:"pitch_120",length_label:"2 minutes",title:"With someone who can decide",body:`Treatment gets one hour a week. The fighting family holds the other 167, and that is exactly where the thread breaks: waiting lists are long and there are not enough therapists. A study of 10,832 military veterans found that 48% of those who improved slid back within four months.

The research also shows what holds. Same treatment, same therapists, and the effect size moves from 0.82 to 2.55 when practice continues between sessions. Monson showed in JAMA that including the partner improved the PTSD itself, and Brewin found that lack of social support is the strongest predictor of risk. The difference is the home.

That is what WalkImpact does. It walks with the fighting family at home, between sessions, across three domains: my own resilience, understanding the person I love, and the bond between us. It is built on evidence-based therapeutic approaches.

We do not replace any organization or any therapist. We join them, extend their work into the home, and give them a picture they do not have today.

It was founded by Eliav Ser, a major in the reserves with over 450 days in combat, who belongs to this population himself.`}],b=["When a soldier comes home from war, the war for the home begins.","Alongside the fighter, never instead of him.","A professional GPS, not a train on a track."],v=[{msg_key:"wa_family",segment:"families",channel:"whatsapp",link_target:"families",sort_order:10,title:"Message to a family you know",body:`{your own opening line: why they came to mind}

There is an Israeli app called WalkImpact, built for everyone who loves a fighter after he comes home changed. The partner, the parent, the sibling, and the fighter himself.

Three minutes a day, private, no forms and no diagnosis. It costs a fighting family nothing.

I thought it might speak to you:
{link}`},{msg_key:"wa_group",segment:"fighter",channel:"whatsapp",link_target:"fighter",sort_order:20,title:"Message to a unit or reserves group",body:`This is worth knowing about.

WalkImpact is a platform for anyone who loves a fighter, and for the fighter himself. It was founded by Eliav Ser, a major in the reserves with 450 days in combat, who is part of this story.

Three minutes a day. Private, separated from your identity. Nobody looking down at you.

For anyone who wants it:
{link}`},{msg_key:"wa_commander",segment:"orgs",channel:"whatsapp",link_target:"orgs",sort_order:30,title:"Message to a commander",body:`I wanted to pass on something relevant to the unit.

WalkImpact gives fighters and their families daily private support between sessions and at home. It does not diagnose anyone and it does not replace treatment. It is a daily tool that builds resilience.

The commander sees no personal content. Aggregate trends only, and only from 11 participants up.

Worth five minutes?
{link}`},{msg_key:"wa_municipality",segment:"orgs",channel:"whatsapp",link_target:"orgs",sort_order:40,title:"Message to a municipal welfare director",note:"The strongest opening we have with a municipality, because the claim belongs to the state rather than to us.",body:`I am writing with a recommendation.

In June the Mor-Yosef committee found that accompanying family members are a critical factor in rehabilitation and that they deserve dedicated support. The government adopted it in July. What is missing is someone who reaches the homes.

WalkImpact does exactly that. It walks with every fighting family in the community between sessions, under your branding, with its own signup page. It already runs in Sderot, where 4,000 reservists and rescue personnel receive it fully subsidised.

A pilot of six to seven weeks, usually funded by a foundation or a donor.

Everything is here:
{link}`},{msg_key:"wa_hr",segment:"employers",channel:"whatsapp",link_target:"employers",sort_order:50,title:"Message to an HR lead",body:`An idea for a benefit that reaches the home and not only the employee.

Some of your people served in the reserves, and some are relatives of the wounded. They keep delivering at work while a quiet load continues at home.

WalkImpact is daily private support for the employee and the family, under your company brand. The company never sees any personal content.

Simple sponsorship by headcount, with no long commitment.

{link}`},{msg_key:"email_org",segment:"orgs",channel:"email",link_target:"orgs",sort_order:60,title:"Cold email to an organization",length_label:"Short email",body:`Subject: What happens to the fighting family between sessions

Hello {name},

{your own opening line}

Treatment gets one hour a week. The fighting family holds the rest of it alone, and that is where the thread breaks: long waiting lists and too few therapists. A study of 10,832 military veterans found that 48% of those who improved slid back within four months.

The research also shows what holds. Same treatment, same therapists, and the effect size moves from 0.82 to 2.55 when practice continues between sessions.

WalkImpact works there. We do not replace any organization or therapist. We join them and extend their work into the home. We already work with the Sderot municipality, the Sderot youth center, Misgav, Kfar Giladi and Menara.

Everything is gathered here: {link}
I am glad to introduce you directly to Eliav Ser, the founder.

Best,
{your name}`},{msg_key:"email_donor",segment:"donors",channel:"email",link_target:"impact",sort_order:65,title:"Email to a donor or foundation",length_label:"Short email",body:`Subject: Holding the families behind the wounded

Hello {name},

{your own opening line}

One in three relatives of a trauma survivor develops secondary traumatic stress themselves (Diehle 2017, a review of 36 studies). Almost every service is built for one person. The rest of the household, and often the fighter himself, are handed a hotline number.

WalkImpact is an Israeli platform that gives those families daily tools at home, between sessions, built on evidence-based therapeutic approaches. In Sderot it already reaches 4,000 reservists and rescue personnel, fully subsidised.

Holding one fighting family for a full year costs 468 shekels, about 39 a month.

The full picture with the research and the sources: {link}

I am glad to connect you to Eliav Ser, the founder, a major in the reserves who belongs to this population himself.

Best,
{your name}`},{msg_key:"linkedin_intro",segment:"all",channel:"linkedin",link_target:"impact_en",sort_order:70,title:"LinkedIn post",body:`When a soldier comes home from war, the war for the home begins.

Almost every service is built for one person. The rest of the household holds it with no tools and no map, and so, very often, does the fighter himself.

Treatment gets one hour a week. In those other hours, the research points one way: the effect size of the same treatment, with the same therapists, moves from 0.82 to 2.55 when practice continues between sessions (Kazantzis 2016, n=2,312). Monson found in JAMA that including the partner improved the PTSD itself.

WalkImpact works exactly there. Three minutes a day, private, built on evidence-based therapeutic approaches. We join therapists and organizations and extend their work into the home.

It was founded by Eliav Ser, a major in the reserves with over 450 days in combat, who belongs to this population himself.

If you know a family, a unit or an organization this belongs in, I am glad to make the introduction.

{link}`},{msg_key:"post_personal",segment:"all",channel:"post",link_target:"families",sort_order:80,title:"Post: why I am in",note:"Week 1 in the calendar. The first paragraph is yours, and the post does not work without it.",body:`{your story: a line or two about why this reached you}

I came across WalkImpact and could not stop thinking about it. It is the first thing I have seen built for everyone who loves a fighter: the partner, the parent, the sibling, the commander, and the fighter himself.

They all carry it, with no tools and no map.

That is what this app gives them. Three minutes a day, private, and free for a fighting family.

If you know a family, a unit or an organization this belongs in, pass it on. That is all I am asking.

{link}`},{msg_key:"post_problem",segment:"all",channel:"post",link_target:"families",sort_order:90,title:"Post: the problem, with its source",note:"Week 2. The source line is part of the post. Do not publish it without them.",body:`One in three relatives of a trauma survivor develops secondary traumatic stress themselves.
(Diehle 2017, a review of 36 studies)

Behind that number is a woman who learned to walk on eggshells in her own home, a parent who checks the weather in the living room before walking in, and a commander who keeps counting everyone long after his discharge.

At home, the hero is also the person awake at three in the morning.

WalkImpact was built for them. Three minutes a day, private, no diagnosis and no label.

{link}`},{msg_key:"story",segment:"all",channel:"story",link_target:"families",sort_order:100,title:"Story text for an image",length_label:"Two lines",body:`"You hold everyone.
Who holds you?"

Swipe up`},{msg_key:"linkedin_ask",segment:"orgs",channel:"linkedin",link_target:"impact_en",sort_order:110,title:"LinkedIn: asking for an introduction",note:"Week 4. One ask only: an introduction. No download, no donation.",body:`A short ask, and then I will get out of your feed.

WalkImpact supports the families of wounded fighters. The partner, the parent and the commander are the people holding the house together while everyone looks at the person who was hurt.

It already works with the Sderot municipality, the Sderot youth center, Misgav, Kfar Giladi and Menara. In Sderot, 4,000 reservists and rescue personnel receive it fully subsidised.

I am looking for one thing: an introduction. A municipality, a nonprofit, a resilience center, a company.

Reply here or send me a message and I will make the connection.

{link}`},{msg_key:"wa_webinar",segment:"all",channel:"webinar",link_target:"webinar",sort_order:120,title:"Event invitation",note:"The easiest ask there is. You are asking for an hour, not a commitment.",body:`{your own opening line: why they came to mind}

WalkImpact is hosting an online evening for anyone who loves a fighter. One hour, free, and nobody has to say a word. Listening is enough.

This time the evening is for you.

Register here:
{link}`},{msg_key:"reminder",segment:"all",channel:"reminder",link_target:"families",sort_order:130,title:'Follow up after "I will get back to you"',length_label:"Three lines",body:`Just floating this back up, no pressure.

If the timing is wrong, that is completely fine. If it is not, I am happy to set up a short call with Eliav.

{link}`},{msg_key:"oped",segment:"press",channel:"oped",link_target:"impact",sort_order:140,title:"Opinion piece to publish under your name",length_label:"About 600 words",note:"Every figure here is backed by a source in the numbers section. It makes no claim about results produced by WalkImpact, and it never uses the word clinical.",body:`The war nobody counts

{first paragraph: your own story. A family you know, something you saw, why it stays with you. Three or four lines, first person}

There is a second war, and it starts exactly when the first one ends. It has no start date and nobody counts casualties in it. It happens in the living room and the bedroom of the person who came home.

A review of thirty six studies found that one in three relatives of a trauma survivor develops secondary traumatic stress. In the large American study of Vietnam veterans, divorce rates in these families were double, and a third of partners reported violence at home, against under fourteen percent in the general population.

Trauma does not stay in the field, it travels home.

And still, almost every system we built looks at one person. He gets the appointment, the treatment and the budget. The person sitting beside him in the waiting room, the partner, the parent, the commander who keeps counting everyone long after discharge, usually gets a hotline number.

That is starting to change. In June the Israeli public committee on national rehabilitation for disabled veterans, chaired by Prof. Mor-Yosef, found that accompanying family members are a critical factor in rehabilitation and that they deserve dedicated support. The government adopted the programme in July.

So the need is now formally recognized. The open question is who answers it in practice, inside the homes rather than in a report.

Here the arithmetic gets simple. Treatment gets one hour a week. The family holds the rest alone, and that is where the thread breaks. A study of more than ten thousand patients found that forty eight percent of those who improved slid back within four months of finishing treatment.

The research also points to what holds. Same treatment, same therapists, and the effect size rises from 0.82 to 2.55 when practice continues between sessions. Monson showed in JAMA that including the partner in treatment improved the PTSD itself, and Brewin found across seventy seven studies that lack of social support is the strongest predictor of risk. Again and again, what holds is what happens at home.

That is the gap WalkImpact works in. It is an Israeli platform that gives the fighting family daily tools: steadying the nervous system, understanding what the person they love is going through, and finding words in the moments that have none. Three minutes a day, private, built on evidence-based therapeutic approaches. It does not diagnose and it does not promise outcomes, and it replaces no therapist and no organization. It joins them and extends their work into the home.

In Sderot it already works. Four thousand reservists and rescue personnel receive it fully subsidised. "The responsibility is not only to say thank you, but to give real tools," said Mayor Alon Davidi.

Its founder, Eliav Ser, is a major in the reserves with more than four hundred and fifty days in combat. He lives it himself.

{closing paragraph: one line of your own. What you want to happen}

The state has already руled that this support is owed to them. What is missing is someone who brings it as far as the home.`},{msg_key:"press_pitch",segment:"press",channel:"press",link_target:"impact",sort_order:150,title:"Pitch to a journalist",length_label:"Short email",body:`Subject: The angle nobody is covering, the fighting families

Hello {name},

{your own line: why you are writing to them specifically, and what they wrote that connects}

There is a story that barely gets covered. One in three relatives of a trauma survivor develops secondary traumatic stress themselves (Diehle 2017). The Mor-Yosef committee recognized it in June and the government adopted it in July, and in practice almost nothing reaches the homes.

An Israeli company works exactly there, WalkImpact. In Sderot it already reaches 4,000 reservists and rescue personnel fully subsidised, and BR7 covered it in July. It was founded by a major in the reserves with 450 days in combat who belongs to this population himself.

He is available to talk, and there are families willing to speak on the record.

Glad to connect you. {your name}, {phone}`},{msg_key:"press_release",segment:"press",channel:"press",link_target:"orgs",sort_order:160,title:"Press release template for a new partnership",note:"Fill in the brackets and send. The partner quote has to be approved by them in writing.",body:`{Organization} launches a support programme for fighting families

{City}, {date} - {Organization} is launching a joint programme with WalkImpact, an Israeli platform for daily support of fighting families. The programme gives {number} families in the community access to daily tools for steadying the nervous system, understanding trauma, and communicating inside the family, between sessions and at home.

The programme follows the finding of the Israeli public committee on national rehabilitation for disabled veterans (Mor-Yosef committee, June 2026), which recognized accompanying family members as a critical factor in rehabilitation and recognized their need for dedicated support. The government adopted the programme in July 2026.

"{quote from the head of the organization}", said {name and title}.

"To heal our heroes, we have to support the families, the caregivers and the commanders," said Eliav Ser, founder and CEO of WalkImpact and a major in the reserves. "We replace no therapist and no organization. We join them and extend their work into the home, in the hours when no therapist is available."

The platform is built on evidence-based therapeutic approaches, runs in full Hebrew, and separates activity from user identity. It also operates in Sderot, where 4,000 reservists and rescue personnel receive it fully subsidised, and in Misgav, Kfar Giladi and Menara.

Contact: eliav@walkimpact.com`}],_=[{q:"Does it cost anything?",a:"Not for a fighting family. Joining and daily use are free. Some routes come through partner organizations and municipalities, and then you enter an organization code at signup."},{q:"Will anyone know I am there? My commander? My employer?",a:"No. Activity is separated from identity. No full name is required, and nobody in the family, the unit or the organization gets access to what you wrote. Sharing is your decision alone.",note:'Note the wording: private, separated from identity. Not "anonymous". That distinction is legal, not stylistic.'},{q:"Does it replace treatment?",a:"No, and we say so plainly. It supports and accompanies treatment. It works in the gaps where no therapist is available: between sessions, after a workshop, while the waiting list is long. It does not diagnose and it does not promise an outcome."},{q:"Why should an organization work with you instead of carrying on as it is?",a:"Because the gap is what happens between sessions. A study of 10,832 military veterans found that 48% of those who improved slid back within four months. In the other direction: same treatment, same therapists, and the effect size moves from 0.82 to 2.55 when practice continues at home. Monson showed in JAMA that including the partner improved the PTSD itself.",note:'This is the answer to "why you". It rests on external research, never on a claim of ours.'},{q:"Who wrote the content? What is it based on?",a:"It was built with therapists and trauma specialists, based on established approaches: SE, ACT, CBT, DBT, NVC, Gottman and EFT. It came out of more than 1,000 conversations and processes with fighting families, organizations, therapists and senior technology people.",note:'The correct phrasing is "built on evidence-based therapeutic approaches". The methods are proven. Our platform itself has not been studied, and we never imply otherwise.'},{q:"I do not see myself as a caregiver. Is this for me?",a:"Most people who come to us do not use that word either. Partners, parents, siblings, commanders. Anyone living beside someone who came home changed. You do not need a label to get help."},{q:"Who is behind this?",a:"Eliav Ser, founder and CEO. A major in the reserves with 450 days in combat, and part of the population the product serves."},{q:"What about privacy and regulation? Is the organization exposed?",a:`Activity is separated from identity and designed around Privacy by Design, GDPR, the Israeli privacy law (amendment 13) and HIPAA principles. A user can export or delete everything at any time, and the organization never sees personal content, only aggregate trends, and only from 11 participants up.

With an organization we sign a distribution agreement and a data processing agreement with an indemnity clause. Built-in distress detection routes any warning sign to human help and to emergency numbers.`},{q:"What does it cost an organization?",a:"Less than two therapy sessions buys a whole fighting family for a year. A state-funded therapy hour is about 384 shekels. A pilot runs six to seven weeks and is usually funded in whole or in part by a foundation, a municipality or a donor."},{q:"Can it carry our branding?",a:"Yes. Full white-label with your logo, colours and name, including a dedicated landing page and signup code. Included at no extra cost."},{q:"What if someone asks me something I do not know?",a:'Say "I am not sure, let me check and come back to you", and send it to us. That beats guessing. There is a direct button to Eliav at the bottom of this kit, and you can simply connect them to him.'}],T=[["anonymous, fully anonymous","private, separated from your identity"],["clinical AI platform","AI platform built on evidence-based therapeutic approaches"],["the clinical model, clinical companion","the professional model, professional companion"],["evidence-based:","built on evidence-based approaches:"],["anonymous community","community without full names"],["it will help him, it will heal","it gives tools, knowledge and support"],["family","fighting family"]],I=[{t:'The word "clinical"',b:'Allowed in two cases only: quoting a real clinical study, and referring to a licensed human ("optional professional clinical support"). Never as a description of the AI or the platform. That is the regulatory trigger for medical device classification.'},{t:'"Healing heroes"',b:'The slogan stays and is allowed. Not in a paid ad, because Meta rejects the word "heal", and never next to a capability claim.'},{t:"Two things that go nowhere in writing",b:'The reserves certification, which is still in process. And the trauma coalition, which appears only on our own pages and never on a flyer. The one trust mark that is allowed: "partners on the road".'},{t:"The one that breaks most often",b:"Do not default to the feminine in Hebrew. We have male users too. A blanket feminine erases the commanders, the male partners and the founder himself."}],S=[{w:"1",role:"Why me",what:"The personal post",where:"Facebook, LinkedIn",key:"post_personal"},{w:"2",role:"The problem",what:"The post with the source",where:"Facebook, Instagram",key:"post_problem"},{w:"3",role:"Invitation",what:"Invite to the next event",where:"Stories, groups",key:"wa_webinar"},{w:"4",role:"The ask",what:"Asking for an introduction",where:"LinkedIn",key:"linkedin_ask"}],A=[{outlet:"BR7",published_date:"2026-07-29",title:"4,000 reservists and rescue personnel in Sderot receive WalkImpact",url:"https://br7news.co.il/he/news/news-1785314026",summary:"The Sderot municipality is making the platform available to reservists and rescue personnel in the city, fully subsidised.",pull_quote:'"The responsibility is not only to say thank you, but to give real tools." Alon Davidi, Mayor of Sderot',sort_order:10}],W={firstStep:"Start here",whoTalking:"Who are you talking to?",pickAudience:"Pick an audience and get exactly what to send them. You can change it any time.",all:"All",forWhom:"For:",opens:"Opens:",updated:"Updated",whenTime:"When you have a moment",whatElse:"What else you have",allReady:"Everything is ready. It opens only when you need it.",foldPitch:"What to say",foldPitchSum:"The story at three lengths: 10 seconds, 30 seconds, and two minutes with someone who can decide.",foldMsg:"Messages ready to send",foldMsgSum:"WhatsApp, email and LinkedIn. Your link is already inside. One line is left for you.",foldWeb:"Invite to the next event",foldWebSum:"The easiest ask there is. You are asking for an hour, not a commitment.",foldSocial:"Post on social",foldSocialSum:"Four posts and a four week calendar. One post a week, a pace you can keep.",foldPress:"Press and articles",foldPressSum:"An opinion piece ready to publish under your name, a pitch to a journalist, and a press release.",foldProof:"The numbers and their sources",foldProofSum:"Every figure with its citation, so you can quote it when someone asks where it came from.",foldFaq:"Questions people will ask you",foldFaqSum:"Eleven questions people really ask, with answers you can read out as they are.",foldRed:"What not to say",foldRedSum:"Two wrong words cost us in regulation and in rejected ads. The list is deliberately short.",versions:"versions",mantras:"lines to remember",messages:"messages",posts:"posts",calendar:"4 week calendar",published:"published articles",templates:"templates",figures:"figures",questions:"questions",swaps:"swaps",rules:"rules",articleCta:"Read the article",eventPage:"Event page",yourLink:"Your personal link",copy:"Copy",copied:"Copied",whatsapp:"WhatsApp",usedKit:e=>`You have used this kit ${e} times. Thank you.`,stuck:"Stuck, or know someone worth talking to?",waEliav:"Message Eliav",tagline:"Supporting families, healing heroes",gateTitle:"This kit is personal",gateBody:"Every ambassador gets their own link. If you arrived without one, or the link expired, we are glad to open one for you.",gateCta:"Request access",socialRule:'No "healing" in a paid ad. No stock photos of soldiers. No figure without its source inside the creative.',yours:"The pink parts are yours. Without them it reads like a template.",coordinate:"Check with Eliav",week:"Week",role:"Role",publish:"What to publish",where:"Where",noneForSegment:"No dedicated material for this audience yet. The general materials work.",moment:"One moment"},i={families:"/families",fighter:"/fighter",orgs:"/orgs",employers:"/employers",impact:"/impact",impact_en:"/impact?lang=en",download:"/download",webinar:"/webinar"};function m(e){return e!=null&&e.ref_code?r(`/s/${e.ref_code}`):""}function c(e,{advocate:n,target:o,lang:h="he"}={}){const l=o||(e==null?void 0:e.link_target)||"families";let s=i[l]||i.families;h==="en"&&s==="/impact"&&(s=i.impact_en);const a=(n==null?void 0:n.ref_code)||"",d=r(s),t=new URL(d);return t.searchParams.set("utm_source","ambassador"),t.searchParams.set("utm_medium",(e==null?void 0:e.channel)||"share"),a&&t.searchParams.set("utm_campaign",a),e!=null&&e.msg_key&&t.searchParams.set("utm_content",e.msg_key),a&&t.searchParams.set("ref",a),t.toString()}function E(e,n="he"){const o=m(e);return o||c({msg_key:"personal",channel:"direct",link_target:"families"},{advocate:e,lang:n})}const M=i;export{S as K,M as L,u as S,W as U,A as a,I as b,T as c,_ as d,v as e,b as f,k as g,w as h,y as i,f as j,g as k,E as l,c as m};
