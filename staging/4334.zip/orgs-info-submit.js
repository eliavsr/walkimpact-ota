/* Lead submission for public/orgs-info.html — kept next to the page so the
   contract is reviewable: a WaitlistSignup row, then notifyWaitlistSignup,
   which sends the team alert and the warm confirmation to the sender.
   The page itself carries this same logic inline; this file is the reference. */
var APP_ID = '6a12d304bee1bf7c2b678097';
var API = 'https://app.walkimpact.com/api/apps/' + APP_ID;

function submitOrgLead(d) {
  var note = [];
  if (d.org) note.push('ארגון: ' + d.org);
  if (d.role) note.push('תפקיד: ' + d.role);
  if (d.topic) note.push('מתעניינים ב: ' + d.topic);
  if (d.note) note.push(d.note);
  note.push('נשלח מדף המידע לארגונים');

  var lead = {
    full_name: d.name || '',
    email: d.email || '',
    phone: d.phone || '',
    role: 'Organization',
    language: 'he',
    timestamp: new Date().toISOString(),
    status: 'pending',
    source: 'orgs',
    message: note.join(' · ')
  };

  return fetch(API + '/entities/WaitlistSignup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(lead)
  }).then(function (r) {
    if (!r.ok) throw new Error('lead');
    return fetch(API + '/functions/notifyWaitlistSignup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        full_name: lead.full_name, email: lead.email, phone: lead.phone,
        role: lead.role, language: 'he', context: 'lead', source: 'orgs'
      })
    }).catch(function () { /* the row is already safe */ });
  });
}
