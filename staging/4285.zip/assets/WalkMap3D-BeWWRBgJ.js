import{r as i,j as ut}from"./ui-vendor-mKHLcNOY.js";import{m as H}from"./maplibre-vendor-D9NOQbgX.js";import{a9 as Pt,m as V}from"./index-BorDjXat.js";import"./data-vendor-3D1cGamO.js";const Gt="https://tiles.openfreemap.org/styles/liberty",xt=["coalesce",["get","render_height"],8],Ct=["interpolate",["linear"],xt,0,"#DCCCEA",12,"#CDB8E0",30,"#B99FD4",60,"#A386C7",120,"#8E6DB8"],jt=e=>/^poi/i.test(e),Bt=["cafe","restaurant","fast_food","bakery","ice_cream","grocery","park","garden","playground","pharmacy","hospital","doctors"],Ut=["coalesce",["get","name:he"],["get","name"]],Wt=e=>{var l;const a=(l=e==null?void 0:e.layout)==null?void 0:l["text-field"];if(!a)return!1;try{return/name:(latin|nonlatin)/.test(JSON.stringify(a))}catch{return!1}},It=[[0,4,3],[.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,.5],[3,4,0],[0,.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,.5]],Kt=400,Et=new WeakMap;function Nt(e){var a;try{(a=Et.get(e))==null||a()}catch{}try{Et.delete(e)}catch{}try{e.remove()}catch{}}let X=null;function Yt(){if(X!==null)return X;try{const e=document.createElement("canvas");X=!!(window.WebGLRenderingContext&&(e.getContext("webgl")||e.getContext("experimental-webgl")))}catch{X=!1}return X}function kt([e,a],[l,b]){const f=D=>D*Math.PI/180,E=D=>D*180/Math.PI,u=f(b-a),A=Math.sin(u)*Math.cos(f(l)),R=Math.cos(f(e))*Math.sin(f(l))-Math.sin(f(e))*Math.cos(f(l))*Math.cos(u);return(E(Math.atan2(A,R))+360)%360}function qt(e,a){return((a-e)%360+540)%360-180}function bt([e,a],[l,b]){const f=(l-e)*111320,E=(b-a)*111320*Math.cos(e*Math.PI/180);return Math.hypot(E,f)}const Jt=30;function Vt(e,a){if(!Array.isArray(e)||e.length<2||!a)return a;const l=111320,b=111320*Math.cos(a[0]*Math.PI/180),f=a[1]*b,E=a[0]*l;let u=null,A=1/0;for(let R=0;R<e.length-1;R++){const D=e[R][1]*b,z=e[R][0]*l,B=e[R+1][1]*b,Q=e[R+1][0]*l,M=B-D,S=Q-z,K=M*M+S*S;if(!K)continue;let $=((f-D)*M+(E-z)*S)/K;$=Math.max(0,Math.min(1,$));const P=D+$*M,Z=z+$*S,tt=Math.hypot(f-P,E-Z);tt<A&&(A=tt,u=[Z/l,P/b])}return u&&A<=Jt?u:a}const Xt=35;function Qt(e,a){if(!Array.isArray(e)||e.length<2||!a)return null;let l=0,b=1/0;for(let u=0;u<e.length;u++){const A=bt(a,e[u]);A<b&&(b=A,l=u)}if(b>120)return null;let f=0;for(let u=l;u<e.length-1;u++)if(f+=bt(e[u],e[u+1]),f>=Xt)return kt(a,e[u+1]);const E=e[e.length-1];return bt(a,E)>5?kt(a,E):null}function re({center:e,routePoints:a=[],routeCoords:l=[],roadBehind:b=[],destination:f=null,stops:E=[],routeNodes:u=[],onStopTap:A,onStopMoved:R,onMapPress:D,onStopSlots:z,introFlyIn:B=!1,follow:Q=!0,zoom:M=17.5,pitch:S=55,cameraOffset:K=null,topChrome:$=0,padding:P=null,trailColor:Z=V.teal,routeColor:tt=V.indigo,frameRoute:Lt=!0,reduced:I=!1,onUserPan:vt,onMoveEnd:Tt,onCamera:At,onFallback:Rt}){const[et,Ot]=i.useState(!1),G=i.useRef(null),w=i.useRef(null),N=i.useRef(!1),gt=i.useRef(0),nt=i.useRef(null),rt=i.useRef(null),Y=i.useRef(null),C=i.useRef([]),at=i.useRef(new Map),ft=i.useRef(0),yt=i.useRef($);yt.current=$;const q=i.useRef([]),k=i.useRef(Rt),L=i.useRef(vt),ot=i.useRef(A),it=i.useRef(R),st=i.useRef(D),ct=i.useRef(z),lt=i.useRef(Tt),dt=i.useRef(At);dt.current=At,k.current=Rt,L.current=vt,ot.current=A,it.current=R,st.current=D,ct.current=z,lt.current=Tt,i.useEffect(()=>{var m,O,j,y,x,_;if(!G.current||w.current)return;if(!Yt()){(m=k.current)==null||m.call(k);return}try{((j=(O=H).getRTLTextPluginStatus)==null?void 0:j.call(O))==="unavailable"&&H.setRTLTextPlugin("https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.2.3/mapbox-gl-rtl-text.min.js",!0)}catch{}let t;try{t=new H.Map({container:G.current,style:Gt,center:e?[e[1],e[0]]:[34.78,32.08],zoom:M,pitch:S,bearing:0,attributionControl:!1,antialias:!1,fadeDuration:0})}catch{(y=k.current)==null||y.call(k);return}w.current=t,t.on("error",o=>{var s,d;(s=o==null?void 0:o.error)!=null&&s.message&&/webgl|context/i.test(o.error.message)&&((d=k.current)==null||d.call(k))});const n=o=>{var s;o!=null&&o.originalEvent&&((s=L.current)==null||s.call(L))};t.on("dragstart",n),t.on("rotatestart",n),t.on("zoomstart",n),t.on("moveend",()=>{var o;try{const s=t.getCenter();(o=lt.current)==null||o.call(lt,[s.lat,s.lng])}catch{}});const h=o=>{var s;if(o!=null&&o.draggable)try{const d=(s=at.current.get(o.id))==null?void 0:s.getLngLat();if(d)return[d.lng,d.lat]}catch{}return[o.lon,o.lat]};t.on("click",o=>{var s,d;try{if(Date.now()-ft.current<Kt)return;const W=o.point,ht=mt.current||[];let F=null,p=1/0,r=null;ht.forEach(T=>{if(typeof(T==null?void 0:T.lat)!="number"||typeof(T==null?void 0:T.lon)!="number"||T.kind==="ghost")return;const J=h(T),Dt=t.project(J),Ft=Math.hypot(Dt.x-W.x,Dt.y-W.y);Ft<p&&(p=Ft,F=T,r=J)});const Mt=()=>{var T;try{const J=t.unproject(W);(T=st.current)==null||T.call(st,{lat:J.lat,lon:J.lng})}catch{}};if(!F){Mt();return}const Ht=F.state==="today"?34:F.kind==="back"||F.kind==="coin"?28:24;if(p>Ht){Mt();return}const St=t.project(r),wt=(s=G.current)==null?void 0:s.getBoundingClientRect(),pt=F.state==="today"?52:30,zt=wt?{left:wt.left+St.x-pt/2,top:wt.top+St.y-pt/2,width:pt,height:pt}:null;(d=ot.current)==null||d.call(ot,F,zt)}catch{}}),t.on("load",()=>{var W,ht,F;N.current=!0;try{(W=dt.current)==null||W.call(dt,{zoomBy:p=>{var r;try{(r=L.current)==null||r.call(L),t.easeTo({zoom:Math.min(19.5,Math.max(13,t.getZoom()+p)),duration:320})}catch{}},tiltBy:p=>{var r;try{(r=L.current)==null||r.call(L),t.easeTo({pitch:Math.min(70,Math.max(0,t.getPitch()+p)),duration:320})}catch{}},turnBy:p=>{var r;try{(r=L.current)==null||r.call(L),t.easeTo({bearing:t.getBearing()+p,duration:320})}catch{}},reset:()=>{try{t.easeTo({pitch:S,bearing:0,zoom:M,duration:420})}catch{}}})}catch{}if(Ot(!0),B)try{t.jumpTo({zoom:Math.max(13,M-2.2),pitch:Math.max(0,S-22)}),setTimeout(()=>{try{t.easeTo({zoom:M,pitch:S,duration:4500})}catch{}},2800)}catch{}try{(ht=t.setSky)==null||ht.call(t,{"sky-color":"#BFDBF5","horizon-color":"#F6E9F0","fog-color":"#EFE7F5","sky-horizon-blend":.5,"horizon-fog-blend":.35,"fog-ground-blend":.08})}catch{}try{const p=(F=t.getStyle().layers.find(r=>r.type==="symbol"))==null?void 0:F.id;t.addLayer({id:"wi-buildings-3d",source:"openmaptiles","source-layer":"building",type:"fill-extrusion",minzoom:14,filter:["!=",["get","hide_3d"],!0],paint:{"fill-extrusion-color":Ct,"fill-extrusion-base":["coalesce",["get","render_min_height"],0],"fill-extrusion-opacity":.82,"fill-extrusion-vertical-gradient":!0,"fill-extrusion-height":I?xt:0,"fill-extrusion-height-transition":{duration:1400,delay:0}}},p),I||setTimeout(()=>{var r;try{(r=w.current)==null||r.setPaintProperty("wi-buildings-3d","fill-extrusion-height",xt)}catch{}},220)}catch{}const o=(()=>{try{return Pt("todayV3")}catch{return!1}})();try{const p=t.getStyle().layers||[];o&&Bt.length?p.filter(r=>r.type==="symbol"&&jt(r.id)).forEach(r=>{try{t.setFilter(r.id,["all",...r.filter?[r.filter]:[],["match",["get","class"],Bt,!0,!1]])}catch{}}):p.filter(r=>r.type==="symbol"&&jt(r.id)).forEach(r=>{try{t.setLayoutProperty(r.id,"visibility","none")}catch{}}),o&&p.forEach(r=>{if(!(r.type!=="symbol"||!Wt(r)))try{t.setLayoutProperty(r.id,"text-field",Ut)}catch{}})}catch{}const s=B?6.5:1,d=B?.8:1;try{t.addSource("wi-road-back",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),t.addLayer({id:"wi-road-back-casing",type:"line",source:"wi-road-back",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*s,"line-opacity":.34*d}}),t.addLayer({id:"wi-road-back-line",type:"line",source:"wi-road-back",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#6E5C93","line-width":10*s,"line-opacity":.55*d}}),t.addSource("wi-trail",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),t.addLayer({id:"wi-trail-casing",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":15*s,"line-opacity":.45*d}}),t.addLayer({id:"wi-trail-line",type:"line",source:"wi-trail",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":Z,"line-width":10*s,"line-opacity":.92*d}}),t.addSource("wi-route",{type:"geojson",data:{type:"Feature",geometry:{type:"LineString",coordinates:[]}}}),t.addLayer({id:"wi-route-casing",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":"#3B2A63","line-width":12*s,"line-opacity":.5*d}}),t.addLayer({id:"wi-route-line",type:"line",source:"wi-route",layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":tt,"line-width":8*s,"line-opacity":.95*d}}),t.addLayer({id:"wi-route-flow",type:"line",source:"wi-route",layout:{"line-cap":"butt","line-join":"round"},paint:{"line-color":"#FFFFFF","line-width":B?3:3.4,"line-opacity":B?.28:.9,"line-dasharray":[0,4,3]}})}catch{}if(!I)if(nt.current=setInterval(()=>{if(!w.current||!N.current)return;const p=Date.now()%7e3/7e3,r=.55+.4*(.5-Math.cos(p*2*Math.PI)/2);try{w.current.setPaintProperty("wi-trail-line","line-opacity",r)}catch{}},120),B)try{w.current.setPaintProperty("wi-route-flow","line-dasharray",[2,3])}catch{}else{let p=0;rt.current=setInterval(()=>{if(!(!w.current||!N.current)){p=(p+1)%It.length;try{w.current.setPaintProperty("wi-route-flow","line-dasharray",It[p])}catch{}}},90)}});const g=typeof ResizeObserver<"u"?new ResizeObserver(()=>{try{t.resize()}catch{}}):null;try{g&&G.current&&g.observe(G.current)}catch{}const U=requestAnimationFrame(()=>{try{t.resize()}catch{}}),v=(x=t.getCanvas)==null?void 0:x.call(t),c=o=>{var s,d;(s=o.preventDefault)==null||s.call(o),(d=k.current)==null||d.call(k)};return(_=v==null?void 0:v.addEventListener)==null||_.call(v,"webglcontextlost",c),()=>{var o,s;cancelAnimationFrame(U);try{g==null||g.disconnect()}catch{}nt.current&&clearInterval(nt.current),rt.current&&clearInterval(rt.current),nt.current=null,rt.current=null,(o=v==null?void 0:v.removeEventListener)==null||o.call(v,"webglcontextlost",c);try{(s=Y.current)==null||s.remove()}catch{}Y.current=null,C.current.forEach(Nt),C.current=[],at.current.clear(),N.current=!1;try{t.remove()}catch{}w.current=null}},[]),i.useEffect(()=>{const t=w.current;if(!t||!e||!Q)return;const n=Qt(l,e)??(a.length>=2?kt(a[a.length-2],a[a.length-1]):null);n!=null&&(gt.current+=qt(gt.current,n)*.18);const h=Vt(l,e);try{t.easeTo({center:[h[1],h[0]],bearing:gt.current,pitch:S,zoom:M,offset:K||[0,0],...P?{padding:P}:{},duration:I?0:900,essential:!0})}catch{}},[e,a,l,Q,I,M,S,K,P]),i.useEffect(()=>{const t=w.current;if(!(!t||!N.current||!Lt||l.length<2))try{const n=new H.LngLatBounds;l.forEach(([h,g])=>n.extend([g,h])),t.fitBounds(n,{padding:{top:150,bottom:230,left:60,right:60},pitch:40,bearing:0,duration:I?0:1500,essential:!0})}catch{}},[l,I,Lt]),i.useEffect(()=>{var n;const t=w.current;if(t){try{(n=Y.current)==null||n.remove()}catch{}if(Y.current=null,!!f)try{const h=document.createElement("div");h.className="wi-dest-pin",h.innerHTML='<span class="wi-dest-ring"></span><span class="wi-dest-dot"></span>',Y.current=new H.Marker({element:h,anchor:"center"}).setLngLat([f.lon,f.lat]).addTo(t)}catch{}}},[f]);const _t=u.map(t=>`${t.id}|${t.done?1:0}`).join("~");i.useEffect(()=>{const t=w.current;if(t)return q.current.forEach(n=>{try{n.remove()}catch{}}),q.current=[],u.forEach(n=>{try{const h=n.kind==="coin"?"#f59e0b":"#14b8a6",g=document.createElement("div");g.style.cssText=`width:${n.done?12:20}px;height:${n.done?12:20}px;border-radius:50%;background:${h};border:3px solid #fff;box-shadow:0 2px 8px rgba(26,20,38,.28);opacity:${n.done?.35:1};`;const U=new H.Marker({element:g,anchor:"center"}).setLngLat([n.lon,n.lat]).addTo(t);q.current.push(U)}catch{}}),()=>{q.current.forEach(n=>{try{n.remove()}catch{}}),q.current=[]}},[_t]);const $t=E.map(t=>`${t.id}|${t.lat}|${t.lon}|${t.state}|${t.done?1:0}|${t.color}|${t.icon}|${t.caption}|${t.draggable?1:0}`).join("~"),mt=i.useRef(E);return mt.current=E,i.useEffect(()=>{var v;const t=w.current;if(!t)return;const n=mt.current;C.current.forEach(Nt),C.current=[],at.current.clear();const h=[];n.forEach(c=>{if(!(typeof(c==null?void 0:c.lat)!="number"||typeof(c==null?void 0:c.lon)!="number"))try{const m=document.createElement("button");m.type="button",m.className=`wi-stop wi-stop--${c.state||"ahead"}${c.done?" wi-stop--complete":""}`,m.style.setProperty("--wi-stop",c.color||V.teal),m.setAttribute("aria-label",c.label||"");const O=document.createElement("span");if(O.className="wi-stop-slot",m.appendChild(O),c.done){const x=document.createElement("span");x.className="wi-stop-check",x.textContent="✓",m.appendChild(x)}if(c.caption){const x=document.createElement("span");x.className=`wi-stop-cap${c.capAbove?" wi-stop-cap--above":""}`,x.textContent=c.caption,m.appendChild(x)}const j=!!c.draggable,y=new H.Marker({element:m,anchor:"center",draggable:j}).setLngLat([c.lon,c.lat]).addTo(t);if(j){m.classList.add("wi-stop--draggable");const x=()=>{try{m.classList.add("wi-stop--dragging")}catch{}},_=()=>{ft.current=Date.now()},o=()=>{var s;ft.current=Date.now();try{m.classList.remove("wi-stop--dragging")}catch{}try{const d=y.getLngLat();(s=it.current)==null||s.call(it,c.id,{lat:d.lat,lon:d.lng})}catch{}};y.on("dragstart",x),y.on("drag",_),y.on("dragend",o),at.current.set(c.id,y),Et.set(y,()=>{try{y.setDraggable(!1)}catch{}try{y.off("dragstart",x)}catch{}try{y.off("drag",_)}catch{}try{y.off("dragend",o)}catch{}try{m.classList.remove("wi-stop--dragging","wi-stop--draggable")}catch{}})}C.current.push(y),h.push({id:c.id,el:O})}catch{}}),(v=ct.current)==null||v.call(ct,h);let g;const U=()=>{var m;const c=yt.current;if(c)try{const O=t.getContainer().getBoundingClientRect().top;for(const j of C.current){const y=(m=j.getElement)==null?void 0:m.call(j);if(!y)continue;const x=y.getBoundingClientRect().top-O,_=Math.max(0,Math.min(1,(x-c)/26));y.style.opacity=String(_),y.style.pointerEvents=_<.35?"none":""}}catch{}g=requestAnimationFrame(U)};if(yt.current)return g=requestAnimationFrame(U),()=>cancelAnimationFrame(g)},[$t,et]),i.useEffect(()=>{var n;const t=w.current;if(!(!t||!N.current))try{(n=t.getSource("wi-trail"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:a.map(([h,g])=>[g,h])}})}catch{}},[a,et]),i.useEffect(()=>{var n;const t=w.current;if(!(!t||!N.current))try{(n=t.getSource("wi-route"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:l.map(([h,g])=>[g,h])}})}catch{}},[l,et]),i.useEffect(()=>{var n;const t=w.current;if(!(!t||!N.current))try{(n=t.getSource("wi-road-back"))==null||n.setData({type:"Feature",geometry:{type:"LineString",coordinates:b.map(([h,g])=>[g,h])}})}catch{}},[b,et]),ut.jsxs(ut.Fragment,{children:[ut.jsx("style",{children:`
        /* ⚠️⚠️ THE RTL TRAP — READ BEFORE TOUCHING ANY MARKER RULE.
           MapLibre's own stylesheet pins every marker with
           .maplibregl-marker { position:absolute; top:0; left:0 } and then
           writes the ground position into an inline transform. Our rules below
           are a single class too, and they load LAST — so declaring
           position:relative here silently beat MapLibre's absolute, dropped the
           marker back into normal flow, and in an RTL document normal flow
           starts at the RIGHT EDGE. The inline transform then offset it from
           there, pushing every stop roughly a screen-width off to the side.
           Measured: container 0..1850, inline translate(925px) — and the marker
           landed at x=2697. That is the whole of "the journey is somewhere on
           the map I have to go looking for": her road was literally rendered
           off the edge of the screen.
           Keep position:absolute + top:0 + left:0 on anything MapLibre mounts as
           a marker. top is still animatable (the bob uses it) because an
           absolutely positioned box honours top just the same. */
        .wi-dest-pin { position: absolute; top: 0; left: 0; width: 26px; height: 26px; }
        .wi-dest-dot { position:absolute; inset:7px; border-radius:50%;
          background:${V.indigo}; border:2.5px solid #fff;
          box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .wi-dest-ring { position:absolute; inset:0; border-radius:50%;
          background:${V.indigo}; opacity:.35; animation: wiDestPulse 1.9s ease-out infinite; }
        @keyframes wiDestPulse {
          0% { transform: scale(.55); opacity:.55; }
          70% { transform: scale(1.5); opacity:0; }
          100% { transform: scale(1.5); opacity:0; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-dest-ring { animation: none; } }

        /* Journey stops standing in the world. Sized by their moment: the day's
           step is the one that draws the eye, the past is quiet, ahead is faint. */
        /* ⚠️⚠️ NOTHING HERE MAY ANIMATE OR SET transform ON .wi-stop ITSELF.
           MapLibre positions a marker by writing an inline transform onto this
           exact element (translate(-50%,-50%) translate(Xpx,Ypx)), and any CSS
           animation or rule that also sets transform REPLACES that — the
           marker snaps to the container's top-left corner and stops following
           the ground.
           That is precisely what happened to TODAY'S stop: the bob animation
           below used to animate transform, so the single most important thing
           on the screen rendered at (0,-1) — off in the corner — while every
           other stop sat correctly on the road. Measured, not guessed:
           computedTransform matrix(1,0,0,1,0,-1) against an inline
           translate(187.5px,340px). It reads exactly like "the journey is
           somewhere on the map you have to go looking for".
           The bob now animates top (this element is position:relative, so that
           moves it visually and touches no transform), and the press uses the
           standalone scale property, which composes with transform instead of
           overwriting it. */
        .wi-stop { -webkit-appearance:none; appearance:none; padding:0; cursor:pointer;
          position:absolute; top:0; left:0;   /* ⚠️ see THE RTL TRAP above */
          border-radius:50%; background:#fff; border:2.5px solid var(--wi-stop);
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 3px 10px rgba(40,25,70,.35); transition:scale .18s ease; }

        /* The road remembers. Every stop she finished carries a soft bloom in
           its own domain colour, so the path behind her is visibly warmer than
           the path ahead — presence left on the ground rather than a number in
           a corner. Drawn behind the marker and never interactive. */
        /* A finished day stops asking for attention: the bob is dropped and a
           check rides the marker, so the work she did is visible ON the road. */
        .wi-stop--complete { animation:none !important; }
        .wi-stop-check { position:absolute; right:-3px; bottom:-3px; width:20px; height:20px;
          border-radius:50%; background:#2E9E6B; border:2.5px solid #fff; color:#fff;
          font-size:11px; font-weight:900; line-height:1;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 2px 6px rgba(40,25,70,.4); pointer-events:none; }

        .wi-stop--done::after, .wi-stop--complete::after {
          content:''; position:absolute; inset:-11px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, var(--wi-stop) 0%, transparent 70%);
          opacity:.34; pointer-events:none;
          animation: wiBloom 6s ease-in-out infinite;
        }
        @keyframes wiBloom {
          0%,100% { transform: scale(1);    opacity:.30; }
          50%     { transform: scale(1.14); opacity:.42; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--done::after { animation:none; } }
        .wi-stop:active { scale:.9; }
        /* ⚠️ HIT SLOP, NOT A BIGGER BUTTON. A finished stop is 30px and a
           locked one 28px — well under the 44px a thumb needs — so taps that
           looked like they landed on a stop landed on the map instead, and the
           card "did not open". The circle keeps its size; only the target
           grows, behind it, invisible. */
        .wi-stop::before { content:''; position:absolute; inset:-9px; border-radius:50%; }
        .wi-stop-slot { display:flex; align-items:center; justify-content:center; line-height:0; }
        /* Sits under the circle, reads over any ground the map puts behind it. */
        /* Dark ink inside a white halo, NOT white text: the ground under these
           labels is a pale lavender city, and white-on-pale left "אתמול · היום ·
           מחר" barely there - the one thing that tells her which way her own
           road runs. */
        .wi-stop-cap { position:absolute; top:100%; margin-top:7px; left:50%;
          transform:translateX(-50%); white-space:nowrap; pointer-events:none;
          font-size:11.5px; font-weight:900; color:#241C3A; letter-spacing:.01em;
          /* A solid light pill so the label reads on ANY surface — the pale map OR
             the dark purple road. Dark text over a white glow alone vanished on the
             road (looked white/unreadable). */
          background:rgba(255,255,255,0.94); padding:2px 9px; border-radius:999px;
          box-shadow:0 1px 5px rgba(26,20,38,0.18); text-shadow:none; }
        /* Future captions (מחר) sit ABOVE their circle so a small node's label
           never lands on the big today node just below it. */
        .wi-stop-cap--above { top:auto; bottom:100%; margin-top:0; margin-bottom:7px; }

        /* ── The road back, and the ghost of what is still folded away ──
           The journey card's own two nodes, planted on the map: a neutral 42px
           circle carrying the arrow, and one faint dashed node behind it so the
           road never looks like it ends. Same sizes, same weights, same colours
           as JourneyHeroCard — they are the same control, on a different
           surface. */
        /* Her coin, waiting on the road. No border and no white plate — it is
           an object lying there, not another station. */
        /* ── A MOMENT SHE SAVED ──
           Deliberately NOT a station: smaller, white, ringed in its own kind's
           colour, and off the road rather than on it. A station is a step the
           journey offered her; this is a thing she put there herself, and the
           two must never be mistaken for one another at a glance. */
        .wi-stop--moment { width:34px; height:34px; background:#FFFFFF;
                           border:2.5px solid var(--wi-stop); box-shadow:0 3px 10px rgba(40,25,70,0.30); }
        .wi-stop--moment .wi-stop-cap { font-size:10.5px; font-weight:800; padding:2px 8px; }

        .wi-stop--coin  { width:44px; height:44px; background:transparent; border:none;
                          box-shadow:none; }
        .wi-stop--coin::after {
          content:''; position:absolute; inset:-10px; border-radius:50%; z-index:-1;
          background: radial-gradient(circle, #8B60EA 0%, transparent 70%);
          opacity:.42; pointer-events:none; animation: wiBloom 3.4s ease-in-out infinite;
        }
        .wi-stop--back  { width:42px; height:42px; background:#F1EEF6; border:2px solid #E3DCEF;
                          box-shadow:0 3px 10px rgba(40,25,70,.22); }
        .wi-stop--ghost { width:36px; height:36px; background:#F1EEF6; border:2px dashed #E3DCEF;
                          opacity:.42; pointer-events:none; box-shadow:none; }
        .wi-stop--done   { width:30px; height:30px; opacity:.9; }
        .wi-stop--ahead  { width:28px; height:28px; opacity:.6; border-style:dashed; }
        .wi-stop--locked { width:28px; height:28px; opacity:.5; border-style:dashed; }
        .wi-stop--today  { width:70px; height:70px; border-width:5px;
          box-shadow:0 0 0 9px color-mix(in srgb, var(--wi-stop) 22%, transparent), 0 8px 22px rgba(40,25,70,.4);
          animation: wiStopBob 2.1s ease-in-out infinite; }
        .wi-stop--today .wi-stop-core { width:24px; height:24px; }
        @keyframes wiStopBob {
          0%,100% { top: 0; }
          50%     { top: -5px; }
        }
        @media (prefers-reduced-motion: reduce) { .wi-stop--today { animation:none; } }

        /* ── A PIN SHE CAN PICK UP ──
           Only the stops that carry HER documentation get this class, and it is
           added in JS beside MapLibre's own draggable flag so the two can never
           drift apart. touch-action:none is not decoration: without it the
           browser can claim the same finger for a scroll and the pin stutters
           out from under it halfway across the screen. */
        .wi-stop--draggable { cursor:grab; touch-action:none;
          -webkit-user-select:none; user-select:none; }
        /* ⚠️ TWO CLASSES, DELIBERATELY. The .wi-stop:active { scale:.9 } rule
           above is (0,2,0) and would out-specify a single class — so a pin under
           a mouse would SHRINK while being dragged, which reads as "pressed,
           stuck" rather than "lifted, moving". Doubling the class matches that
           weight and wins on source order.
           Feedback is scale + shadow only, and small: she is arranging her own
           day at 23:00, not playing with a toy. And it is the standalone scale
           property, never transform — MapLibre writes the ground position into
           this element's transform, and overwriting it drops the marker in the
           corner (see THE TRANSFORM TRAP above). The bob is stopped for the
           same reason it exists: a pin that keeps bouncing while she is placing
           it is fighting her hand. */
        .wi-stop--draggable.wi-stop--dragging { cursor:grabbing; scale:1.06;
          box-shadow:0 10px 26px rgba(40,25,70,.42); z-index:4; animation:none; }
        /* The lift is a state, so it stays; only the slide into it goes. */
        @media (prefers-reduced-motion: reduce) {
          .wi-stop--draggable.wi-stop--dragging { transition:none; }
        }
        ${I?".wi-stop--draggable.wi-stop--dragging { transition:none; }":""}
      `}),ut.jsx("div",{ref:G,style:{width:"100%",height:"100%"}})]})}export{Ut as HEBREW_FIRST_TEXT_FIELD,Bt as POI_ALLOWED_CLASSES,re as default,Yt as isWebGLAvailable};
