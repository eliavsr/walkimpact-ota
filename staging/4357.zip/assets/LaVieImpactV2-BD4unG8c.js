import{r as o,j as e,k as ce}from"./ui-vendor-YyuPkM9D.js";import{b as $,a as de,e0 as X,d_ as pe}from"./index-DjJnoU4Z.js";import me from"./MayaDoor-BaXBGBtr.js";import{u as he}from"./useMarketingDoor-cuoyPMIJ.js";import{b as ge,g as ue,s as xe}from"./supportDoor-BVYLtYCz.js";import{P as ve}from"./ParticleField-Dqj7bc2X.js";import{T as fe}from"./landingContent-9PbDh-XT.js";import{m as be,r as we,c as ke,D as ye,a as je,C as E,S as F,d as Ne,e as Z,h as ze,f as Se,P as Ae}from"./impactV2Content-Dr5MR6ph.js";import{D as J,S as Ce}from"./impactV2Dash-BUZFftPX.js";import"./data-vendor-B-T4UEYq.js";import"./MayaChatSurface-CDfLL41L.js";import"./MayaAvatar-D8vt5sJN.js";import"./SmartProgressBar-DWMUjWbu.js";import"./StartControls-BiexJPpJ.js";import"./proLegalCopy-BhwQZFjo.js";import"./proFlowEngine-8znWrxlU.js";import"./doorFlow-DRUENq65.js";const Le=[0,1,3],_e=l=>{const d=Math.max(...l);return l.map((n,x)=>[x*(100/(l.length-1)),26-n/d*22])},Ee=l=>l.map(([d,n],x)=>`${x?"L":"M"}${d.toFixed(1)},${n.toFixed(1)}`).join(" ");function ee({cast:l,field:d,markRef:n,className:x}){const p=o.useRef(null);return o.useEffect(()=>{const S=p.current;if(!S)return;const c=window.matchMedia("(prefers-reduced-motion: reduce)").matches;let b=0,f=0,A=!1;const w=2800,k=g=>{f||(f=g);const u=Math.min(1,(g-f)/w);n.current[d]=u,u<1&&(b=requestAnimationFrame(k))},y=()=>{if(!A){if(A=!0,c){n.current[d]=1;return}b=requestAnimationFrame(k)}};if(!("IntersectionObserver"in window)){y();return}const h=new IntersectionObserver(g=>{g.forEach(u=>{u.isIntersecting&&(y(),h.disconnect())})},{threshold:.3});return h.observe(S),()=>{cancelAnimationFrame(b),h.disconnect()}},[d,n]),e.jsx("div",{className:x,ref:p,children:e.jsx(ve,{cast:l,markRef:n,field:d})})}function V({text:l,label:d}){return l?e.jsxs("details",{className:"v2src",children:[e.jsx("summary",{children:d}),e.jsx("p",{children:l})]}):null}function Qe(){const[l,d]=o.useState("he"),[n,x]=o.useState(null),[p,S]=o.useState(11),[c,b]=o.useState(0),[f,A]=o.useState(!1),[w,k]=o.useState(!1),y=o.useRef(!1),h=o.useRef(null),g=o.useRef(!1),u=o.useRef(null),P=o.useRef({sold:0,fam:0}),r=o.useMemo(()=>be(n,l),[n,l]),T=o.useMemo(()=>we(n),[n]),D=o.useMemo(()=>({...ke,...(n==null?void 0:n.images)||{}}),[n]),v=J[l]||J.he,ae=l==="he"?ze:Se,H=p*Ae,R=((n==null?void 0:n.donate_url_il)||"").trim()||ye,B=((n==null?void 0:n.donate_url_intl)||"").trim()||je,O=(n==null?void 0:n.sticky_cta_enabled)!==!1;o.useEffect(()=>{let t=!0;return(async()=>{try{const a=await $.entities.ImpactPageV2.filter({singleton_key:"main"},"-updated_date",1);t&&(a!=null&&a[0])&&x(a[0])}catch{}})(),()=>{t=!1}},[]),o.useEffect(()=>{const t=document.title;return document.title=r.title||t,g.current=window.matchMedia("(prefers-reduced-motion: reduce)").matches,()=>{document.title=t}},[r.title]);const Y=o.useCallback(()=>{if(h.current)return h.current;const t=window.AudioContext||window.webkitAudioContext;if(!t)return null;const a=new t,i=Math.floor(a.sampleRate*4),s=a.createBuffer(1,i,a.sampleRate),m=s.getChannelData(0);let N=0;for(let M=0;M<i;M++){const le=Math.random()*2-1;N=(N+.02*le)/1.02,m[M]=N*3.4}const L=a.createGain();L.gain.value=0,L.connect(a.destination);const z=a.createBufferSource();z.buffer=s,z.loop=!0;const _=a.createBiquadFilter();_.type="lowpass",_.frequency.value=320;const q=a.createGain();return q.gain.value=.05,z.connect(_),_.connect(q),q.connect(L),z.start(),h.current={ctx:a,master:L,src:z},h.current},[]);o.useEffect(()=>()=>{var a;const t=h.current;if(h.current=null,!!t){try{(a=t.src)==null||a.stop()}catch{}try{t.ctx.close().catch(()=>{})}catch{}}},[]);const te=o.useCallback(()=>{const t=Y();if(!t)return;t.ctx.state==="suspended"&&t.ctx.resume();const a=!y.current;y.current=a,A(a);const i=t.ctx.currentTime;t.master.gain.cancelScheduledValues(i),t.master.gain.setValueAtTime(t.master.gain.value,i),t.master.gain.linearRampToValueAtTime(a?1:0,i+(a?1:.4))},[Y]);o.useEffect(()=>{if(!O){k(!1);return}let t=!1;const a=()=>{t=!1;const s=window.scrollY>window.innerHeight*.85,m=u.current,N=m?m.getBoundingClientRect().top<window.innerHeight*.9:!1;k(s&&!N)},i=()=>{t||(t=!0,requestAnimationFrame(a))};return window.addEventListener("scroll",i,{passive:!0}),window.addEventListener("resize",i),a(),()=>{window.removeEventListener("scroll",i),window.removeEventListener("resize",i)}},[O,T]),o.useEffect(()=>{const t=document.querySelectorAll(".wi-v2 [data-reveal]");if(!("IntersectionObserver"in window)||g.current){t.forEach(i=>i.classList.add("on"));return}const a=new IntersectionObserver(i=>{i.forEach(s=>{s.isIntersecting&&(s.target.classList.add("on"),a.unobserve(s.target))})},{rootMargin:"4000px 0px -8% 0px",threshold:0});return t.forEach(i=>a.observe(i)),()=>a.disconnect()},[l,T,c]);const C=t=>X("form","impact-v2",`${t}_seats_${p}`),I=t=>{var a;t.preventDefault(),(a=u.current)==null||a.scrollIntoView({behavior:g.current?"auto":"smooth",block:"start"})},j=l==="he",{doorEnabled:ie,doorDryRun:re,doorOpen:ne,openDoor:se,closeDoor:U}=he("support:impact"),G=ie&&j,W=o.useMemo(()=>{const t=ge("impact",{donateIl:R,donateIntl:B}),a=t.handoff.ready;return{...t,steps:t.steps.map(i=>i.key==="seats"&&!a?{...i,chips:i.chips.map(s=>{if(s.goto!=="give")return s;const m={...s};return delete m.goto,m})}:i.key==="give"?{...i,chips:i.chips.map(s=>s.href?{...s,route:s.href}:s)}:i)}},[R,B]),K=W.handoff.ready||ue,oe=async t=>{const a=xe(t,{kind:"impact",utm:pe()});if(re)return console.info("[door] dry run - nothing was written:",a),{id:"dry"};const i=await $.entities.WaitlistSignup.create(a);return $.functions.invoke("notifyWaitlistSignup",{full_name:a.full_name,email:a.email,phone:a.phone,role:a.role,language:"he",context:"lead",source:a.source,utm_campaign:a.utm_campaign,landing_path:a.landing_path,message:a.message}).catch(s=>console.warn("lead notification failed (lead was saved):",s)),X("form","impact-v2",`door_seats_${t.seats??""}`),{id:(i==null?void 0:i.id)||"ok"}},Q={hero:t=>e.jsxs("section",{className:"v2 dark hero",style:{backgroundImage:`url('${D.img_hero}')`},children:[e.jsxs("div",{className:"v2in",children:[e.jsx("p",{className:"word",children:r.hero}),e.jsx("p",{className:"lead",children:(r.heroLine||[]).map((a,i)=>e.jsxs(ce.Fragment,{children:[i?e.jsx("br",{}):null,a]},a))}),e.jsx("p",{className:"attrib",children:r.heroSrc})]}),e.jsxs("a",{className:"cue",href:"#donate",onClick:I,children:[r.scroll,e.jsx("i",{"aria-hidden":"true",children:"↓"})]})]},t.key),problem:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:r.problemTitle}),e.jsx("p",{className:"h2sub",children:r.problemSub}),e.jsx(ee,{cast:"soldiers",field:"sold",markRef:P,className:"field"}),e.jsx("p",{className:"bignum",children:e.jsx("span",{children:r.problemNum})}),e.jsx(ee,{cast:"family",field:"fam",markRef:P,className:"field fam"}),e.jsx("p",{className:"body",children:r.problemLine}),e.jsx(V,{text:r.problemSrc,label:r.sourcesLabel})]})},t.key),scope:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:r.scopeTitle}),e.jsx("div",{className:"tiles","data-reveal":!0,children:(r.scopeTiles||[]).map(([a,i,s])=>e.jsxs("div",{className:"tile",children:[e.jsx("span",{className:"tn",children:a}),e.jsx("span",{className:"tl",children:i}),s?e.jsx("span",{className:"tnote",children:s}):null]},`${a}-${i}`))}),e.jsx("p",{className:"money",children:r.scopeMoney}),e.jsx("p",{className:"body",children:r.scopeMoneyLine}),e.jsxs("a",{className:"inlinecta",href:"#donate",onClick:I,children:[r.scopeMoneyCta," ",e.jsx("span",{"aria-hidden":"true",children:j?"←":"→"})]}),e.jsx(V,{text:r.scopeSrc,label:r.sourcesLabel})]})},t.key),gap:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:r.gapTitle}),e.jsx("p",{className:"h2sub accent",children:r.gapSub}),e.jsx("div",{className:"hours","data-reveal":!0,"aria-hidden":"true",children:e.jsx("div",{className:"hourgrid",children:Array.from({length:168},(a,i)=>e.jsx("span",{className:`hr${i===0?" on":""}`},i))})}),e.jsx("p",{className:"micro",children:r.gapLegend})]})},t.key),proof:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"h1",children:r.proofTitle}),e.jsx("div",{className:"bars","data-reveal":!0,children:(r.proofBars||[]).map(([a,i,s],m)=>e.jsxs("div",{className:"bar",children:[e.jsx("span",{className:"barlbl",children:a}),e.jsx("span",{className:"bartrack",children:e.jsx("span",{className:`barfill${m?" good":""}`,style:{width:`${i/2.55*100}%`}})}),e.jsx("span",{className:"bartag",children:s})]},a))}),e.jsx("p",{className:"body strong",children:r.proofNote}),e.jsx("p",{className:"bignum","data-reveal":!0,children:e.jsx("span",{children:r.reboundNum})}),e.jsx("p",{className:"body",children:r.reboundLine}),e.jsx(V,{text:r.proofSrc,label:r.sourcesLabel})]})},t.key),solution:t=>e.jsx("section",{className:"v2 dark",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:r.solutionTitle}),e.jsx("p",{className:"h2sub",children:r.solutionSub}),e.jsx("div",{className:"phones","data-reveal":!0,children:(Z[l]||Z.he).map((a,i)=>e.jsxs("figure",{children:[e.jsx("span",{className:"phone",children:e.jsx("img",{src:a,alt:(r.solutionCaps||[])[i]||"",loading:"lazy",decoding:"async"})}),e.jsx("figcaption",{children:(r.solutionCaps||[])[i]})]},a))})]})},t.key),credibility:t=>e.jsx("section",{className:"v2 dark tight",children:e.jsxs("div",{className:"v2in",children:[e.jsx("p",{className:"credline",children:r.credLine}),e.jsx("p",{className:"micro",children:r.credSrc})]})},t.key),orgs:t=>e.jsx("section",{className:"v2 light",children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:r.orgsTitle}),e.jsx("p",{className:"body strong",children:r.orgsSub}),e.jsx("p",{className:"body",children:r.orgsLine}),e.jsx("p",{className:"body",children:r.orgsPrivacy}),e.jsx("div",{className:"tabs",role:"tablist",children:(r.orgsTabs||[]).map((a,i)=>e.jsx("button",{role:"tab","aria-selected":c===i,className:`tab${c===i?" on":""}`,onClick:()=>b(i),children:a},a))}),e.jsxs("div",{className:"agg",role:"tabpanel",children:[e.jsxs("div",{className:"agghead",children:[e.jsx("p",{className:"aggwho",children:v[c].who}),e.jsx("span",{className:"aggtrend",children:v[c].trend})]}),e.jsxs("div",{className:"agghero",children:[e.jsxs("div",{children:[e.jsx("p",{className:"aggbig",children:v[c].big}),e.jsx("p",{className:"aggbiglbl",children:v[c].bigLbl})]}),(()=>{const a=_e(Ce[c]),i=Ee(a),[s,m]=a[a.length-1];return e.jsxs("svg",{className:"spark",viewBox:"0 0 100 30","aria-hidden":"true",preserveAspectRatio:"none",children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"wiV2Spark",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"0",stopColor:"#C7155A",stopOpacity:".34"}),e.jsx("stop",{offset:"1",stopColor:"#C7155A",stopOpacity:"0"})]})}),e.jsx("path",{d:`${i} L100,30 L0,30 Z`,fill:"url(#wiV2Spark)",stroke:"none"}),e.jsx("path",{d:i,fill:"none",stroke:"#C7155A",strokeWidth:"2.4",strokeLinecap:"round",strokeLinejoin:"round"}),e.jsx("circle",{cx:s,cy:m,r:"2.4",fill:"#C7155A"})]})})()]}),e.jsx("div",{className:"aggkpis",children:v[c].kpis.map(([a,i])=>e.jsxs("div",{className:"kpi",children:[e.jsx("span",{className:"kpin",children:a}),e.jsx("span",{className:"kpil",children:i})]},i))}),e.jsx("div",{className:"aggbands",children:v[c].bands.map(([a,i])=>e.jsxs("div",{className:"band",children:[e.jsx("span",{className:"bandlbl",children:a}),e.jsx("span",{className:"bandtrack",children:e.jsx("span",{className:"bandfill",style:{width:`${i}%`}})}),e.jsxs("span",{className:"bandpct",children:[i,"%"]})]},a))}),e.jsx("p",{className:"aggline",children:v[c].line})]},c),e.jsx("p",{className:"micro",children:r.orgsNote})]})},t.key),voices:t=>e.jsx("section",{className:"v2 dark photo",style:{backgroundImage:`url('${D.img_voices}')`},children:e.jsxs("div",{className:"v2in wide",children:[e.jsx("h2",{className:"h1",children:r.voicesTitle}),e.jsx("p",{className:"body",children:r.voicesSub}),e.jsx("div",{className:"voices","data-reveal":!0,children:Le.map(a=>fe[a]).filter(Boolean).map(([a,i])=>e.jsxs("blockquote",{children:[e.jsx("p",{children:a}),e.jsx("cite",{children:i})]},i))})]})},t.key),traction:t=>e.jsx("section",{className:"v2 light tight",children:e.jsx("div",{className:"v2in",children:e.jsxs("div",{className:"tract","data-reveal":!0,children:[e.jsx("div",{className:"tractrow",children:(r.tractionStats||[]).map(([a,i])=>e.jsxs("div",{className:"tractstat",children:[e.jsx("span",{className:"tn",children:a}),e.jsx("span",{className:"tl",children:i})]},i))}),e.jsxs("blockquote",{className:"tractquote",children:[e.jsx("p",{children:r.tractionQuote}),e.jsx("cite",{children:r.tractionQuoteSrc})]}),e.jsxs("a",{className:"tractlink",href:Ne,target:"_blank",rel:"noopener noreferrer",children:[r.tractionLink," ",e.jsx("span",{"aria-hidden":"true",children:j?"←":"→"})]})]})})},t.key),donate:t=>e.jsx("section",{id:"donate",ref:u,className:"v2 dark photo ask",style:{backgroundImage:`url('${D.img_donate}')`},children:e.jsxs("div",{className:"v2in",children:[e.jsx("h2",{className:"asktitle",children:r.donateTitle}),e.jsx("p",{className:"anchor",children:r.donateSub}),e.jsx("p",{className:"anchorsub",children:r.donateSubSub}),e.jsx("p",{className:"h3",children:r.seatLabel}),e.jsx("div",{className:"grid","aria-hidden":"true",children:Array.from({length:E},(a,i)=>e.jsx("span",{className:`seat${i<Math.min(p,E)?" on":""}`},i))}),p>E&&e.jsxs("p",{className:"plus",children:["+",ae(p-E)]}),e.jsx("input",{className:"slider",type:"range",min:"0",max:F.length-1,step:"1",value:F.indexOf(p),onChange:a=>S(F[Number(a.target.value)]),"aria-label":r.seatLabel,"aria-valuetext":String(p)}),e.jsx("div",{className:"stops","aria-hidden":"true",children:F.map(a=>e.jsx("span",{children:a},a))}),G?e.jsxs(e.Fragment,{children:[e.jsx("button",{type:"button",className:"cta","data-wi-door-cta":"1",onClick:()=>{C("door"),se("donate_section")},children:K?r.cta(p,H):"להחזיק משפחה לוחמת"}),!K&&e.jsx("p",{className:"anchorsub",children:"תרומה מקוונת עוד לא פתוחה. משאירים פרטים, ונחזור אליכם."})]}):e.jsxs(e.Fragment,{children:[e.jsx("a",{className:"cta",href:R,target:"_blank",rel:"noopener noreferrer",onClick:()=>C("primary"),children:r.cta(p,H)}),e.jsx("a",{className:"cta ghost",href:B,target:"_blank",rel:"noopener noreferrer",onClick:()=>C("intl"),children:r.ctaIntl})]}),e.jsx("p",{className:"legal",children:r.legal})]})},t.key)};return e.jsxs("div",{dir:r.dir,lang:l,className:`wi-v2${l==="en"?" en":""}`,children:[e.jsx("style",{children:Fe}),e.jsxs("div",{className:"topbar",children:[e.jsx("button",{className:"chip",onClick:()=>d(j?"en":"he"),"aria-label":r.otherLabel,children:r.other}),e.jsx("button",{className:"chip",onClick:te,role:"switch","aria-checked":f,children:`♪ ${f?r.sound[1]:r.sound[0]}`})]}),e.jsx("main",{children:T.map(t=>Q[t.key]?Q[t.key](t):null)}),O&&e.jsxs("a",{className:`sticky${w?" on":""}`,href:"#donate",onClick:I,"aria-hidden":!w,tabIndex:w?0:-1,children:[r.stickyCta," ",e.jsx("span",{"aria-hidden":"true",children:j?"←":"→"})]}),G&&ne&&e.jsx(me,{flow:W,doorKey:"support:impact",onSubmit:oe,renderDone:()=>e.jsx(de,{variant:"quiet",onClick:U,children:"סגירה"}),onClose:U,onRoute:t=>{C("door_donate"),window.open(t,"_blank","noopener,noreferrer")}})]})}const Fe=`
.wi-v2{--ink:#14111C;--ink2:#1D1926;--lav:#F3EDFA;--paper:#FFF;
  --magenta:#C7155A;--magenta2:#D81E5B;--violet:#8B60EA;
  --text-lt:#F7F4F9;--muted-lt:#CBC5D3;--text-dk:#14111C;--muted-dk:#6B6478;
  background:var(--ink);font-family:'Google Sans','Open Sans Hebrew','Heebo','Assistant',system-ui,sans-serif}
.wi-v2.en{font-family:'Google Sans','Assistant',system-ui,sans-serif}
.wi-v2 *{box-sizing:border-box}
.wi-v2 main{position:relative;z-index:1}

.wi-v2 .v2{position:relative;padding:clamp(5rem,12vh,9rem) clamp(1.25rem,6vw,5rem);
  display:flex;align-items:center;justify-content:center}
.wi-v2 .v2.tight{padding-top:clamp(2rem,5vh,3.5rem);padding-bottom:clamp(3.5rem,8vh,6rem)}
.wi-v2 .v2.dark{background:var(--ink);color:var(--text-lt)}
.wi-v2 .v2.light{background:var(--lav);color:var(--text-dk)}
.wi-v2 .v2.photo{background-size:cover;background-position:center}
.wi-v2 .v2.dark.photo::before{content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,rgba(20,17,28,.95) 0%,rgba(20,17,28,.88) 40%,rgba(20,17,28,.95) 100%)}
.wi-v2 .v2in{position:relative;z-index:1;max-width:740px;width:100%;text-align:center}
.wi-v2 .v2in.wide{max-width:1080px}

/* The copy sits in the TOP third, not the middle. Centred, it landed straight on
   the soldiers' faces and torsos - the busiest part of the frame - and the
   Hebrew became genuinely hard to read. Held high, the type has the plain wall
   and sky behind it and the photograph still reads underneath. */
.wi-v2 .hero{min-height:100svh;background-size:cover;background-position:center;
  align-items:flex-start;padding-top:clamp(9vh,14vh,16vh)}
.wi-v2 .hero::before{content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,rgba(20,17,28,.88) 0%,rgba(20,17,28,.74) 30%,
    rgba(20,17,28,.46) 56%,rgba(20,17,28,.62) 78%,rgba(20,17,28,.93) 100%)}
.wi-v2 .word{font-size:clamp(2.6rem,7vw,5.2rem);font-weight:800;line-height:.95;letter-spacing:-.03em;
  margin:0;text-shadow:0 4px 44px rgba(7,6,11,.85)}
.wi-v2 .lead{font-size:clamp(1.3rem,2.8vw,2rem);line-height:1.4;margin:26px auto 0;max-width:24ch;
  text-wrap:balance;text-shadow:0 2px 28px rgba(7,6,11,.9)}
.wi-v2 .attrib{font-size:.92rem;color:var(--muted-lt);margin:26px auto 0;max-width:46ch;line-height:1.55;
  text-shadow:0 2px 18px rgba(7,6,11,.95)}
.wi-v2 .cue{position:absolute;z-index:2;bottom:calc(26px + var(--wi-safe-bottom, env(safe-area-inset-bottom, 0px)));
  left:50%;transform:translateX(-50%);font-size:1rem;
  color:#B4ADBF;letter-spacing:.14em;font-weight:600;text-decoration:none;
  text-shadow:0 2px 18px rgba(7,6,11,.95)}
.wi-v2 .cue i{display:block;font-style:normal;font-size:1.45rem;margin-top:8px;
  animation:wiV2Bob 2.6s cubic-bezier(.4,0,.6,1) infinite}
@keyframes wiV2Bob{0%,100%{transform:translateY(0);opacity:.4}50%{transform:translateY(9px);opacity:1}}

.wi-v2 .h1{font-size:clamp(1.9rem,4.5vw,3.4rem);font-weight:700;line-height:1.05;letter-spacing:-.02em;
  margin:0;text-wrap:balance}
.wi-v2 .h2sub{font-size:clamp(1.3rem,2.6vw,1.9rem);font-weight:500;line-height:1.3;margin:14px auto 0;
  max-width:26ch;text-wrap:balance}
.wi-v2 .h2sub.accent{color:var(--magenta)}
.wi-v2 .v2.dark .h2sub.accent{color:#F094B0}
.wi-v2 .h3{font-size:clamp(1.25rem,2.2vw,1.6rem);font-weight:700;margin:38px 0 4px}
.wi-v2 .body{font-size:clamp(1.05rem,1.6vw,1.3rem);line-height:1.6;margin:18px auto 0;max-width:44ch}
.wi-v2 .body.strong{font-weight:600}
.wi-v2 .v2.dark .body{color:var(--muted-lt)}
.wi-v2 .v2.light .body{color:var(--muted-dk)}
.wi-v2 .micro{font-size:.78rem;line-height:1.6;margin:16px auto 0;max-width:60ch}
.wi-v2 .v2.dark .micro{color:#8F8899}
.wi-v2 .v2.light .micro{color:var(--muted-dk)}
/* Weighted so the number groups with the cloud BELOW it, which is the one it
   counts, rather than floating equidistant between the two. */
.wi-v2 .bignum{margin:26px 0 0}
.wi-v2 .field+.bignum{margin-top:48px}
.wi-v2 .bignum span{display:inline-block;font-size:clamp(3.2rem,9vw,7rem);font-weight:800;line-height:1;
  letter-spacing:-.03em;color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .v2.dark .bignum span{color:#F094B0}
.wi-v2 .money{font-size:clamp(2rem,5.5vw,3.4rem);font-weight:800;letter-spacing:-.02em;margin:38px 0 0;
  color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .credline{font-size:clamp(.95rem,1.3vw,1.06rem);line-height:1.65;color:var(--muted-lt);
  margin:0 auto;max-width:60ch}

.wi-v2 .inlinecta{display:inline-flex;align-items:center;gap:8px;margin-top:22px;padding:13px 26px;
  border-radius:999px;background:var(--magenta);color:#fff;text-decoration:none;font-weight:700;font-size:1.02rem;
  transition:filter .25s,transform .25s}
.wi-v2 .inlinecta:hover{filter:brightness(1.08);transform:translateY(-2px)}

.wi-v2 .tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:32px auto 0}
.wi-v2 .tile{border-radius:20px;padding:22px 12px 18px;display:flex;flex-direction:column;gap:8px;align-items:center}
.wi-v2 .v2.light .tile{background:rgba(255,255,255,.72);border:1px solid rgba(139,96,234,.18)}
.wi-v2 .v2.dark .tile{background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.15)}
.wi-v2 .tile .tn{font-size:clamp(1.7rem,3.6vw,2.6rem);font-weight:800;line-height:1;letter-spacing:-.02em;
  color:var(--magenta);font-variant-numeric:tabular-nums}
.wi-v2 .tile .tl{font-size:clamp(.95rem,1.35vw,1.06rem);line-height:1.4;text-align:center}
.wi-v2 .v2.light .tile .tl{color:var(--text-dk)}
.wi-v2 .v2.dark .tile .tl{color:var(--muted-lt)}
.wi-v2 .tile .tnote{font-size:.8rem;line-height:1.45;text-align:center}
.wi-v2 .v2.light .tile .tnote{color:var(--muted-dk)}
.wi-v2 .v2.dark .tile .tnote{color:#A49DB0}

/* The point clouds. Sized so ten figures still read as ten on a phone, with
   headroom above them for the in-canvas callouts. */
.wi-v2 .field{width:min(1040px,94vw);height:clamp(280px,36vh,420px);margin:30px auto 6px}
.wi-v2 .field.fam{width:min(520px,72vw);height:clamp(210px,26vh,300px);margin:18px auto 6px}
.wi-v2 .pfield{width:100%;height:100%;display:block}

.wi-v2 .hours{margin:34px auto 0;max-width:520px}
.wi-v2 .hourgrid{display:grid;grid-template-columns:repeat(24,1fr);gap:4px}
.wi-v2 .hr{aspect-ratio:1;border-radius:2px;background:rgba(255,255,255,.13)}
.wi-v2 .hr.on{background:var(--magenta);box-shadow:0 0 12px rgba(199,21,90,.75)}
.wi-v2 .hours[data-reveal] .hr{opacity:0;transition:opacity .5s}
.wi-v2 .hours[data-reveal].on .hr{opacity:1}

.wi-v2 .bars{display:flex;flex-direction:column;gap:20px;margin:34px auto 0;max-width:600px;text-align:start}
.wi-v2 .bar{display:grid;grid-template-columns:1fr;gap:8px}
.wi-v2 .barlbl{font-size:1.05rem}
.wi-v2 .v2.light .barlbl{color:var(--muted-dk)}
.wi-v2 .v2.dark .barlbl{color:var(--muted-lt)}
.wi-v2 .bartrack{display:block;height:16px;border-radius:99px;overflow:hidden}
.wi-v2 .v2.light .bartrack{background:rgba(20,17,28,.10)}
.wi-v2 .v2.dark .bartrack{background:rgba(255,255,255,.09)}
.wi-v2 .barfill{display:block;height:100%;border-radius:99px;background:#9C93AD;
  transition:width 1s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .barfill.good{background:linear-gradient(90deg,var(--violet),var(--magenta))}
.wi-v2 .bartag{font-size:.98rem;font-weight:700;font-variant-numeric:tabular-nums}
.wi-v2 .bars[data-reveal]:not(.on) .barfill{width:0 !important}

.wi-v2 .phones{display:grid;grid-template-columns:repeat(auto-fit,minmax(184px,1fr));gap:26px;margin:44px auto 0}
.wi-v2 .phones figure{margin:0}
.wi-v2 .phone{display:block;padding:9px;border-radius:34px;background:linear-gradient(160deg,#2A2436,#15121D);
  border:1px solid rgba(255,255,255,.16);box-shadow:0 24px 60px rgba(0,0,0,.6);position:relative}
.wi-v2 .phone::after{content:"";position:absolute;top:15px;left:50%;transform:translateX(-50%);
  width:34%;height:7px;border-radius:99px;background:#0B0910}
.wi-v2 .phone img{width:100%;display:block;border-radius:26px}
.wi-v2 .phones figcaption{font-size:1.02rem;color:var(--muted-lt);margin-top:14px;line-height:1.45}

.wi-v2 .tabs{display:flex;gap:8px;justify-content:center;margin:28px auto 0;flex-wrap:wrap}
.wi-v2 .tab{padding:11px 22px;border-radius:999px;font-size:1rem;font-weight:600;font-family:inherit;
  cursor:pointer;transition:background .25s,color .25s,border-color .25s}
.wi-v2 .v2.light .tab{background:rgba(255,255,255,.7);border:1px solid rgba(139,96,234,.24);color:var(--muted-dk)}
.wi-v2 .v2.light .tab.on{background:var(--magenta);border-color:var(--magenta);color:#fff}
.wi-v2 .agg{margin:26px auto 0;max-width:640px;text-align:start;border-radius:20px;padding:28px;
  animation:wiV2Rise .5s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .v2.light .agg{background:rgba(255,255,255,.82);border:1px solid rgba(139,96,234,.2)}
@keyframes wiV2Rise{from{opacity:0;transform:translateY(12px)}}
.wi-v2 .agghead{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap;margin-bottom:18px}
.wi-v2 .aggwho{font-size:1.15rem;font-weight:700;margin:0}
.wi-v2 .aggtrend{font-size:1rem;font-weight:600;color:var(--violet)}
.wi-v2 .agghero{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin:0 0 22px}
.wi-v2 .aggbig{font-size:clamp(2.6rem,6vw,4rem);font-weight:800;margin:0;line-height:1;letter-spacing:-.02em;
  font-variant-numeric:tabular-nums}
.wi-v2 .aggbiglbl{font-size:1.05rem;color:var(--muted-dk);margin:8px 0 0}
.wi-v2 .spark{width:min(150px,34%);height:44px;overflow:visible;opacity:.9}
.wi-v2 .aggkpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0 0 22px}
.wi-v2 .kpi{border-radius:12px;padding:14px 8px;display:flex;flex-direction:column;gap:4px;align-items:center;text-align:center;
  background:rgba(139,96,234,.08);border:1px solid rgba(139,96,234,.16)}
.wi-v2 .kpin{font-size:clamp(1.2rem,2vw,1.5rem);font-weight:800;color:var(--magenta);line-height:1;font-variant-numeric:tabular-nums}
.wi-v2 .kpil{font-size:.95rem;color:var(--muted-dk);line-height:1.35}
.wi-v2 .aggbands{display:flex;flex-direction:column;gap:15px}
.wi-v2 .band{display:grid;grid-template-columns:8ch 1fr 4ch;align-items:center;gap:12px}
.wi-v2 .bandlbl{font-size:1rem;color:var(--muted-dk)}
.wi-v2 .bandtrack{height:14px;border-radius:99px;background:rgba(20,17,28,.10);overflow:hidden}
.wi-v2 .bandfill{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--violet),var(--magenta));
  animation:wiV2Band .9s cubic-bezier(.2,.7,.3,1)}
@keyframes wiV2Band{from{width:0}}
.wi-v2 .bandpct{font-size:1rem;font-variant-numeric:tabular-nums;text-align:end}
.wi-v2 .aggline{font-size:1.08rem;line-height:1.55;margin:22px 0 0}

.wi-v2 .voices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin:34px auto 0;text-align:start}
.wi-v2 .voices blockquote:last-child:nth-child(odd){grid-column:1/-1}
.wi-v2 .voices blockquote{margin:0;background:rgba(13,11,19,.78);border:1px solid rgba(255,255,255,.14);
  border-radius:18px;padding:26px 28px;position:relative;overflow:hidden}
/* The Hebrew gershayim, not a low-9 quote. U+201E sits ON the baseline, so at
   5.4rem it dropped into the middle of the card and collided with the quote it
   was decorating. This glyph hangs from the cap line, which is why the long page
   uses it. */
.wi-v2 .voices blockquote::before{content:"״";position:absolute;top:-14px;inset-inline-start:14px;
  font-size:5.4rem;font-weight:700;color:#F094B0;opacity:.22;line-height:1;pointer-events:none}
.wi-v2 .voices blockquote::after{content:"";position:absolute;inset-inline-start:0;top:0;bottom:0;width:3px;
  background:linear-gradient(180deg,#F094B0,transparent)}
.wi-v2 .voices p{font-size:1.08rem;line-height:1.6;margin:0;position:relative}
.wi-v2 .voices cite{display:block;font-style:normal;font-size:.95rem;color:#F094B0;margin-top:14px;font-weight:600}

.wi-v2 .tract{margin:0 auto;max-width:620px;border-radius:20px;padding:26px 28px;
  background:rgba(255,255,255,.78);border:1px solid rgba(139,96,234,.22);text-align:start}
.wi-v2 .tractrow{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.wi-v2 .tractstat{display:flex;flex-direction:column;gap:5px;align-items:center;text-align:center}
.wi-v2 .tractstat .tn{font-size:clamp(1.4rem,3vw,2rem);font-weight:800;color:var(--magenta);
  line-height:1;font-variant-numeric:tabular-nums}
.wi-v2 .tractstat .tl{font-size:.9rem;color:var(--muted-dk);line-height:1.35}
.wi-v2 .tractquote{margin:22px 0 0;border-inline-start:3px solid var(--magenta);padding-inline-start:16px}
.wi-v2 .tractquote p{font-size:1.08rem;font-weight:600;line-height:1.5;margin:0}
.wi-v2 .tractquote cite{display:block;font-style:normal;font-size:.86rem;color:var(--muted-dk);margin-top:9px}
.wi-v2 .tractlink{display:inline-flex;align-items:center;gap:8px;margin-top:16px;color:var(--magenta);
  font-weight:700;font-size:.98rem;text-decoration:none}
.wi-v2 .tractlink:hover{text-decoration:underline}

.wi-v2 .asktitle{font-size:clamp(1.9rem,4.5vw,3.2rem);font-weight:800;line-height:1.15;margin:0 auto;
  max-width:20ch;text-wrap:balance}
.wi-v2 .anchor{font-size:clamp(1.35rem,2.6vw,1.9rem);font-weight:700;color:#F094B0;margin:24px auto 0;max-width:26ch;line-height:1.35}
.wi-v2 .anchorsub{font-size:1.1rem;color:var(--muted-lt);margin:8px auto 0}
.wi-v2 .grid{display:grid;grid-template-columns:repeat(10,1fr);gap:6px;margin:22px auto 0;max-width:440px}
.wi-v2 .seat{aspect-ratio:1;border-radius:3px;background:rgba(255,255,255,.11);border:1px solid rgba(255,255,255,.13);
  transition:background .28s cubic-bezier(.2,.7,.3,1),box-shadow .28s}
.wi-v2 .seat.on{background:var(--magenta);border-color:var(--magenta);box-shadow:0 0 12px rgba(199,21,90,.55)}
.wi-v2 .plus{font-size:1.1rem;font-weight:700;color:#F094B0;margin:12px 0 0}
.wi-v2 .slider{width:100%;max-width:440px;margin:22px 0 0;accent-color:var(--magenta);cursor:pointer}
.wi-v2 .stops{display:flex;justify-content:space-between;max-width:440px;margin:6px auto 0;
  font-size:.95rem;color:#B4ADBF;font-variant-numeric:tabular-nums}
.wi-v2 .cta{display:block;width:fit-content;margin:30px auto 0;padding:19px 46px;border-radius:999px;
  font-size:1.16rem;font-weight:800;color:#fff;text-decoration:none;
  background:linear-gradient(135deg,var(--magenta),var(--magenta2));transition:filter .25s,transform .25s}
.wi-v2 .cta:hover{filter:brightness(1.08);transform:translateY(-2px)}
/* The door's CTA is a <button> (it opens a takeover, it does not navigate), so
   it needs the three properties the UA stylesheet hands an <a> for free. */
.wi-v2 button.cta{border:0;font-family:inherit;cursor:pointer;text-align:center}
.wi-v2 .cta.ghost{margin-top:14px;background:transparent;border:1.5px solid rgba(255,255,255,.4);
  font-size:1.02rem;font-weight:700;padding:15px 34px}
.wi-v2 .cta.ghost:hover{background:rgba(255,255,255,.1)}
.wi-v2 .legal{font-size:.86rem;color:#9F98AB;line-height:1.7;max-width:60ch;margin:28px auto 0}

.wi-v2 .v2src{margin:26px auto 0;max-width:100%;text-align:start}
.wi-v2 .v2src summary{cursor:pointer;font-size:.78rem;letter-spacing:.04em;font-weight:600;
  list-style:none;display:inline-flex;align-items:center;gap:6px;padding:6px 0;opacity:.72}
.wi-v2 .v2src summary::-webkit-details-marker{display:none}
.wi-v2 .v2src summary::after{content:"↓";font-size:.7rem;transition:transform .25s}
.wi-v2 .v2src[open] summary::after{transform:rotate(180deg)}
.wi-v2 .v2src p{font-size:.78rem;line-height:1.65;margin:8px 0 0}
.wi-v2 .v2.dark .v2src summary,.wi-v2 .v2.dark .v2src p{color:#8F8899}
.wi-v2 .v2.light .v2src summary,.wi-v2 .v2.light .v2src p{color:var(--muted-dk)}

.wi-v2 .topbar{position:fixed;top:14px;inset-inline-end:14px;z-index:9;display:flex;gap:8px}
/* Opaque enough to sit over a heading. At .82 the section titles read straight
   through the chips on a phone, where a centred heading passes under them. */
.wi-v2 .chip{padding:11px 17px;border-radius:999px;background:rgba(20,17,28,.94);
  -webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.22);color:var(--text-lt);font-size:.95rem;font-weight:600;
  font-family:inherit;cursor:pointer}
.wi-v2 .chip:hover{background:rgba(40,34,55,.94)}

/* The sticky CTA never covers the ask it points at, and on a phone it sits
   above the safe-area inset so it cannot land under the home indicator.
   --wi-safe-bottom first, env() only as the fallback: on Android env() reports
   0 often enough that lib/nativeSafeArea.js exists solely to correct it, and
   the resolved value lands in the var. Reading env() directly opts out of the
   fix and drops this pill into the gesture strip on 3-button devices. */
.wi-v2 .sticky{position:fixed;z-index:8;inset-inline-end:18px;
  bottom:calc(18px + var(--wi-safe-bottom, env(safe-area-inset-bottom,0px)));
  display:inline-flex;align-items:center;gap:8px;padding:15px 28px;border-radius:999px;
  background:linear-gradient(135deg,var(--magenta),var(--magenta2));color:#fff;text-decoration:none;
  font-weight:800;font-size:1rem;box-shadow:0 14px 40px rgba(199,21,90,.45);
  opacity:0;transform:translateY(16px);pointer-events:none;
  transition:opacity .35s cubic-bezier(.2,.7,.3,1),transform .35s cubic-bezier(.2,.7,.3,1)}
.wi-v2 .sticky.on{opacity:1;transform:none;pointer-events:auto}

.wi-v2 [data-reveal]>*{opacity:0;transform:translateY(16px);
  transition:opacity .6s cubic-bezier(.2,.7,.3,1),transform .6s cubic-bezier(.2,.7,.3,1)}
.wi-v2 [data-reveal].on>*{opacity:1;transform:none}
.wi-v2 [data-reveal]>*:nth-child(2){transition-delay:.1s}
.wi-v2 [data-reveal]>*:nth-child(3){transition-delay:.2s}
.wi-v2 [data-reveal]>*:nth-child(4){transition-delay:.3s}
.wi-v2 :focus-visible{outline:2px solid var(--magenta);outline-offset:4px;border-radius:6px}

@media (prefers-reduced-motion:reduce){
  .wi-v2 .cue i{animation:none}
  .wi-v2 .sticky,.wi-v2 .seat{transition:none}
  .wi-v2 [data-reveal]>*{transition:none;opacity:1;transform:none}
  .wi-v2 .agg,.wi-v2 .bandfill{animation:none}
}
@media (max-width:760px){
  .wi-v2 .tiles{grid-template-columns:repeat(2,1fr)}
}
@media (max-width:640px){
  .wi-v2 .topbar{top:10px;inset-inline-end:10px}
  .wi-v2 .chip{padding:9px 13px;font-size:.86rem}
  .wi-v2 .voices{grid-template-columns:1fr}
  .wi-v2 .voices blockquote:last-child:nth-child(odd){grid-column:auto}
  .wi-v2 .grid{gap:5px;max-width:330px}
  .wi-v2 .agg{padding:20px 16px}
  .wi-v2 .band{grid-template-columns:7ch 1fr 4ch;gap:8px}
  .wi-v2 .tractrow{grid-template-columns:1fr;gap:16px}
  .wi-v2 .hourgrid{grid-template-columns:repeat(14,1fr);gap:3px}
  .wi-v2 .field{height:clamp(230px,30vh,300px);margin-top:22px}
  .wi-v2 .field.fam{width:min(340px,84vw);height:200px}
  .wi-v2 .sticky{inset-inline:14px;justify-content:center;font-size:.96rem;padding:14px 20px}
  .wi-v2 .cta{width:100%;padding:17px 22px;font-size:1.05rem}
}
`;export{Qe as default};
